local jobClothes = false
Citizen.CreateThread(function()
    while true do
        local wait = 1000
        local coords = GetPlayerCoords()
        for k,v in pairs(Outfits) do 
            local dist = #(v.Location - coords)
            if (dist < 20.0) then 
                wait = 0
                if (PlayerData ~= nil and v.Job == PlayerData.job.name and Marker(v.Location, dist, "Press ~INPUT_CONTEXT~ to get your clothes.")) then 
                    if (jobClothes) then
                        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
                            TriggerEvent('skinchanger:loadSkin', skin)
                        end)
                    else
                        ESX.TriggerServerCallback('esx_skin:getPlayerSkin', function(skin, jobSkin)
                            if skin.sex == 0 then
                                newSkin = v.Skin.male
                            else
                                newSkin = v.Skin.female
                            end
                            for k,v in pairs(newSkin) do 
                                skin[k] = v 
                            end
                            TriggerEvent('skinchanger:loadSkin', skin)
                        end)
                    end
                    jobClothes = not jobClothes
                end
            end
        end
        Citizen.Wait(wait)
    end
end)