ESX = exports["es_extended"]:getSharedObject()

RegisterNetEvent("esx_societyjobs:crafting:craftItem")
AddEventHandler("esx_societyjobs:crafting:craftItem", function(k, item)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    local craft = CraftingTables[k]
    print("[DEBUG] Crafting event triggered by player:", src)

    if not craft then 
        print("[DEBUG] No crafting table found for key:", k)
        return 
    end

    local recipe = nil
    for _, craftItem in pairs(craft.items) do
        if craftItem.Name == item then
            recipe = craftItem
            break
        end
    end

    if not recipe then
        print("[DEBUG] Invalid craft item:", item)
        TriggerClientEvent('okokNotify:Alert', src, "Error", "Invalid craft item.", 5000, 'error')
        return
    end

    print("[DEBUG] Recipe found:", recipe.Name)

    -- Check if the player has the required materials
    for _, material in pairs(recipe.Requirements) do
        local count = exports.ox_inventory:GetItemCount(src, material.item)
        print("[DEBUG] Checking material:", material.item, "Player has:", count, "Needs:", material.count)
        if count < material.count then
            TriggerClientEvent('okokNotify:Alert', src, "Error", "You lack the required materials.", 5000, 'error')
            return
        end
    end

    print("[DEBUG] Player has all required materials")

    -- Ensure all items are removed before adding the crafted item
    local removedItems = {}
    for _, material in pairs(recipe.Requirements) do
        local success = exports.ox_inventory:RemoveItem(src, material.item, material.count)
        if success then
            print("[DEBUG] Removed material:", material.item, "Amount:", material.count)
            table.insert(removedItems, material.item)
        else
            -- Rollback removed items if something fails
            for _, item in pairs(removedItems) do
                exports.ox_inventory:AddItem(src, item, material.count)
            end
            print("[DEBUG] Failed to remove required items. Rolling back.")
            TriggerClientEvent('okokNotify:Alert', src, "Error", "Failed to remove required items.", 5000, 'error')
            return
        end
    end

    print("[DEBUG] All required materials removed. Checking inventory space.")

    -- Check if the player can carry the crafted item before adding it
    if exports.ox_inventory:CanCarryItem(src, recipe.Name, recipe.count) then
        exports.ox_inventory:AddItem(src, recipe.Name, recipe.count)
        print("[DEBUG] Successfully crafted item:", recipe.Name, "Amount:", recipe.count)
        TriggerClientEvent('okokNotify:Alert', src, "Success", "Crafting successful!", 5000, 'success')
    else
        -- Return materials since the player can't carry the crafted item
        for _, material in pairs(recipe.Requirements) do
            exports.ox_inventory:AddItem(src, material.item, material.count)
        end
        print("[DEBUG] Player inventory full. Returning materials.")
        TriggerClientEvent('okokNotify:Alert', src, "Error", "Not enough space in inventory!", 5000, 'error')
    end
end)

ESX.RegisterServerCallback("esx_societyjobs:crafting:startCrafting", function(source, cb, k, item)
    local xPlayer = ESX.GetPlayerFromId(source)
    local craft = CraftingTables[k]
    if not craft then 
        print("[DEBUG] No crafting table found for key:", k)
        cb(false) 
        return 
    end

    local recipe = nil
    for _, craftItem in pairs(craft.items) do
        if craftItem.Name == item then
            recipe = craftItem
            break
        end
    end

    if not recipe then 
        print("[DEBUG] Invalid crafting recipe for:", item)
        cb(false) 
        return 
    end

    -- Check if player has required materials
    for _, material in pairs(recipe.Requirements) do
        if exports.ox_inventory:GetItemCount(source, material.item) < material.count then
            print("[DEBUG] Player missing material:", material.item)
            cb(false)
            return
        end
    end
    
    print("[DEBUG] Player has all required materials. Crafting can proceed.")
    cb(true)
end)
