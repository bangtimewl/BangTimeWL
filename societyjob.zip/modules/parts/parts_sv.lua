ESX = exports["es_extended"]:getSharedObject()

RegisterNetEvent("esx_societyjobs:parts:purchasePart")
AddEventHandler("esx_societyjobs:parts:purchasePart", function(k, partName)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    local partStore = PartStores[k]
    if not partStore then return end

    local partData = nil
    for _, part in pairs(partStore.items) do
        if part.Name == partName then
            partData = part
            break
        end
    end

    if not partData then
        TriggerClientEvent('okokNotify:Alert', src, "Error", "Invalid part selection.", 5000, 'error')
        return
    end

    local price = partData.Price or 0
    local playerMoney = xPlayer.getAccount('money').money  -- Fix: Get money from player account

    if playerMoney < price then
        TriggerClientEvent('okokNotify:Alert', src, "Error", "You don't have enough money.", 5000, 'error')
        return
    end

    -- Deduct money
    xPlayer.removeAccountMoney('money', price)

    -- Give the part and check if successful
    local success = exports.ox_inventory:AddItem(src, partData.Name, 1)
    if success then
        TriggerClientEvent('okokNotify:Alert', src, "Success", "You purchased " .. partData.Label .. " for $" .. price .. ".", 5000, 'success')
    else
        -- Refund money if item is not added
        xPlayer.addAccountMoney('money', price)
        TriggerClientEvent('okokNotify:Alert', src, "Error", "Failed to add part. Money refunded.", 5000, 'error')
    end
end)

ESX.RegisterServerCallback("esx_societyjobs:parts:purchasePart", function(source, cb, k, partName)
    local xPlayer = ESX.GetPlayerFromId(source)
    local partStore = PartStores[k]
    if not partStore then cb(false) return end

    local partData = nil
    for _, part in pairs(partStore.items) do
        if part.Name == partName then
            partData = part
            break
        end
    end

    if not partData then 
        cb(false)
        return
    end

    -- Fix: Check player money correctly
    local playerMoney = xPlayer.getAccount('money').money 
    if playerMoney < partData.Price then
        cb(false)
    else
        cb(true, "authorized_token")
    end
end)
