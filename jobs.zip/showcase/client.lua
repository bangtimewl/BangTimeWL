local JobData = Config.Jobs.Showcase
local HasAlreadyEnteredMarker = false
local LastZone = nil

function StartScriptA()
    if JobData.EnableBlips then
        for k, v in pairs(JobData.Locations) do
            local blip = AddBlipForCoord(v.coords)
            SetBlipSprite(blip, 380)
            SetBlipColour(blip, 1)
            SetBlipScale(blip, 0.7)
            SetBlipDisplay(blip, 4)
            SetBlipAsShortRange(blip, true)

            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString('SCMain')
            EndTextCommandSetBlipName(blip)
        end
    end

    Citizen.CreateThread(function()
        while true do
            local wait = 0

            for k, v in pairs(JobData.Locations) do
                local coords = GetEntityCoords(PlayerPedId())

                local dist = #(coords - v.coords)

                if dist < 10 then
                    LastZone = k
                    if Marker(v.coords, dist, "Browse") then
                        JobsNUI:Emit("items", JobData.Items)
                        JobsNUI:Emit("open", { context = "showcase" })
                        SetNuiFocus(true, true)
                    end
                end
            end

            if LastZone == nil then
                wait = 1000
            end

            Citizen.Wait(0)
        end
    end)
end

JobsNUI:On("purchase", function(data, cb)
    if data.context ~= "showcase" then
        return
    end

    local item = data.item
    if not data.item then
        return cb('')
    end

    ESX.TriggerServerCallback('showcase:purchase', function(resp)
        cb({
            result = resp
        })

        if resp == true then
            TriggerServerEvent("InteractSound_SV:PlayWithinDistance", 3.0, "purchase", 0.7)
        end
    end, data.item)
end)

local currentAction
local currentMessage
local currentActionData

AddEventHandler('showcase:entermarker', function(zone)
    currentAction = zone
    currentMessage = 'Press ~INPUT_CONTEXT~ browse'
    currentActionData = true
end)

AddEventHandler('showcase:exitmarker', function(zone)
    ESX.UI.Menu.CloseAll()
    currentAction = nil
end)

StartScriptA()
