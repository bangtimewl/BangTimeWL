local CurrentPlayerJob = {job = nil, grade = nil}
local JobData = Config.Jobs.Blazeit
local ClockedIn = false
local OvenStatus = {baking = false, type = nil, fire = false, timer = 0}
local AllowInteraction = true
local ActiveFire = nil

function GetBlazeit(type)
    for i=1, #JobData.CookableItems do 
        if (type == JobData.CookableItems[i].Name) then 
            return JobData.CookableItems[i]
        end
    end
end

function BlazeitGetBlazeitsMenu()
    local menu = {
        {
            id = 1,
            header = "Oven",
            txt = "This is where you can make anything. Don't forget the ingredients first!"
        },
    }
    for i=1, #JobData.CookableItems do 
        local data = JobData.CookableItems
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "bake_blazeit",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function BlazeitGetDrinksMenu()
    local menu = {
        {
            id = 1,
            header = "Drink Fountain",
            txt = "This is where you can pour any drinks for a fee."
        },
    }
    for i=1, #JobData.Drinks do 
        local data = JobData.Drinks
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "blazeit_drink",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function BlazeitGetIngredientsMenu()
    local menu = {
        {
            id = 1,
            header = "Blazeit Materials",
            txt = "This is where you can grab any materials."
        },
    }
    for i=1, #JobData.Ingredients do 
        local data = JobData.Ingredients
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label .. " - $" .. data[i].Price,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "blazeit_ingredients",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function BlazeitGatherAnim()
    LoadAnim('mini@repair') 
    TaskPlayAnim(PlayerPedId(), 'mini@repair', 'fixing_a_player', 8.0, -8, -1, 49, 0, 0, 0, 0)
end

function BlazeitStartFire(coords) 
    -- Make some variables for the particle dictionary and particle name.
    local dict = "scr_trevor3"
    local particleName = "scr_trev3_trailer_plume"

    -- Create a new thread.
    Citizen.CreateThread(function()
        -- Request the particle dictionary.
        RequestNamedPtfxAsset(dict)
        -- Wait for the particle dictionary to load.
        while not HasNamedPtfxAssetLoaded(dict) do
            Citizen.Wait(0)
        end
        UseParticleFxAssetNextCall(dict)
        -- Create a new non-looped particle effect, we don't need to store the particle handle because it will
        -- automatically get destroyed once the particle has finished it's animation (it's non-looped).
        ActiveFire = StartParticleFxLoopedAtCoord(particleName, coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 0.2, false, false, false)
    end)
end

function BlazeitStopFire() 
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Extinguishing Fire", 'mini@repair', 'fixing_a_player')
        BlazeitGatherAnim()
        Citizen.SetTimeout(5000, function()
            ClearPedTasksImmediately(PlayerPedId())
            StopParticleFxLooped(ActiveFire, true)
            ActiveFire = false
            AllowInteraction = true
        end)
    end)
end

function BlazeitStartBaking(type)
    if (not OvenStatus.baking and OvenStatus.type == nil) then 
        OvenStatus.baking = true
        OvenStatus.type = type
        OvenStatus.timer = JobData.BlazeitCookTime
        Citizen.CreateThread(function() 
            while OvenStatus.type ~= nil do
                OvenStatus.timer = OvenStatus.timer - 1
                if (OvenStatus.timer == 0) then
                    OvenStatus.baking = false
                end 
                if (OvenStatus.timer <= -JobData.OvercookedTime) then
                    OvenStatus.baking = false
                    OvenStatus.type = nil
                    OvenStatus.timer = 0
                    OvenStatus.fire = true
                    BlazeitStartFire(JobData.InteractMarkers["blazeit_oven"].Coords) 
                    break
                end 
                Citizen.Wait(1000)
            end
        end)
    end
end

function BlazeitMakeDough()
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Making Blazeit Dough", 'mini@repair', 'fixing_a_player')
        BlazeitGatherAnim()
        Citizen.Wait(5000)
        ClearPedTasksImmediately(PlayerPedId())
        TriggerServerEvent("esx_societyjobs:blazeit:craftDough")
        AllowInteraction = true
    end)
end

function BlazeitToggleDuty(bool)
    ClockedIn = bool
    if (ClockedIn) then 
        BlazeitSetMarkerDisplay("clock_in", false)
        BlazeitSetMarkerDisplay("clock_out", true)
        BlazeitSetMarkerDisplay("boss", true)
        BlazeitSetMarkerDisplay("drink_fountain", true)
        BlazeitSetMarkerDisplay("blazeit_ingredients", true)
        BlazeitSetMarkerDisplay("blazeit_oven", true)
    else
        BlazeitSetMarkerDisplay("clock_in", true)
        BlazeitSetMarkerDisplay("clock_out", false)
        BlazeitSetMarkerDisplay("boss", false)
        BlazeitSetMarkerDisplay("drink_fountain", false)
        BlazeitSetMarkerDisplay("blazeit_ingredients", false)
        BlazeitSetMarkerDisplay("blazeit_oven", false)
    end
end

function BlazeitSetMarkerDisplay(key, bool)
    JobData.InteractMarkers[key].Display = bool
end

function BlazeitGetMarkerText(key)
    local text = JobData.InteractMarkers[key].DisplayText
    if (key == "blazeit_oven") then 
        if OvenStatus.baking then 
            text = text:gsub("|oven_status|", "Crafting Timer: " .. OvenStatus.timer .. " second(s)")
        elseif OvenStatus.type ~= nil then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to take out the ".. GetBlazeit(OvenStatus.type).Label ..".")
        elseif OvenStatus.fire then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to extinguish the fire.")
        else
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to use the table.")
        end
    end
    return text
end

function BlazeitInteractMarker(key)
    AllowInteraction = false
    local marker = JobData.InteractMarkers[key]
    if (key == "boss") then 
        OpenSocietyJobBossMenu()
    elseif (key == "clock_out") then 
        BlazeitToggleDuty(false)
    elseif (key == "clock_in") then 
        Citizen.CreateThread(function()
            BlazeitToggleDuty(true)
        end)
    elseif (key == "drink_fountain") then 
        TriggerEvent('nh-context-bridge:sendMenu', BlazeitGetDrinksMenu())
    elseif (key == "blazeit_ingredients") then 
        TriggerEvent('nh-context-bridge:sendMenu', BlazeitGetIngredientsMenu())
    elseif (key == "blazeit_oven") then 
        if (OvenStatus.fire) then
            OvenStatus.fire = false
            BlazeitStopFire() 
        elseif (not OvenStatus.baking and OvenStatus.type ~= nil) then 
            local blazeitType = OvenStatus.type
            OvenStatus.type = nil
            OvenStatus.timer = 0
            OvenStatus.fire = false
            Citizen.CreateThread(function()
                AllowInteraction = false
                DisplayProgress(5000, "Taking Blazeit out of Oven", 'mini@repair', 'fixing_a_player')
                BlazeitGatherAnim()
                Citizen.Wait(5000)
                ClearPedTasksImmediately(PlayerPedId())
                TriggerServerEvent("esx_societyjobs:blazeit:cookedBlazeit", blazeitType)
                AllowInteraction = true
            end)
        elseif (not OvenStatus.baking and OvenStatus.type == nil) then
            TriggerEvent('nh-context-bridge:sendMenu', BlazeitGetBlazeitsMenu())
        end
    end
    AllowInteraction = true
end

function BlazeitThread()
    Citizen.CreateThread(function()
        while true do
            local wait = 1000
            local coords = GetPlayerCoords()
            for k,v in pairs(JobData.InteractMarkers) do 
                if (v.Display or v.Display == nil) then 
                    local dist = #(v.Coords - coords)
                    if (dist < 20.0) then 
                        wait = 0
                        if (Marker(v.Coords, dist, BlazeitGetMarkerText(k)) and AllowInteraction) then 
                            BlazeitInteractMarker(k)
                        end
                    end
                end
            end
            Citizen.Wait(wait)
        end
    end)
end

RegisterNetEvent("nh-context:returnData")
AddEventHandler("nh-context:returnData", function(_data)
    local key = _data.id
    local data = _data.data
    if (key == "blazeit_ingredients") then 
        Citizen.CreateThread(function()
            ESX.TriggerServerCallback("esx_societyjobs:blazeit:purchaseIngredient", function(result) 
                if (result) then 
                    Citizen.CreateThread(function()
                        AllowInteraction = false
                        DisplayProgress(5000, "Grabbing Ingredient", 'mini@repair', 'fixing_a_player')
                        BlazeitGatherAnim()
                        Citizen.Wait(5000)
                        ClearPedTasksImmediately(PlayerPedId())
                        AllowInteraction = true
                    end)
                else
                    ESX.ShowNotification("You cannot afford this ingredient.")
                end
            end, data.selected)
        end)
    elseif (key == "bake_blazeit") then
        AllowInteraction = false
        ESX.TriggerServerCallback("esx_societyjobs:blazeit:bakeBlazeit", function(result) 
            if (result) then 
                Citizen.CreateThread(function()
                    DisplayProgress(5000, "Putting food into Oven", 'mini@repair', 'fixing_a_player')
                    BlazeitGatherAnim()
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    BlazeitStartBaking(result)
                    AllowInteraction = true
                end)
            else
                ESX.ShowNotification("Missing Ingredients for the Blazeit.")
                AllowInteraction = true
            end
        end, data.selected)
    elseif (key == "blazeit_drink") then
        AllowInteraction = false
        ESX.TriggerServerCallback("esx_societyjobs:blazeit:getDrink", function(result) 
            if (result) then 
                Citizen.CreateThread(function()
                    DisplayProgress(5000, "Pouring Drink", 'mini@repair', 'fixing_a_player')
                    BlazeitGatherAnim()
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    AllowInteraction = true
                end)
            else
                ESX.ShowNotification("You cannot afford the drink.")
                AllowInteraction = true
            end
        end, data.selected)
    end
end)

RegisterNetEvent('esx_societyjobs:jobUpdated')
AddEventHandler('esx_societyjobs:jobUpdated', function(job)
    if (not CurrentPlayerJob.job or (CurrentPlayerJob.job ~= job.name or CurrentPlayerJob.grade ~= job.grade)) then 
        if (CurrentPlayerJob.job ~= job.name and job.name == "blazeit") then 
            BlazeitToggleDuty(false)
        elseif (job.name == "unemployed") then
            BlazeitToggleDuty(false)
            BlazeitSetMarkerDisplay("clock_in", false)
        end
        CurrentPlayerJob.job = job.name
        CurrentPlayerJob.grade = job.grade
    end
end)

OnScriptStarted(BlazeitThread)