local CurrentPlayerJob = { job = nil, grade = nil }
local JobData = Config.Jobs.Bahama
local ClockedIn = false
local OvenStatus = { baking = false, type = nil, fire = false, timer = 0 }
local AllowInteraction = true
local ActiveFire = nil
polePoints = {}
Citizen.CreateThread(function()
    while not NetworkIsSessionStarted() do
        Wait(500)
    end

    BahamaInit()
end)

function DrawText3Ds(x, y, z, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)

    if onScreen then
        SetTextScale(0.35, 0.35)
        SetTextFont(4)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 215)
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end

LastPole = nil
Dancing = false
function BahamaInit()
    for k, v in pairs(JobData.PedList) do
        local npc = NPC.new(v)
        npc:Spawn()
    end

    for _, v in ipairs(JobData.Poles) do
        local polePoints = lib.points.new({
            coords = v.position,
            distance = 3.0,
        })
        polePoints[#polePoints + 1] = v
    end

    lib.registerContext({
        id = 'dance_menu_pole',
        title = 'Select Your Dance',
        options = {
            { title = 'Dance Options' }, {
                title = 'Pole Dance #1',
                icon = 'shoe-prints',
                event = 'bm_dance:start',
                args = { dance = 1 }
            }, {
                title = 'Pole Dance #2',
                icon = 'shoe-prints',
                event = 'bm_dance:start',
                args = { dance = 2 }
            }, {
                title = 'Pole Dance #3',
                icon = 'shoe-prints',
                event = 'bm_dance:start',
                args = { dance = 3 }
            }
        }
    })

    lib.registerContext({
        id = "dance_menu_lap",
        title = "Select your dance",
        options = { {
                        title = 'Lap Dance #1',
                        icon = 'shoe-prints',
                        event = 'bm_dance:start',
                        args = {
                            lapdance = 1,
                            anim = 'lap_dance_girl',
                            dict = 'mp_safehouse'
                        }
                    }, {
                        title = 'Lap Dance #2',
                        icon = 'shoe-prints',
                        event = 'bm_dance:start',
                        args = {
                            lapdance = 2,
                            anim = 'priv_dance_idle',
                            dict = 'mini@strip_club@private_dance@idle'
                        }
                    }, {
                        title = 'Lap Dance #3',
                        icon = 'shoe-prints',
                        event = 'bm_dance:start',
                        args = {
                            lapdance = 3,
                            anim = 'priv_dance_p1',
                            dict = 'mini@strip_club@private_dance@part1'
                        }
                    }, {
                        title = 'Lap Dance #4',
                        icon = 'shoe-prints',
                        event = 'bm_dance:start',
                        args = {
                            lapdance = 4,
                            anim = 'priv_dance_p2',
                            dict = 'mini@strip_club@private_dance@part2'
                        }
                    }, {
                        title = 'Lap Dance #5',
                        icon = 'shoe-prints',
                        event = 'bm_dance:start',
                        args = {
                            lapdance = 5,
                            anim = 'priv_dance_p3',
                            dict = 'mini@strip_club@private_dance@part3'
                        }
                    }, {
                        title = 'Lap Dance #6',
                        icon = 'shoe-prints',
                        event = 'bm_dance:start',
                        args = {
                            lapdance = 6,
                            anim = 'yacht_ld_f',
                            dict = 'oddjobs@assassinate@multi@yachttarget@lapdance'
                        }

                    }
        } })

    for k, v in pairs(JobData.MoneyPlaces) do
        local params = {
            coords = v.coords,
            size = vec3(1, 1, 1),
            rotation = v.heading,
            onEnter = function()
                exports['okokTextUI']:Open('[E] to make it rain', 'darkblue', 'right')
            end,
            onExit = function()
                exports['okokTextUI']:Close()
            end,
            inside = function()
                if IsControlJustPressed(0, 38) then
                    exports['okokTextUI']:Close()
                    local allowed = BahamaRain()
                    if allowed == false then
                        ESX.ShowNotification("Not enough cash")
                        return
                    end
                    local asset = "scr_xs_celebration"
                    RequestNamedPtfxAsset(asset)
                    while not HasNamedPtfxAssetLoaded(asset) do
                        RequestNamedPtfxAsset(asset)
                        Wait(10)
                    end
                    UseParticleFxAssetNextCall(asset)
                    local cash = CreateObject(GetHashKey("prop_anim_cash_pile_01"), 0, 0, 0, true, true, true)
                    AttachEntityToEntity(cash, GetPlayerPed(-1), GetPedBoneIndex(GetPlayerPed(-1), 60309), 0.0, 0.0, 0.0, 180.0, 0.0, 70.0, true, true, false, true, 1, true)
                    local liba, anim = 'anim@mp_player_intupperraining_cash', 'idle_a'
                    Citizen.Wait(900)
                    local p = promise:new()
                    local Ptfx, Ptfx1, Ptfx2 = nil, nil, nil
                    ESX.Streaming.RequestAnimDict(liba, function()
                        TaskPlayAnim(PlayerPedId(), liba, anim, 8.0, -1, -1, 1, 0, false, false, false);
                        Citizen.Wait(1000)

                        Ptfx = StartNetworkedParticleFxLoopedOnEntityBone("scr_xs_money_rain", PlayerPedId(), 0.0, 0.3, 0.45, -50.0, 0.0, 0.0, GetEntityBoneIndexByName("scr_xs_money_rain", "VFX"), 1.0, 1065353216, 0, 0, 0, 1065353216, 1065353216, 1065353216, 0)
                        SetParticleFxLoopedColour(Ptfx, 1.0, 1.0, 1.0)
                        Citizen.Wait(100)
                        RequestNamedPtfxAsset(asset)
                        while not HasNamedPtfxAssetLoaded(asset) do
                            RequestNamedPtfxAsset(asset)
                            Wait(10)
                        end
                        UseParticleFxAssetNextCall(asset)
                        Ptfx1 = StartNetworkedParticleFxLoopedOnEntityBone("scr_xs_money_rain", PlayerPedId(), 0.0, 0.3, 0.45, -50.0, 0.0, 0.0, GetEntityBoneIndexByName("scr_xs_money_rain", "VFX"), 1.0, 1065353216, 0, 0, 0, 1065353216, 1065353216, 1065353216, 0)
                        SetParticleFxLoopedColour(Ptfx1, 1.0, 1.0, 1.0)
                        Citizen.Wait(100)
                        RequestNamedPtfxAsset(asset)
                        while not HasNamedPtfxAssetLoaded(asset) do
                            RequestNamedPtfxAsset(asset)
                            Wait(10)
                        end

                        p:resolve()
                        --UseParticleFxAssetNextCall(asset)
                        --Ptfx2 = StartNetworkedParticleFxLoopedOnEntityBone("scr_xs_money_rain", PlayerPedId(), 0.0, 0.3, 0.45, -50.0, 0.0, 0.0, GetEntityBoneIndexByName("scr_xs_money_rain", "VFX"), 1.0, 1065353216, 0, 0, 0, 1065353216, 1065353216, 1065353216, 0)
                        --SetParticleFxLoopedColour(Ptfx2, 1.0, 1.0, 1.0)

                        --local fx = StartParticleFxNonLoopedOnEntity(, PlayerPedId(),0.0, 0.0, -0.09, -80.0, 0.0, 0.0, 1.0, false, false, false)  --(effectName, entity, offsetX, offsetY, offsetZ, rotX, rotY, rotZ, scale, axisX, axisY, axisZ);
                    end)
                    Citizen.Await(p)
                    -- print("handles are", Ptfx, Ptfx1)
                    if lib.progressBar({
                        duration = 12000,
                        label = 'Making it Rain!!',
                        useWhileDead = false,
                        canCancel = false,
                        disable = {
                            car = true,
                        },
                    }) then
                        DeleteEntity(cash)
                        StopParticleFxLooped(Ptfx, false)
                        StopParticleFxLooped(Ptfx1, false)
                        ClearPedTasksImmediately(PlayerPedId())
                        exports['okokTextUI']:Open('[E] to make it rain', 'darkblue', 'right')
                    else
                        --print('Do stuff when cancelled')
                    end

                end

            end

        }
        lib.zones.box(params)
    end

    for k, v in pairs(JobData.Poles) do
        if v.spawn then
            lib.requestModel('prop_strip_pole_01')
            local pole = CreateObject(joaat('prop_strip_pole_01'), v.position.x, v.position.y, v.position.z, false, false,
                    false)
            poleProps[#poleProps + 1] = pole
        end

        local point = lib.points.new({
            coords = vec3(v.position.x, v.position.y, v.position.z),
            distance = 1.5,
        })
        local params = {
            coords = vec3(v.position.x, v.position.y, v.position.z + 1.0),
            size = vec3(1, 1, 1),
            rotation = v.position.w,
            onEnter = function()
                exports['okokTextUI']:Open('[E] to Dance', 'darkblue', 'right')

            end,
            inside = function()
                if IsEntityPlayingAnim(cache.ped, 'mini@strip_club@pole_dance@pole_dance1', 'pd_dance_01', 3) or IsEntityPlayingAnim(cache.ped, 'mini@strip_club@pole_dance@pole_dance2', 'pd_dance_02', 3) or IsEntityPlayingAnim(cache.ped, 'mini@strip_club@pole_dance@pole_dance3', 'pd_dance_03', 3) then
                    exports['okokTextUI']:Close()
                    -- exports['okokTextUI']:Open('[X] Stop Dancing', 'darkblue', 'right')
                    if IsControlJustPressed(0, 73) then
                        ClearPedTasks(cache.ped)
                        exports['okokTextUI']:Close()
                    end
                end
                if IsControlJustReleased(0, 38) then
                    exports['okokTextUI']:Close()
                    lib.showContext('dance_menu_pole')

                end
            end,
            onExit = function()
                exports['okokTextUI']:Close()
            end,
            debug = Config.Debug,
        }
        local poleZone = lib.zones.box(params)
        polePoints[#polePoints + 1] = poleZone
    end
end

function BahamaRain()
    local players = ESX.Game.GetPlayersInArea(GetEntityCoords(PlayerPedId()), 3.0)

    local tmp = {}

    local coords = GetEntityCoords(PlayerPedId())
    for k, v in pairs(players) do
        local serverId = GetPlayerServerId(v)
        table.insert(tmp, serverId)
    end

    local p = promise:new()

    ESX.TriggerServerCallback("bahama:canrain", function(can)
        p:resolve(can)
    end, tmp)
    return Citizen.Await(p)
end

AddEventHandler("bm_dance:start", function(args)
    local position = GetEntityCoords(cache.ped)
    local usePolePosition = true
    if not args.coords then
        args.coords = position
    end
    if args.dance then
        local nearbyObjects = lib.getNearbyObjects(args.coords, 3.0)
        local pole = nil
        for k, v in pairs(nearbyObjects) do
            -- print("located", json.encode(v, { indent = true }))
            local model = GetEntityModel(v.object)
            if model == GetHashKey('prop_strip_pole_01') then
                pole = v
                break
            end
        end
        if nearbyObjects and not usePolePosition then
            local closestObject = pole
            if closestObject then
                local scene = NetworkCreateSynchronisedScene(closestObject.coords.x + 0.07, closestObject.coords.y + 0.3,
                        closestObject.coords.z + 1.15, 0.0, 0.0, 0.0, 2, false, true, 1065353216, 0, 1.3)
                NetworkAddPedToSynchronisedScene(cache.ped, scene, 'mini@strip_club@pole_dance@pole_dance' .. args.dance,
                        'pd_dance_0' .. args.dance, 1.5, -4.0, 1, 1, 1148846080, 0)
                NetworkStartSynchronisedScene(scene)
            else
                --lib.notify({
                --    title = 'Error',
                --    description = json.encode(args, { indent = true }),
                --    type = 'error'
                --})
            end

        else
            if usePolePosition then
                local closestPoint = lib.points.getClosestPoint()
                if closestPoint then
                    if Config.Debug then
                        --print('Close')
                    end
                    args.coords = closestPoint.coords

                    local scene = NetworkCreateSynchronisedScene(args.coords.x + 0.07, args.coords.y + 0.3,
                            args.coords.z + 1.15, 0.0, 0.0, 0.0, 2, false, true, 1065353216, 0, 1.3)
                    NetworkAddPedToSynchronisedScene(cache.ped, scene, 'mini@strip_club@pole_dance@pole_dance' .. args.dance,
                            'pd_dance_0' .. args.dance, 1.5, -4.0, 1, 1, 1148846080, 0)
                    NetworkStartSynchronisedScene(scene)
                else
                    lib.notify({
                        title = 'Error 2',
                        description = 'Error 2',
                        type = 'error',
                    })
                    if Config.Debug then
                        --print('Not close')
                    end
                end
            end
            usePolePosition = true
        end
    elseif args.lapdance then
        lib.requestAnimDict(args.dict)
        TaskPlayAnim(cache.ped, args.dict, args.anim, 1.0, 1.0, -1, 1, 0, 0, 0, 0)
    else
        for _, point in ipairs(polePoints) do
            local distance = #(point.coords - GetEntityCoords(cache.ped))
            if distance <= point.distance then
                usePolePosition = true
                break
            end
        end
    end

end)

function DispMarker(location)
    Citizen.CreateThread(function()
        while LastPole ~= nil do
            Citizen.Wait(0)
            DrawText3Ds(location.x, location.y, location.z, "[E] - Dance")
            if IsControlJustReleased(0, 38) then
                TriggerServerEvent("esx_societyjobs:bahama:doDance", LastPole)
                Dancing = true
            end
        end
    end)
end

function GetBahama(type)
    for i = 1, #JobData.CookableItems do
        if (type == JobData.CookableItems[i].Name) then
            return JobData.CookableItems[i]
        end
    end
end

function BahamaGetBahamasMenu()
    local menu = {
        {
            id = 1,
            header = "Drinks",
            txt = "This is where you can make any drink. Don't forget the ingredients!"
        },
    }
    for i = 1, #JobData.CookableItems do
        local data = JobData.CookableItems
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "bake_bahama",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function BahamaGetDrinksMenu()
    local menu = {
        {
            id = 1,
            header = "Drink Fountain",
            txt = "This is where you can pour any drinks for a fee."
        },
    }
    for i = 1, #JobData.Drinks do
        local data = JobData.Drinks
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "bahama_drink",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function BahamaGetIngredientsMenu()
    local menu = {
        {
            id = 1,
            header = "Bahama Ingredients",
            txt = "This is where you can grab any ingredients for your bahama. Don't forget the cheese and sauce!"
        },
    }
    for i = 1, #JobData.Ingredients do
        local data = JobData.Ingredients
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label .. " - $" .. data[i].Price,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "bahama_ingredients",
                    data = {
                        selected = data[i].Name,
                    }
                }
            }
        }
    end
    return menu
end

function BahamaGatherAnim()
    LoadAnim('mini@repair')
    TaskPlayAnim(PlayerPedId(), 'mini@repair', 'fixing_a_player', 8.0, -8, -1, 49, 0, 0, 0, 0)
end

function BahamaStartFire(coords)
    -- Make some variables for the particle dictionary and particle name.
    local dict = "scr_trevor3"
    local particleName = "scr_trev3_trailer_plume"

    -- Create a new thread.
    Citizen.CreateThread(function()
        -- Request the particle dictionary.
        RequestNamedPtfxAsset(dict)
        -- Wait for the particle dictionary to load.
        while not HasNamedPtfxAssetLoaded(dict) do
            Citizen.Wait(0)
        end
        UseParticleFxAssetNextCall(dict)
        -- Create a new non-looped particle effect, we don't need to store the particle handle because it will
        -- automatically get destroyed once the particle has finished it's animation (it's non-looped).
        ActiveFire = StartParticleFxLoopedAtCoord(particleName, coords.x, coords.y, coords.z, 0.0, 0.0, 0.0, 0.2, false, false, false)
    end)
end

function BahamaStopFire()
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Extinguishing Fire", 'mini@repair', 'fixing_a_player')
        BahamaGatherAnim()
        Citizen.SetTimeout(5000, function()
            ClearPedTasksImmediately(PlayerPedId())
            StopParticleFxLooped(ActiveFire, true)
            ActiveFire = false
            AllowInteraction = true
        end)
    end)
end

function BahamaStartBaking(type)
    if (not OvenStatus.baking and OvenStatus.type == nil) then
        OvenStatus.baking = true
        OvenStatus.type = type
        OvenStatus.timer = JobData.BahamaCookTime
        Citizen.CreateThread(function()
            while OvenStatus.type ~= nil do
                OvenStatus.timer = OvenStatus.timer - 1
                if (OvenStatus.timer == 0) then
                    OvenStatus.baking = false
                end
                if (OvenStatus.timer <= -JobData.OvercookedTime) then
                    OvenStatus.baking = false
                    OvenStatus.type = nil
                    OvenStatus.timer = 0
                    OvenStatus.fire = true
                    BahamaStartFire(JobData.InteractMarkers["bahama_oven"].Coords)
                    break
                end
                Citizen.Wait(1000)
            end
        end)
    end
end

function BahamaMakeDough()
    Citizen.CreateThread(function()
        AllowInteraction = false
        DisplayProgress(5000, "Making Bahama Dough", 'mini@repair', 'fixing_a_player')
        BahamaGatherAnim()
        Citizen.Wait(5000)
        ClearPedTasksImmediately(PlayerPedId())
        TriggerServerEvent("esx_societyjobs:bahama:craftDough")
        AllowInteraction = true
    end)
end

function BahamaToggleDuty(bool)
    ClockedIn = bool
    if (ClockedIn) then
        BahamaSetMarkerDisplay("wash_hands", false)
        BahamaSetMarkerDisplay("clock_out", false)
        BahamaSetMarkerDisplay("boss", false)
        BahamaSetMarkerDisplay("bahama_ingredients", true)
        BahamaSetMarkerDisplay("bahama_oven", false)
    else
        BahamaSetMarkerDisplay("wash_hands", true)
        BahamaSetMarkerDisplay("clock_out", false)
        BahamaSetMarkerDisplay("boss", true)
        BahamaSetMarkerDisplay("bahama_ingredients", false)
        BahamaSetMarkerDisplay("bahama_oven", false)
    end
end

function BahamaSetMarkerDisplay(key, bool)
    JobData.InteractMarkers[key].Display = bool
end

function BahamaGetMarkerText(key)
    local text = JobData.InteractMarkers[key].DisplayText
    if (key == "bahama_oven") then
        if OvenStatus.baking then
            text = text:gsub("|oven_status|", "Timer: " .. OvenStatus.timer .. " second(s)")
        elseif OvenStatus.type ~= nil then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to take out the " .. GetBahama(OvenStatus.type).Label .. ".")
        elseif OvenStatus.fire then
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to extinguish the fire.")
        else
            text = text:gsub("|oven_status|", "Press ~INPUT_CONTEXT~ to use bar.")
        end
    end
    return text
end

function BahamaInteractMarker(key)
    AllowInteraction = false
    local marker = JobData.InteractMarkers[key]
    if (key == "boss") then
        OpenSocietyJobBossMenu()
    elseif (key == "clock_out") then
        BahamaToggleDuty(false)
    elseif (key == "wash_hands") then
        Citizen.CreateThread(function()
            AllowInteraction = false
            DisplayProgress(5000, "Washing Hands", 'mini@repair', 'fixing_a_player')
            BahamaGatherAnim()
            Citizen.Wait(5000)
            ClearPedTasksImmediately(PlayerPedId())
            BahamaToggleDuty(true)
            AllowInteraction = true
        end)
    elseif (key == "bahama_ingredients") then
        TriggerEvent('nh-context-bridge:sendMenu', BahamaGetIngredientsMenu())
    elseif (key == "bahama_oven") then
        if (OvenStatus.fire) then
            OvenStatus.fire = false
            BahamaStopFire()
        elseif (not OvenStatus.baking and OvenStatus.type ~= nil) then
            local bahamaType = OvenStatus.type
            OvenStatus.type = nil
            OvenStatus.timer = 0
            OvenStatus.fire = false
            Citizen.CreateThread(function()
                AllowInteraction = false
                DisplayProgress(5000, "Taking Bahama out of Oven", 'mini@repair', 'fixing_a_player')
                BahamaGatherAnim()
                Citizen.Wait(5000)
                ClearPedTasksImmediately(PlayerPedId())
                TriggerServerEvent("esx_societyjobs:bahama:cookedBahama", bahamaType)
                AllowInteraction = true
            end)
        elseif (not OvenStatus.baking and OvenStatus.type == nil) then
            TriggerEvent('nh-context-bridge:sendMenu', BahamaGetBahamasMenu())
        end
    end
    AllowInteraction = true
end

function BahamaThread()
    Citizen.CreateThread(function()
        while true do
            local wait = 1000
            local coords = GetPlayerCoords()
            for k, v in pairs(JobData.InteractMarkers) do
                if (v.Display or v.Display == nil) then
                    local dist = #(v.Coords - coords)
                    if (dist < 20.0) then
                        wait = 0
                        if (Marker(v.Coords, dist, BahamaGetMarkerText(k)) and AllowInteraction) then
                            BahamaInteractMarker(k)
                        end
                    end
                end
            end
            Citizen.Wait(wait)
        end
    end)
end

RegisterNetEvent("nh-context:returnData")
AddEventHandler("nh-context:returnData", function(_data)
    local key = _data.id
    local data = _data.data
    if (key == "bahama_ingredients") then
        Citizen.CreateThread(function()
            ESX.TriggerServerCallback("esx_societyjobs:bahama:purchaseIngredient", function(result)
                if (result) then
                    Citizen.CreateThread(function()
                        AllowInteraction = false
                        DisplayProgress(5000, "Grabbing Ingredient", 'mini@repair', 'fixing_a_player')
                        BahamaGatherAnim()
                        Citizen.Wait(5000)
                        ClearPedTasksImmediately(PlayerPedId())
                        AllowInteraction = true
                    end)
                else
                    ESX.ShowNotification("You cannot afford this ingredient.")
                end
            end, data.selected)
        end)
    elseif (key == "bake_bahama") then
        AllowInteraction = false
        ESX.TriggerServerCallback("esx_societyjobs:bahama:bakeBahama", function(result)
            if (result) then
                Citizen.CreateThread(function()
                    DisplayProgress(5000, "Putting food into Oven", 'mini@repair', 'fixing_a_player')
                    BahamaGatherAnim()
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    BahamaStartBaking(result)
                    AllowInteraction = true
                end)
            else
                ESX.ShowNotification("Missing Ingredients for the Bahama.")
                AllowInteraction = true
            end
        end, data.selected)
    elseif (key == "bahama_drink") then
        AllowInteraction = false
        ESX.TriggerServerCallback("esx_societyjobs:bahama:getDrink", function(result)
            if (result) then
                Citizen.CreateThread(function()
                    DisplayProgress(5000, "Pouring Drink", 'mini@repair', 'fixing_a_player')
                    BahamaGatherAnim()
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    AllowInteraction = true
                end)
            else
                ESX.ShowNotification("You cannot afford the drink.")
                AllowInteraction = true
            end
        end, data.selected)
    end
end)

RegisterNetEvent('esx_societyjobs:jobUpdated')
AddEventHandler('esx_societyjobs:jobUpdated', function(job)
    if (not CurrentPlayerJob.job or (CurrentPlayerJob.job ~= job.name or CurrentPlayerJob.grade ~= job.grade)) then
        if (CurrentPlayerJob.job ~= job.name and job.name == "bahama") then
            BahamaToggleDuty(false)
        elseif (job.name == "unemployed") then
            BahamaToggleDuty(false)
            BahamaSetMarkerDisplay("wash_hands", false)
        end
        CurrentPlayerJob.job = job.name
        CurrentPlayerJob.grade = job.grade
    end
end)

OnScriptStarted(BahamaThread)
