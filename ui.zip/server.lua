

ESX = exports["es_extended"]:getSharedObject()

local function GetPlayer(source)
    return ESX.GetPlayerFromId(source)
end

local function HasItem(source, item)
    local data = exports.ox_inventory:GetItem(source, item)
    return data and data.count or 0
end

local function RemoveItem(source, item, amount)
    local data = exports.ox_inventory:GetItem(source, item)
    if not data or data.count < amount then 
        print("[DEBUG] Player does not have enough ".. item .." to remove.")
        return false 
    end
    local success = exports.ox_inventory:RemoveItem(source, item, amount)
    if success then
        print("[DEBUG] Successfully removed ".. amount .." of ".. item)
    else
        print("[DEBUG] Failed to remove ".. amount .." of ".. item)
    end
    return success
end

local function GiveItem(source, item, amount)
    -- We will NOT check CanCarryItem since ox_inventory does not have it
    local success = exports.ox_inventory:AddItem(source, item, amount)
    if success then
        print("[DEBUG] Successfully gave ".. amount .." of ".. item)
    else
        print("[DEBUG] Failed to give ".. amount .." of ".. item)
    end
    return success
end

local function getSocietyMoney(society)
    local money = nil
    TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
        money = account.money
    end)
    while money == nil do Citizen.Wait(0) end
    return money
end

local function addSocietyMoney(society, amount)
    TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
        account.addMoney(amount)
    end)
end

local function removeSocietyMoney(society, amount)
    TriggerEvent('esx_addonaccount:getSharedAccount', society, function(account)
        account.removeMoney(amount)
    end)
end

RegisterServerEvent('crafting:server:main:mech', function(item)
    local source = source
    local xPlayer = GetPlayer(source)
    local itemName = item.item
    local hasIngredients = true
    local missingIngredients = ""

    print("[DEBUG] Player is attempting to craft: ".. itemName)

    if not Config.craftingMenu[itemName] then
        print("[ERROR] Item ".. itemName .." is not in Config.craftingMenu!")
        return
    end

    -- Check if the player has enough of each required item
    for _, ingredient in ipairs(Config.craftingMenu[itemName]) do
        local playerItemCount = HasItem(source, ingredient.item)
        if playerItemCount < ingredient.amount then
            hasIngredients = false
            local missingAmount = ingredient.amount - playerItemCount
            missingIngredients = missingIngredients .. missingAmount .. "x " .. ingredient.item .. ", "
        end
    end

    if hasIngredients then
        -- Remove ingredients from inventory
        for _, ingredient in ipairs(Config.craftingMenu[itemName]) do
            if not RemoveItem(source, ingredient.item, ingredient.amount) then
                print("[ERROR] Failed to remove ".. ingredient.amount .." of ".. ingredient.item)
                TriggerClientEvent('esx:showNotification', source, 'Error: Failed to remove '.. ingredient.item)
                return
            end
        end

        -- Give crafted item
        if GiveItem(source, itemName, 1) then
            TriggerClientEvent('esx:showNotification', source, 'You crafted: ' .. itemName)
        else
            print("[ERROR] Failed to give crafted item: ".. itemName)
        end
    else
        missingIngredients = string.sub(missingIngredients, 1, -3) -- Remove trailing ", "
        TriggerClientEvent('esx:showNotification', source, 'Missing: ' .. missingIngredients)
    end
end)

