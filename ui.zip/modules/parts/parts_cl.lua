local AllowInteraction = true
local Working = false

function ShowPartStore(k)
    local part = PartStores[k]
    local menu = {
        {
            id = 1,
            header = part.menu.label,
            txt = part.menu.text
        },
    }
    for i = 1, #part.items do
        local data = part.items[i]
        menu[#menu + 1] = {
            id = i + 1,
            header = data.Label .. " - $" .. data.Price,
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = k,
                    data = {
                        selected = data.Name,
                        index = i
                    }
                }
            }
        }
    end
    TriggerEvent('nh-context-bridge:sendMenu', menu)
end

function InteractPartStore(k)
    ShowPartStore(k)
end

RegisterNetEvent("nh-context:returnData")
AddEventHandler("nh-context:returnData", function(_data)
    local key = _data.id
    local data = _data.data

    if PartStores[key] then
        Working = true
        ESX.TriggerServerCallback("esx_societyjobs:parts:purchasePart", function(result, token)
            if result then
                Citizen.CreateThread(function()
                    AllowInteraction = false
                    DisplayProgress(5000, "Grabbing Part", 'mini@repair', 'fixing_a_player')
                    
                    if PartStores[key].items[data.index].Emote then
                        if PartStores[key].heading then
                            SetEntityHeading(PlayerPedId(), PartStores[key].heading)
                        end
                        OnEmotePlay(Config.Emotes[PartStores[key].items[data.index].Emote])
                    else
                        LoadAnim('mini@repair')
                        TaskPlayAnim(PlayerPedId(), 'mini@repair', 'fixing_a_player', 8.0, -8, -1, 49, 0, 0, 0, 0)
                    end
                    
                    Citizen.Wait(5000)
                    ClearPedTasksImmediately(PlayerPedId())
                    DestroyAllProps()
                    AllowInteraction = true
                    Working = false
                    
                    -- **FIX: Ensure the correct server event is triggered**
                    TriggerServerEvent("esx_societyjobs:parts:givePart", token, data.selected)

                end)
            else
                TriggerEvent('okokNotify:Alert', "Error", "Part purchase failed.", 5000, 'error')
                Working = false
            end
        end, key, data.selected)
    end
end)

Citizen.CreateThread(function()
    while true do
        local cTables = PartStores
        local waitTimer = 1000
        local coords = GetEntityCoords(PlayerPedId())

        for k, v in pairs(cTables) do
            local dist = #(v.coords - coords)
            if dist < 20.0 and Working == false then
                waitTimer = 0
                if AllowInteraction and Marker(v.coords, dist, v.interact or "Press ~INPUT_CONTEXT~ to open the parts store.") then
                    InteractPartStore(k)
                end
            end
        end
        Citizen.Wait(waitTimer)
    end
end)
