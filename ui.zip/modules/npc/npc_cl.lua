---@class NPCConfig
---@field name string
---@field model string | number
---@field coords table
---@field heading number
---@field gender '"male"' | '"female"'
---@field animation string|table

function LoadModel(model)
    if not IsModelInCdimage(model) then return end

    RequestModel(model)
    local started = GetGameTimer()
    while not HasModelLoaded(model) do
        Citizen.Wait(0)
        if GetGameTimer() - started > 10000 then
            print('Failed to load model: ' .. model)
            return
        end
    end
end

---@class NPC
---@field Handle number
---@field Name string
---@field Model number
---@field Coords table
---@field Heading number
---@field Gender '"male'" | '"female'"
NPC = setmetatable({}, NPC)

NPC.__index = NPC

function LoadAnimDict(dict)
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Citizen.Wait(0)
    end
end

---@param config NPCConfig
function NPC.new(config)
    local _NPC = {
        Handle = nil,
        Name = config.name,
        Model = type(model) == 'string' and GetHashKey(config.model) or config.model,
        Coords = config.coords,
        Heading = config.heading,
        Gender = config.gender,
        Animation = config.animation
    }

    return setmetatable(_NPC, NPC)
end

function NPC:Spawn()
    LoadModel(self.Model)
    local ped = CreatePed(4, self.Model, self.Coords.x, self.Coords.y, self.Coords.z, self.Heading, false, true)
    SetModelAsNoLongerNeeded(self.Model)
    SetEntityHeading(ped, self.Heading)
    self.Handle = ped

    SetBlockingOfNonTemporaryEvents(self.Handle, true)
    SetEntityAsMissionEntity(self.Handle, 1, 1)
    FreezeEntityPosition(self.Handle, true)
    SetEntityInvincible(self.Handle, true)
    SetEntityCanBeDamaged(self.Handle, 0)
    SetPedAsEnemy(self.Handle, 0)
    SetBlockingOfNonTemporaryEvents(self.Handle, 1)
    SetPedResetFlag(self.Handle, 249, 1)
    SetPedConfigFlag(self.Handle, 185, true)
    SetPedConfigFlag(self.Handle, 108, true)
    SetPedCanEvasiveDive(self.Handle, 0)
    SetPedCanRagdollFromPlayerImpact(self.Handle, 0)
    SetPedConfigFlag(self.Handle, 208, true)

    if type(self.Animation) == "string" then
        TaskStartScenarioInPlace(ped, self.Animation, 0, true)
    end

    if type(self.Animation) == "table" then
        if #self.Animation ~= 2 then
            print('Invalid animation table')
            return
        end

        local anim = self.Animation[2]
        local dict = self.Animation[1]

        LoadAnimDict(dict)

        TaskPlayAnim(ped, dict, anim, 8.0, 8.0, -1, 1, 0, 0, 0, 0)
        RemoveAnimDict(dict)
    end
end
