Citizen.CreateThread(function()
    while true do
        local wait = 1000
        local coords = GetPlayerCoords()
        for k,v in pairs(BossMenus) do 
            local dist = #(v.Coords - coords)
            if (dist < 20.0) then 
                wait = 0
                if (Marker(v.Coords, dist, "Press ~INPUT_CONTEXT~ to open the boss menu.")) then 
                    OpenSocietyJobBossMenu()
                end
            end
        end
        Citizen.Wait(wait)
    end
end)