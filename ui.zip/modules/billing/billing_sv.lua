ESX = exports["es_extended"]:getSharedObject()

RegisterNetEvent("esx_societyjobs:billing:sendBill", function(k, target, amount)
    local src = source
    local xPlayer = ESX.GetPlayerFromId(src)
    local xTarget = ESX.GetPlayerFromId(target)
    local register = BillingRegisters[k]
    if not register or not xTarget then return end

    amount = tonumber(amount)
    if not amount or amount <= 0 then
        TriggerClientEvent('okokNotify:Alert', src, "Error", "Invalid billing amount.", 5000, 'error')
        return
    end

    if exports.ox_inventory:GetItemCount(target, 'money') < amount then
        TriggerClientEvent('okokNotify:Alert', src, "Error", "The person does not have enough money.", 5000, 'error')
        return
    end

    -- Deduct money from target
    exports.ox_inventory:RemoveItem(target, 'money', amount)
    
    -- Add money to the society account
    TriggerEvent('esx_addonaccount:getSharedAccount', 'society_' .. register.job, function(account)
        if account then
            account.addMoney(amount)
        end
    end)

    TriggerClientEvent('okokNotify:Alert', target, "Billing", "You have been billed $" .. amount .. " by " .. xPlayer.getName(), 5000, 'info')
    TriggerClientEvent('okokNotify:Alert', src, "Success", "You billed " .. xTarget.getName() .. " for $" .. amount .. ".", 5000, 'success')
end)
