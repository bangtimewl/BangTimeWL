Config = {}

Config.Jobs = {}

Config.Jobs.Showcase = {
    Locations = {
        [1] = { coords = vector3(-439.0587, -31.56981, 46.10)}, 
        [2] = { coords = vector3(-442.081, -36.32952, 46.10)}, 
        [3] = { coords = vector3(-436.4703, -36.62119, 46.10)},
		
    },
    Items = {
        {
            name = "watch_01",
            label = "Watch 1",
            price = 320000,
            purchasable = true
        },
        {
            name = "watch_02",
            label = "Watch 2",
            price = 320000,
            purchasable = true
        },
        {
            name = "watch_03",
            label = "Watch 3",
            price = 320000,
            purchasable = true
        },
        {
            name = "watch_04",
            label = "Watch 4",
            price = 375000,
            purchasable = true
        },
        {
            name = "watch_05",
            label = "Watch 5",
            price = 220000,
            purchasable = true
        },
        {
            name = "watch_06",
            label = "Watch 6",
            price = 220000,
            purchasable = true
        },
        {
            name = "watch_07",
            label = "Watch 7",
            price = 220000,
            purchasable = true
        },
        {
            name = "watch_08",
            label = "Watch 8",
            price = 750000,
            purchasable = true
        },		
        {
            name = "watch_09",
            label = "Watch 9",
            price = 750000,
            purchasable = true
        },
        {
            name = "watch_10",
            label = "Watch 10",
            price = 750000,
            purchasable = true
        },
        {
            name = "watch_11",
            label = "Watch 11",
            price = 200000,
            purchasable = true
        },
        {
            name = "watch_12",
            label = "Watch 12",
            price = 200000,
            purchasable = true
        },
        {
            name = "watch_13",
            label = "Watch 13",
            price = 200000,
            purchasable = true
        },
        {
            name = "watch_14",
            label = "Watch 14",
            price = 200000,
            purchasable = true
        },
        {
            name = "watch_15",
            label = "Watch 15",
            price = 3000000,
            purchasable = true
        },	
        {
            name = "watch_16",
            label = "Watch 16",
            price = 3000000,
            purchasable = true
        },
        {
            name = "watch_17",
            label = "Watch 17",
            price = 3000000,
            purchasable = true
        },
        {
            name = "watch_18",
            label = "Watch 18",
            price = 3000000,
            purchasable = true
        },	
        {
            name = "watch_19",
            label = "Watch 19",
            price = 275000,
            purchasable = true
        },
        {
            name = "watch_20",
            label = "Watch 20",
            price = 275000,
            purchasable = true
        },
        {
            name = "watch_21",
            label = "Watch 21",
            price = 275000,
            purchasable = true
        },		
        {
            name = "watch_22",
            label = "Watch 22",
            price = 200000,
            purchasable = true
        },
        {
            name = "watch_23",
            label = "Watch 23",
            price = 200000,
            purchasable = true
        },
        {
            name = "watch_24",
            label = "Watch 24",
            price = 200000,
            purchasable = true
        },
        {
            name = "watch_25",
            label = "Watch 25",
            price = 350000,
            purchasable = true
        },	
        {
            name = "watch_26",
            label = "Watch 26",
            price = 350000,
            purchasable = true
        },	
        {
            name = "watch_27",
            label = "Watch 27",
            price = 350000,
            purchasable = true
        },		
        {
            name = "watch_28",
            label = "Watch 28",
            price = 2000000,
            purchasable = true
        },	
        {
            name = "watch_29",
            label = "Watch 29",
            price = 2000000,
            purchasable = true
        },	
        {
            name = "watch_30",
            label = "Watch 30",
            price = 2000000,
            purchasable = true
        },			
        {
            name = "watch_31",
            label = "Watch 31",
            price = 800000,
            purchasable = true
        },		
        {
            name = "watch_32",
            label = "Watch 32",
            price = 800000,
            purchasable = true
        },
        {
            name = "watch_33",
            label = "Watch 33",
            price = 800000,
            purchasable = true
        },
        {
            name = "watch_34",
            label = "Watch 34",
            price = 800000,
            purchasable = true
        },	
        {
            name = "watch_35",
            label = "Watch 35",
            price = 900000,
            purchasable = true
        },	
        {
            name = "watch_36",
            label = "Watch 36",
            price = 900000,
            purchasable = true
        },	
        {
            name = "watch_37",
            label = "Watch 37",
            price = 900000,
            purchasable = true
        },	
        {
            name = "watch_38",
            label = "Watch 38",
            price = 800000,
            purchasable = true
        },	
        {
            name = "watch_39",
            label = "Watch 39",
            price = 800000,
            purchasable = true
        },	
        {
            name = "watch_40",
            label = "Watch 40",
            price = 800000,
            purchasable = true
        },	
        {
            name = "watch_41",
            label = "Watch 41",
            price = 800000,
            purchasable = true
        },	
        {
            name = "watch_42",
            label = "Watch 42",
            price = 800000,
            purchasable = true
        },	
        {
            name = "watch_43",
            label = "Watch 43",
            price = 800000,
            purchasable = true
        },	
        {
            name = "watch_44",
            label = "Watch 44",
            price = 1000000,
            purchasable = true
        },	
        {
            name = "watch_45",
            label = "Watch 45",
            price = 1000000,
            purchasable = true
        },	
        {
            name = "watch_46",
            label = "Watch 46",
            price = 1000000,
            purchasable = true
        },	
        {
            name = "watch_47",
            label = "Watch 47",
            price = 4200000,
            purchasable = true
        },	
        {
            name = "watch_48",
            label = "Watch 48",
            price = 4200000,
            purchasable = true
        },	
        {
            name = "watch_49",
            label = "Watch 49",
            price = 4200000,
            purchasable = true
        },	
        {
            name = "watch_50",
            label = "Watch 50",
            price = 4000000,
            purchasable = true
        },	
        {
            name = "watch_51",
            label = "Watch 51",
            price = 4000000,
            purchasable = true
        },	
        {
            name = "watch_52",
            label = "Watch 52",
            price = 4000000,
            purchasable = true
        },	
        {
            name = "watch_53",
            label = "Watch 53",
            price = 1000000,
            purchasable = true
        },		
    }
}

Config.Jobs.Showcasezaza = {
    Locations = { 
        [1] = { coords = vector3(189.129, -242.4274, 54.07)} 
		
    },
    Items = {
        {
            name = "zaza_cherryld",
            label = "Zaza Cherry Lemonade",
            price = false,
            purchasable = true
        },		
        {
            name = "zaza_cookncrm",
            label = "Zaza CookiesnCream",
            price = false,
            purchasable = true
        },	
        {
            name = "zaza_gelato",
            label = "Zaza Gelato Pack",
            price = false,
            purchasable = true
        },	
        {
            name = "zaza_greencrack",
            label = "Zaza Green Crack",
            price = false,
            purchasable = true
        },	
        {
            name = "zaza_italice",
            label = "Zaza Italian Ice",
            price = false,
            purchasable = true
        },	
        {
            name = "zaza_sherbet",
            label = "Zaza Sherbet",
            price = false,
            purchasable = true
        },	
        {
            name = "zaza_sprinklez",
            label = "Zaza Sprinklez",
            price = false,
            purchasable = true
        },	
        {
            name = "zaza_zlushie",
            label = "Zaza Zlushie",
            price = false,
            purchasable = true
        },	
        {
            name = "zaza_cookiemstr",
            label = "Zaza Cookies",
            price = false,
            purchasable = true
        },			
    }
}

Config.Jobs.Showcasesmokeys = {
    Locations = { 
        [1] = { coords = vector3(1133.907, -990.8267, 46.11)}
		
    },
    Items = {
        {
            name = "smokeys_aliencookies",
            label = "Smokeys AlienCookies",
            price = false,
            purchasable = true
        },		
        {
            name = "smokeys_applepie",
            label = "Smokeys AppliePie",
            price = false,
            purchasable = true
        },	
        {
            name = "smokeys_bluedream",
            label = "Smokeys BlueDream",
            price = false,
            purchasable = true
        },	
        {
            name = "smokeys_cheesecake",
            label = "Smokeys CheeseCake",
            price = false,
            purchasable = true
        },	
        {
            name = "smokeys_gumball",
            label = "Smokeys Gumball",
            price = false,
            purchasable = true
        },	
        {
            name = "smokeys_orangekrush",
            label = "Smokeys OrangeKrush",
            price = false,
            purchasable = true
        },	
        {
            name = "smokeys_pineappleexpress",
            label = "Smokeys Pineapplexpress",
            price = false,
            purchasable = true
        },	
        {
            name = "smokeys_purplepunch",
            label = "Smokeys PurplePunch",
            price = false,
            purchasable = true
        },	
        {
            name = "smokeys_whitechocolate",
            label = "Smokeys WhiteChocolate",
            price = false,
            purchasable = true
        },		
        {
            name = "smokeys_zkittles",
            label = "Smokeys Zkittles",
            price = false,
            purchasable = true
        },		
        {
            name = "n2o_grape",
            label = "SolarGas (Grape)",
            price = false,
            purchasable = true
        },
        {
            name = "n2o_mango",
            label = "SolarGas (Mango)",
            price = false,
            purchasable = true
        },
        {
            name = "n2o_raspberry",
            label = "SolarGas (Raspberry)",
            price = false,
            purchasable = true
        },
        {
            name = "n2o_strawberry",
            label = "SolarGas (Strawberry)",
            price = false,
            purchasable = true
        },		
        {
            name = "n2o_watermelon",
            label = "SolarGas (Watermelon)",
            price = false,
            purchasable = true
        },			
    }
}

Config.Jobs.Mosleys = {
    Locations = {
        [1] = { coords = vector3(3.73, -1667.1, 28.40)},
    },
    SellLocation = {
        coords = vector3( -8.35, -1655.18, 28.35), -- The place of the menu{ x = -8.35079860687255, y = -1655.1868896484375, z = 29.29161262512207, h = 315.6656494140625 }
        enableBlip = false                        -- If blip should be enabled
    },
    DeleteVehicleTime = 15,
    TyreTime = 15,
    Debug = false,
    EnableBlips = false,
    Parts = {
        [0] = { label = 'Driver Front Door', time = 10, item = {
            enabled = true,
            name = 'battery',
            count = 1,
            chance = 100
        } },
        [1] = { label = 'Passenger Front Door', time = 10, item = {
            enabled = true,
            name = 'subwoofer',
            count = 1,
            chance = 100
        } },
        [2] = { label = 'Driver Rear Door', time = 10, item = { enabled = true, name = 'rims', count = 4, chance = 100 } },
        [3] = { label = 'Passenger Rear Door', time = 10, item = {
            enabled = true,
            name = 'steeringwheel',
            count = 1,
            chance = 100
        } },
        [4] = { label = 'Hood', time = 10, item = { enabled = true, name = 'hood', count = 1, chance = 100 } },
        [5] = { label = 'Trunk', time = 10, item = { enabled = true, name = 'trunk', count = 1, chance = 100 } } -- Time Seconds
    },
    RewardForVehicle = {
        ['Seller'] = false,
        ['Owner']  = 320
    },

    BlackMoney = {
        Enabled = true,
        Account = 'black_money'
    },
    AllowJobs = {
        Jobs = {
            ['mosleys'] = true,
        }
    },
    Items = {
        ['battery'] = 1500,
        ['subwoofer'] = 2500,
        ['trunk'] = 2000,
        ['hood'] = 2000,
        ['steeringwheel'] = 1750,
        ['rims'] = 1800,

    },
    AdditionalItemAmount = 1,

    AdditionalItems = {
        { name = 'id_card',     count = 1, chance = 1 },
        { name = 'laptop',    count = 1, chance = 1 },
        { name = 'lockpick',    count = 1, chance = 3 },
    },
    Shops = {
        ["mosleys"] = {
            InteractMarkers = {
                ["workbench5"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to grab a vehicle part.",
                    Coords = vector3(8.51, -1668.69, 29.377),
                    Display = true,
                },
                ["boss"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
                    Coords = vector3(-1.57, -1657.70, 29.26), --{ { x = 8.51376724243164, y = -1668.6912841796875, z = 29.34246253967285, h = 256.7915344238281 }
                    Display = true,
                },
            },
        }
    },
    VehicleParts5 = {
        {
            Name = "modEngine",
            Label = "Engines",
            ModType = 11,
            Items = {}
        },
        {
            Name = "modTurbo",
            Label = "Turbo",
            ModType = 17,
            Items = {}
        },
        {
            Name = "modBrakes",
            Label = "Brakes",
            ModType = 12,
            Items = {}
        },
        {
            Name = "modSuspension",
            Label = "Suspension",
            ModType = 15,
            Items = {}
        },
        {
            Name = "modTransmission",
            Label = "Transmission",
            ModType = 13,
            Items = {}
        },
        {
            Name = "repair",
            Label = "Repair",
            Items = {}
        },
    },
    CarryingSettings = {
        ["modEngine"] = { "anim@heists@box_carry@", "idle", "Engine", AnimationOptions =
        {
            Prop = "prop_car_engine_01",
            PropBone = 60309,
            PropPlacement = { 0.2, 0.2, 0.08, -55.0, 290.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modArmor"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTurbo"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modBrakes"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modSuspension"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTransmission"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["repair"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
    }
}


Config.Jobs.Pearls = {
    PearlsCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "idrp_shrimp_kebab",
            Label = "Kebab",
            Price = 4,
            RequiredIngredients = { "shrimp", "vegetables" },
        },
        {
            Name = "idrp_sardine_basket",
            Label = "Sardine Basket",
            Price = 4,
            RequiredIngredients = { "sardines", "vegetables" },
        },
        {
            Name = "idrp_lobster_basket",
            Label = "Lobster Basket",
            Price = 4,
            RequiredIngredients = { "lobster" },
        },
        {
            Name = "idrp_clamchowder",
            Label = "Clam Chowder",
            Price = 4,
            RequiredIngredients = { "clams", "soup_base" },
        },
        {
            Name = "idrp_shrimp_cocktail",
            Label = "Cocktail",
            Price = 4,
            RequiredIngredients = { "shrimp", "tomato_sauce" },
        },
        {
            Name = "idrp_pearl_fries",
            Label = "Fries",
            Price = 4,
            RequiredIngredients = { "potato" },
        },
    },
    Drinks = {
        {
            Name = "idrp_pearl_pinejuice",
            Label = "Pineapple Juice",
            Price = 5
        },
        {
            Name = "idrp_pearl_apjuice",
            Label = "Apple Juice",
            Price = 5
        },
        {
            Name = "idrp_pearl_oj",
            Label = "Orange Juice",
            Price = 5
        },
        {
            Name = "idrp_pearl_sparkling",
            Label = "Sparkling Water",
            Price = 5
        },
    },
    Ingredients = {
        {
            Name = "shrimp",
            Label = "Shrimp",
            Price = 4,
        },
        {
            Name = "lobster",
            Label = "Fried Chicken",
            Price = 4,
        },
        {
            Name = "clams",
            Label = "Sandwich Bun",
            Price = 4,
        },
        {
            Name = "sardines",
            Label = "Sardines",
            Price = 4,
        },
        {
            Name = "vegetables",
            Label = "Vegetables",
            Price = 4,
        },
        {
            Name = "tomato_sauce",
            Label = "Tomato Sauce",
            Price = 4,
        },
        {
            Name = "soup_base",
            Label = "Soup Base",
            Price = 4,
        },
        {
            Name = "potato",
            Label = "Potato",
            Price = 4,
        },
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(337.2132, -896.4923, 29.33044),
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(-1842.111, -1192.425, 14.30044),
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(-1841.30, -1181.91, 14.30),
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(-1837.50, -1190.53, 14.30),
            Display = false,
        },
        ["pearls_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3(-1844.623, -1199.41, 14.30),
            Display = false,
        },
        ["pearls_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(-1846.60, -1194.21, 14.30),
            Display = false,
        },
    }
}

Config.Jobs.Blazeit = {
    BlazeitCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "blazeit_cherrylemon_pack",
            Label = "CherryLemon Pack",
            Price = 100,
            RequiredIngredients = { "drugbags", "ogkush" },
        },
        {
            Name = "blazeit_dirtysprunk_pack",
            Label = "DirtySprunk Pack",
            Price = 100,
            RequiredIngredients = { "drugbags", "ogkush" },
        },
        {
            Name = "blazeit_fruntz_pack",
            Label = "Fruntz Pack",
            Price = 100,
            RequiredIngredients = { "drugbags", "ogkush" },
        },
        {
            Name = "blazeit_itagelato_pack",
            Label = "Itegelato Pack",
            Price = 100,
            RequiredIngredients = { "drugbags", "ogkush" },
        },
        {
            Name = "blazeit_jumbogumbo_pack",
            Label = "JumboGumbo Pack",
            Price = 100,
            RequiredIngredients = { "drugbags", "ogkush" },
        },
        {
            Name = "blazeit_junglekids_pack",
            Label = "JungleKids Pack",
            Price = 100,
            RequiredIngredients = { "drugbags", "ogkush" },
        },
        {
            Name = "blazeit_opp_pack",
            Label = "Opp Pack",
            Price = 100,
            RequiredIngredients = { "drugbags", "ogkush" },
        },
        {
            Name = "blazeit_weddingcake_pack",
            Label = "WeddingCake Pack",
            Price = 100,
            RequiredIngredients = { "drugbags", "ogkush" },
        },
        {
            Name = "weed_cookie3",
            Label = "Weed Cookie 3",
            Price = 100,
            RequiredIngredients = { "drugbags", "ogkush" },
        },	
        {
            Name = "weed_cookie7",
            Label = "Weed Cookie 4",
            Price = 100,
            RequiredIngredients = { "drugbags", "ogkush" },
        },		
        {
            Name = "weed_cookie9",
            Label = "Weed Cookie 5",
            Price = 100,
            RequiredIngredients = { "drugbags", "ogkush" },
        },			
        {
            Name = "aqua_bong",
            Label = "Aqua Bong",
            Price = 20000,
            RequiredIngredients = { "temperedglass", "acrylicpaint" },
        },
        {
            Name = "blue_bong",
            Label = "Blue Bong",
            Price = 20000,
            RequiredIngredients = { "temperedglass", "acrylicpaint" },
        },
        {
            Name = "green_bong",
            Label = "Green Bong",
            Price = 20000,
            RequiredIngredients = { "temperedglass", "acrylicpaint" },
        },
        {
            Name = "purple_bong",
            Label = "Purple Bong",
            Price = 20000,
            RequiredIngredients = { "temperedglass", "acrylicpaint" },
        },
        {
            Name = "red_bong",
            Label = "Red Bong",
            Price = 20000,
            RequiredIngredients = { "temperedglass", "acrylicpaint" },
        },
        {
            Name = "yellow_bong",
            Label = "Yellow Bong",
            Price = 20000,
            RequiredIngredients = { "temperedglass", "acrylicpaint" },
        },
        {
            Name = "uwubong",
            Label = "UWU Bong(Rare)",
            Price = 40000,
            RequiredIngredients = { "temperedglass", "acrylicpaint" },
        },
        {
            Name = "skullbong",
            Label = "Skull Bong(Rare)",
            Price = 40000,
            RequiredIngredients = { "temperedglass", "acrylicpaint" },
        },

    },
    Drinks = {
        {
            Name = "ecola",
            Label = "Cola",
            Price = 4
        },
        {
            Name = "sprunk",
            Label = "Sprunk",
            Price = 4
        },
    },
    Ingredients = {
        {
            Name = "temperedglass",
            Label = "Tempered Glass",
            Price = 20000,
        },
        {
            Name = "acrylicpaint",
            Label = "Acrylic Paint",
            Price = 5000,
        },
        {
            Name = "drugbags",
            Label = "Weed Bag",
            Price = 100,
        },
        {
            Name = "ogkush",
            Label = "OG Kush",
            Price = 10,
        },		
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(337.2132, -896.4923, 29.33044),
            Display = false,
        },
        ["clock_in"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock in.",
            Coords = vector3(364.43, -1267.7, 32.59),
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(363.01, -1259.46, 32.59),
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(180.17, -1628.89, 29.27),
            Display = false,
        },
        ["blazeit_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3(359.48, -1254.63, 32.5940),
            Display = false,
        },
        ["blazeit_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(364.146, -1254.040, 32.59),
            Display = false,
        },
    }
}

Config.Jobs.Burgershot = {
    BurgershotCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "bleeder_burger",
            Label = "Bleeder Burger",
            Price = 4,
            RequiredIngredients = { "beef_patty", "sandwich_bun", "cheese_slice" },
        },
        {
            Name = "double_shot_burger",
            Label = "Double Shot Burger",
            Price = 4,
            RequiredIngredients = { "beef_patty", "sandwich_bun", "cheese_slice" },
        },
        {
            Name = "the_glorious_burger",
            Label = "Glorious Burger",
            Price = 4,
            RequiredIngredients = { "beef_patty", "sandwich_bun", "cheese_slice" },
        },
        {
            Name = "prickly_burger",
            Label = "Prickly Burger",
            Price = 4,
            RequiredIngredients = { "beef_patty", "sandwich_bun", "cheese_slice" },
        },
        {
            Name = "the_simply_burger",
            Label = "Simply Burger",
            Price = 4,
            RequiredIngredients = { "beef_patty", "sandwich_bun", "cheese_slice" },
        },
        {
            Name = "chicken_wrap",
            Label = "Chicken Wrap",
            Price = 4,
            RequiredIngredients = { "fried_chicken", "tortilla", "cheese_slice" },
        },		
        {
            Name = "goat_cheese_wrap",
            Label = "Goat Cheese Wrap",
            Price = 4,
            RequiredIngredients = { "fried_chicken", "tortilla", "cheese_slice" },
        },		
        {
            Name = "tacos",
            Label = "Tacos",
            Price = 4,
            RequiredIngredients = { "ground_beef", "tortilla", "cheese_slice" },
        },	
        {
            Name = "fries_box",
            Label = "Fries",
            Price = 4,
            RequiredIngredients = { "potato" },
        },		
        {
            Name = "meteorite_icecream",
            Label = "Meteorite Icecream",
            Price = 4,
            RequiredIngredients = { "icecream_pint" },
        },	
        {
            Name = "orangotang_icecream",
            Label = "Orangotang Icecream",
            Price = 4,
            RequiredIngredients = { "icecream_pint" },
        },		
    },
    Drinks = {
        {
            Name = "soda",
            Label = "Soda",
            Price = 4
        },	
        {
            Name = "ecola",
            Label = "Cola",
            Price = 4
        },
        {
            Name = "sprunk",
            Label = "Sprunk",
            Price = 4
        },
    },
    Ingredients = {
        {
            Name = "beef_patty",
            Label = "Beef Patty",
            Price = 4,
        },
        {
            Name = "sandwich_bun",
            Label = "Sandwich Bun",
            Price = 4,
        },
        {
            Name = "cheese_slice",
            Label = "Cheese Slice",
            Price = 4,
        },
        {
            Name = "fried_chicken",
            Label = "Fried Chicken",
            Price = 4,
        },
        {
            Name = "tortilla",
            Label = "Tortilla",
            Price = 4,
        },
        {
            Name = "ground_beef",
            Label = "Ground Beef",
            Price = 4,
        },
        {
            Name = "potato",
            Label = "Potatos",
            Price = 4,
        },		
        {
            Name = "icecream_pint",
            Label = "Icecream Pint",
            Price = 4,
        },		
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(337.2132, -896.4923, 29.33044), 
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(-1199.749, -899.345, 13.84),  
            Display = false, 
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(-1196.47, -901.6624, 13.88), 
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(-1190.765, -898.1211, 13.88),
            Display = false,
        },
        ["burgershot_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3(-1203.224, -896.0975, 13.88), 
            Display = false,
        },
        ["burgershot_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(-1195.559, -898.0915, 13.88),
            Display = false,
        },
    }
}

Config.Jobs.Bahama = { --{ position = vec4(-1391.3549804688,-632.28094482422,30.433620452881,0.0), spawn = true },
    BahamaCookTime = 10,
    Poles = {
        { position = vector4(-1393.8203125,-612.31158447266,29.85692024231,0.0),  job = 'unicorn' }, 
        { position = vector4(-1390.8145751953,-616.89904785156,29.848852157593,0.0),  job = 'unicorn' }, 
        { position = vector4(-1387.8979492188,-621.41259765625,29.825666427612,0.0), job = 'unicorn' }, 
        { position = vector4(-1391.3549804688,-632.28094482422,30.43,0.0), job = 'unicorn' }, 
        { position = vector4(-1409.1325683594,-606.86700439453,29.60,0.0), job = 'unicorn' } 
    },
    MoneyPlaces = {
        [1] = {coords = vector3(-1394.7997, -610.6295, 29.7199), heading = 203.9248, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 1, debug = false},
        [2] = {coords = vector3(-1393.3813, -610.4242, 29.7199), heading = 163.0239, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 2, debug = false},
        [3] = {coords = vector3(-1392.2688, -610.9330, 29.7199), heading = 138.0994, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 3, debug = false},
        [4] = {coords = vector3(-1391.8689, -612.5453, 29.7199), heading = 79.6484, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 4, debug = false},
        [5] = {coords = vector3(-1392.6650, -613.7248, 29.7199), heading = 33.4013, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 5, debug = false},
        [6] = {coords = vector3(-1394.2192, -614.0991, 29.7199), heading = 335.9953, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 6, debug = false},
        [7] = {coords = vector3(-1395.3662, -613.4092, 29.7199), heading = 301.6945, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 7, debug = false},
        [8] = {coords = vector3(-1395.7375, -611.7599, 29.7199), heading = 256.9470, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 8, debug = false},
        [9] = {coords = vector3(-1389.5292, -618.4742, 29.7199), heading = 40.6318, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 9, debug = false},
        [10] = {coords = vector3(-1388.6731, -617.2834, 29.7199), heading = 78.2008, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 10, debug = false},
        [11] = {coords = vector3(-1389.1180, -615.6698, 29.7199), heading = 125.0303, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 11, debug = false},
        [12] = {coords = vector3(-1390.3547, -614.8910, 29.7199), heading = 160.1089, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 12, debug = false},
        [13] = {coords = vector3(-1391.9192, -615.1569, 29.7199), heading = 210.8465, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 13, debug = false},
        [14] = {coords = vector3(-1392.9275, -616.3796, 29.7199), heading = 257.6070, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 14, debug = false},
        [15] = {coords = vector3(-1392.5758, -617.9479, 29.7199), heading = 300.9478, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 15, debug = false},
        [16] = {coords = vector3(-1391.2651, -618.8065, 29.7199), heading = 353.1051, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 16, debug = false},
        [17] = {coords = vector3(-1389.0327, -619.7303, 29.7199), heading = 214.8008, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 17, debug = false},
        [18] = {coords = vector3(-1389.9326, -620.9433, 29.7199), heading = 251.3413, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 18, debug = false},
        [19] = {coords = vector3(-1389.5614, -622.5867, 29.7199), heading = 299.0656, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 19, debug = false},
        [20] = {coords = vector3(-1388.2418, -623.4676, 29.7199), heading = 343.1413, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 20, debug = false},
        [21] = {coords = vector3(-1386.6459, -623.1381, 29.7199), heading = 29.4355, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 21, debug = false},
        [22] = {coords = vector3(-1385.9092, -621.7597, 29.7199), heading = 87.9390, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 22, debug = false},
        [23] = {coords = vector3(-1386.1104, -620.1339, 29.7199), heading = 133.4820, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 23, debug = false},
        [24] = {coords = vector3(-1387.4741, -619.3600, 29.7199), heading = 251.3413, width = 1, length = 1, minZ=28.01, maxZ=31.6, name = 24, debug = false},
        [25] = {coords = vector3(-1390.7206, -630.5842, 30.3200), heading = 162.0033, width = 1, length = 1, minZ=29.01, maxZ=32.6, name = 25, debug = false},
        [26] = {coords = vector3(-1408.4805, -605.1449, 30.4996), heading = 151.3013, width = 1, length = 1, minZ=29.01, maxZ=32.6, name = 26, debug = false},
    },

    PedList = {
        {
            model = "u_f_y_spyactress",                            -- BAHAMA TİCKET NPC
            coords = vector3(-1383.93, -593.21, 29.32),
            heading = 33.33,
            gender = "female",
            animation_type = "basic",  -- basic or custom
            animation = "WORLD_HUMAN_CLIPBOARD",
            dict = "", -- If it is Basic, you do not need to fill out this section.
            anim = "" -- If it is Basic, you do not need to fill out this section.
        },
        {
            model = "csb_vincent",                            -- BAHAMA EXTERIOR DOOR PROTECTION 1
            coords = vector3(-1390.29, -587.05, 29.23),
            heading = 32.65,
            gender = "male",
            animation_type = "basic",  -- basic or custom
            animation = "WORLD_HUMAN_GUARD_STAND_CASINO",
            dict = "", -- If it is Basic, you do not need to fill out this section.
            anim = "" -- If it is Basic, you do not need to fill out this section.
        },
        {
            model = "csb_vincent",                            -- BAHAMA EXTERIOR DOOR PROTECTION 2
            coords = vector3(-1387.33, -585.36, 29.21),
            heading = 32.65,
            gender = "male",
            animation_type = "basic",  -- basic or custom
            animation = "WORLD_HUMAN_GUARD_STAND_CASINO",
            dict = "", -- If it is Basic, you do not need to fill out this section.
            anim = "" -- If it is Basic, you do not need to fill out this section.
        },
        -- {
            -- model = "csb_stripper_02",                            -- BAHAMA POLE DANCE 1
            -- coords = vector3(-1409.04, -606.47, 29.5),
            -- heading = 336.14,
            -- gender = "female",
            -- animation_type = "custom",  -- basic or custom
            -- scenario = "",  -- Custom ise burayı doldurmana gerek yok
            -- animation = { "mini@strip_club@private_dance@part2", "priv_dance_p2" } -- If it is Basic, you do not need to fill out this section.
        -- },
        -- {
            -- model = "csb_stripper_02",                            -- BAHAMA POLE DANCE 2
            -- coords = vector3(-1391.11, -632.06, 30.3),
            -- heading = 346.8,
            -- gender = "female",
            -- animation_type = "custom",  -- basic or custom
            -- scenario = "",  -- Custom ise burayı doldurmana gerek yok
            -- animation = { "mp_safehouse", "lap_dance_girl" } -- If it is Basic, you do not need to fill out this section.
        -- },
        -- {
            -- model = "csb_stripper_02",                            -- BAHAMA POLE DANCE 3
            -- coords = vector3(-1394.0, -611.55, 29.7),
            -- heading = 41.57,
            -- gender = "female",
            -- animation_type = "custom",  -- basic or custom
            -- scenario = "",  -- Custom ise burayı doldurmana gerek yok
            -- animation = { "mini@strip_club@private_dance@part3", "priv_dance_p3" } -- If it is Basic, you do not need to fill out this section.
        -- },
        -- {
            -- model = "csb_stripper_02",                            -- BAHAMA POLE DANCE 4
            -- coords = vector3(-1390.95, -616.58, 29.7),
            -- heading = 197.74,
            -- gender = "female",
            -- animation_type = "custom",  -- basic or custom
            -- scenario = "",  -- Custom ise burayı doldurmana gerek yok
            -- animation = { "mp_safehouse", "lap_dance_girl" } -- If it is Basic, you do not need to fill out this section.
        -- },
        -- {
            -- model = "csb_stripper_02",                            -- BAHAMA POLE DANCE 5
            -- coords = vector3(-1387.65, -621.79, 29.7),
            -- heading = 212.67,
            -- gender = "female",
            -- animation_type = "custom",  -- basic orİÇİ KORUMA custom
            -- scenario = "",  -- Custom ise burayı doldurmana gerek yok
            -- animation = { "mini@strip_club@private_dance@idle", "priv_dance_idle" } -- If it is Basic, you do not need to fill out this section.
        -- },
        {
            model = "csb_stripper_02",                            -- BAHAMA POLE DANCE 6
            coords = vector3(-1369.89, -621.07, 29.5),
            heading = 164.49,
            gender = "female",
            animation_type = "custom",  -- basic or custom
            scenario = "",  -- Custom ise burayı doldurmana gerek yok
            animation = { "mini@strip_club@private_dance@part2", "priv_dance_p2" } -- If it is Basic, you do not need to fill out this section.
        },
        {
            model = "cs_fbisuit_01",                            -- BAHAMA BOSS DOOR PROTECTION 1
            coords = vector3(-1379.2, -621.03, 29.32),
            heading = 122.79,
            gender = "male",
            animation_type = "basic",  -- basic or custom
            animation = "WORLD_HUMAN_GUARD_STAND",
            dict = "", -- If it is Basic, you do not need to fill out this section.
            anim = "" -- If it is Basic, you do not need to fill out this section.
        },
        {
            model = "cs_fbisuit_01",                            -- BAHAMA BOSS DOOR PROTECTION 2
            coords = vector3(-1379.57, -625.68, 29.32),
            heading = 32.22,
            gender = "male",
            animation_type = "basic",  -- basic or custom
            animation = "WORLD_HUMAN_GUARD_STAND",
            dict = "", -- If it is Basic, you do not need to fill out this section.
            anim = "" -- If it is Basic, you do not need to fill out this section.
        },
        {
            model = "s_m_m_highsec_01",                            -- BAHAMA HALL INTERIOR DOOR PROTECTION
            coords = vector3(-1390.56, -595.29, 29.32),
            heading = 123.72,
            gender = "male",
            animation_type = "basic",  -- basic or custom
            animation = "WORLD_HUMAN_GUARD_STAND",
            dict = "", -- If it is Basic, you do not need to fill out this section.
            anim = "" -- If it is Basic, you do not need to fill out this section.
        },
        {
            model = "s_m_m_bouncer_01",                            -- BAHAMA INTERIOR PROTECTION 1
            coords = vector3(-1404.71, -610.12, 29.32),
            heading = 300.92,
            gender = "male",
            animation_type = "basic",  -- basic or custom
            animation = "WORLD_HUMAN_GUARD_STAND",
            dict = "", -- If it is Basic, you do not need to fill out this section.
            anim = "" -- If it is Basic, you do not need to fill out this section.
        },
        {
            model = "s_m_m_bouncer_01",                            -- BAHAMA INTERIOR PROTECTION 2
            coords = vector3(-1399.53, -618.1, 29.32),
            heading = 299.92,
            gender = "male",
            animation_type = "basic",  -- basic or custom
            animation = "WORLD_HUMAN_GUARD_STAND",
            dict = "", -- If it is Basic, you do not need to fill out this section.
            anim = "" -- If it is Basic, you do not need to fill out this section.
        },
        {
            model = "s_m_m_bouncer_01",                            -- BAHAMA INTERIOR PROTECTION 3
            coords = vector3(-1392.26, -607.37, 28.72),
            heading = 162.35,
            gender = "male",
            animation_type = "basic",  -- basic or custom
            animation = "WORLD_HUMAN_GUARD_STAND",
            dict = "", -- If it is Basic, you do not need to fill out this section.
            anim = "" -- If it is Basic, you do not need to fill out this section.
        },
        {
            model = "s_m_m_bouncer_01",                            -- BAHAMA INTERIOR PROTECTION 4
            coords = vector3(-1398.84, -611.71, 28.72),
            heading = 271.51,
            gender = "male",
            animation_type = "basic",  -- basic or custom
            animation = "WORLD_HUMAN_GUARD_STAND",
            dict = "", -- If it is Basic, you do not need to fill out this section.
            anim = "" -- If it is Basic, you do not need to fill out this section.
        },
        -- {
            -- model = "s_m_y_waiter_01",                            -- BAHAMA WAITER
            -- coords = vector3(-1400.28, -602.31, 29.32),
            -- heading = 208.22,
            -- gender = "male",
            -- animation_type = "basic",  -- basic or custom
            -- animation = "WORLD_HUMAN_CLIPBOARD",
            -- dict = "", -- If it is Basic, you do not need to fill out this section.
            -- anim = "" -- If it is Basic, you do not need to fill out this section.
        -- },
    },
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "orangotang_icecream",
            Label = "Orangotang Icecream",
            Price = 4,
            RequiredIngredients = { "icecream_pint" },
        },		
    },
    Drinks = {
        {
            Name = "soda",
            Label = "Soda",
            Price = 4
        },	
        {
            Name = "ecola",
            Label = "Cola",
            Price = 4
        },
        {
            Name = "sprunk",
            Label = "Sprunk",
            Price = 4
        },
    },
    Ingredients = {
        {
            Name = "ngd_bhmartiniglass",
            Label = "Martini Glass",
            Price = 15,
        },
        {
            Name = "ngd_bhhurricaneglass",
            Label = "Hurricane Glass",
            Price = 15,
        },
        {
            Name = "ngd_bhtallglass",
            Label = "Tall Glass",
            Price = 15,
        },	
        {
            Name = "ngd_bhwineglass",
            Label = "Wine Glass",
            Price = 15,
        },		
        {
            Name = "ngd_bhchamglass",
            Label = "Champagne Glass",
            Price = 15,
        },	
        {
            Name = "ngd_bhtequila",
            Label = "Tequila",
            Price = 25,
        },	
        {
            Name = "ngd_bhcdm",
            Label = "Creme De Menthe",
            Price = 25,
        },	
        {
            Name = "ngd_bhrum",
            Label = "Rum",
            Price = 25,
        },	
        {
            Name = "ngd_bhbrandy",
            Label = "Brandy",
            Price = 25,
        },			
        {
            Name = "ngd_bhrwbottle",
            Label = "Red Wine Bottle",
            Price = 25,
        },	
        {
            Name = "ngd_bhwwbottle",
            Label = "White Wine Bottle",
            Price = 25,
        },			
        {
            Name = "ngd_bhchambottle",
            Label = "Champagne Bottle",
            Price = 25,
        },			
        {
            Name = "ngd_bhice",
            Label = "Ice",
            Price = 4,
        },		
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(337.2132, -896.4923, 29.33044), 
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(-1402.779, -598.5503, 30.319),   --vector4(-1402.779, -598.5503, 30.31995, 24.79192)
            Display = false, 
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(-1372.134, -629.0733, 30.32), 
            Display = false,
        },
        ["bahama_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3(-1404.049, -599.662, 30.31),  --vector4(-1404.049, -599.662, 30.31997, 111.8457)
            Display = false,
        },
        ["bahama_oven"] = {
            DisplayText = "|oven_status|", 
            Coords = vector3(-1400.401, -598.4598, 30.31), --vector4(-1400.401, -598.4598, 30.31997, 296.6576)
            Display = false,
        },
    }
}

Config.Jobs.Bishops = {
    BishopsCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "idrp_bish_wings",
            Label = "Chicken Wings",
            Price = 4,
            RequiredIngredients = { "fried_chicken", "hot_sauce" },
        },
        {
            Name = "idrp_bish_sandwich",
            Label = "Chicken Sandwich",
            Price = 4,
            RequiredIngredients = { "fried_chicken", "sandwich_bun" },
        },
        {
            Name = "idrp_bish_bucket",
            Label = "Chicken Bucket",
            Price = 4,
            RequiredIngredients = { "fried_chicken" },
        },
        {
            Name = "idrp_bish_rings",
            Label = "Onion Rings",
            Price = 4,
            RequiredIngredients = { "onions" },
        },
        {
            Name = "idrp_bish_fries",
            Label = "Fries",
            Price = 4,
            RequiredIngredients = { "potato" },
        },
        -- {
            -- Name = "meatloaf",
            -- Label = "Meatloaf Plate",
            -- Price = 4,
            -- RequiredIngredients = { },
        -- },
        -- {
            -- Name = "porkmix",
            -- Label = "Baby-Back-Ribs",
            -- Price = 4,
            -- RequiredIngredients = { "onions" },
        -- },
        -- {
            -- Name = "potroastmc",
            -- Label = "Pot-Roast",
            -- Price = 4,
            -- RequiredIngredients = { "onions" },
        -- },
        -- {
            -- Name = "smothredporkchop",
            -- Label = "Smothered-Pork-Chop",
            -- Price = 4,
            -- RequiredIngredients = { "onions" },
        -- },
        -- {
            -- Name = "wafflenchicken",
            -- Label = "Waffles-n-Chicken",
            -- Price = 4,
            -- RequiredIngredients = { "onions" },
        -- },		
    },
    Drinks = {
        {
            Name = "ecola",
            Label = "Cola",
            Price = 4
        },
        {
            Name = "sprunk",
            Label = "Sprunk",
            Price = 4
        },
        {
            Name = "idrp_bish_cshake",
            Label = "Choclate Milkshake",
            Price = 4
        },
        {
            Name = "idrp_bish_sshake",
            Label = "Strawberry Milkshake",
            Price = 4
        },
        {
            Name = "idrp_bish_vshake",
            Label = "Vanilla Milkshake",
            Price = 4
        },
    },
    Ingredients = {
        {
            Name = "hot_sauce",
            Label = "Hot Sauce",
            Price = 4,
        },
        {
            Name = "fried_chicken",
            Label = "Fried Chicken",
            Price = 4,
        },
        {
            Name = "sandwich_bun",
            Label = "Sandwich Bun",
            Price = 4,
        },
        {
            Name = "potato",
            Label = "Potato",
            Price = 4,
        },
        {
            Name = "onions",
            Label = "Onions",
            Price = 4,
        },
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(2586.855, 477.6873, -108.65),--vector4(2586.855, 477.6873, 108.6579, 175.3455)
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(2585.955, 486.138, 108.65), --vector4(2585.955, 486.138, 108.658, 350.0692)
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(2586.855, 477.6873, 108.65),
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(2582.516, 483.5868, 108.65), --vector4(2582.516, 483.5868, 108.658, 175.425)
            Display = false,
        },
        ["bishops_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3(2588.316, 485.9563, 108.65), --vector4(2588.316, 485.9563, 108.658, 14.8475)
            Display = false,
        },
        ["bishops_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(2583.407, 486.1473, 108.65),--vector4(2583.407, 486.1473, 108.6579, 355.5189)
            Display = false,
        },
    }
}

Config.Jobs.Catcafe = {
    CatcafeCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "catburger",
            Label = "Cat Burger",
            Price = 4,
            RequiredIngredients = { "sandwich_bun", "cheese", "chicken_cutlet" },
        },
        {
            Name = "catdonut",
            Label = "Cat Donut",
            Price = 4,
            RequiredIngredients = { "dough_ball", "strawberry", "sugar" },
        },
        {
            Name = "catmacaron",
            Label = "Cat Macaron",
            Price = 4,
            RequiredIngredients = { "dough_ball", "vanilla", "sugar" },
        },
        {
            Name = "catmarsh",
            Label = "Cat Marshmallow",
            Price = 4,
            RequiredIngredients = { "marshmallow", "sprinkles" },
        },
        {
            Name = "mochi1",
            Label = "Blueberry Mochi",
            Price = 4,
            RequiredIngredients = { "sugar", "blueberry" },
        },
        {
            Name = "mochi2",
            Label = "Vanilla Mochi",
            Price = 4,
            RequiredIngredients = { "sugar", "vanilla" },
        },
        {
            Name = "mochi3",
            Label = "Greentea Mochi",
            Price = 4,
            RequiredIngredients = { "sugar", "greentea" },
        },
        {
            Name = "mochi4",
            Label = "Strawberry Mochi",
            Price = 4,
            RequiredIngredients = { "sugar", "strawberry" },
        },
    },
    Drinks = {
        {
            Name = "matchagreentea",
            Label = "Matcha GreenTea",
            Price = 4
        },
        {
            Name = "bubbletea",
            Label = "BubbleTea",
            Price = 4
        },
        {
            Name = "water",
            Label = "Water",
            Price = 4
        },
    },
    Ingredients = {
        {
            Name = "chicken_cutlet",
            Label = "Chicken Cutlet",
            Price = 4,
        },
        {
            Name = "sandwich_bun",
            Label = "Sandwich Bun",
            Price = 4,
        },
        {
            Name = "cheese",
            Label = "Cheese",
            Price = 4,
        },
        {
            Name = "dough_ball",
            Label = "Dough",
            Price = 4,
        },
        {
            Name = "marshmallow",
            Label = "Marshmallow",
            Price = 4,
        },
        {
            Name = "sugar",
            Label = "Sugar",
            Price = 4,
        },
        {
            Name = "vanilla",
            Label = "Vanilla",
            Price = 4,
        },
        {
            Name = "strawberry",
            Label = "Strawberry",
            Price = 4,
        },
        {
            Name = "blueberry",
            Label = "Blueberry",
            Price = 4,
        },
        {
            Name = "greentea",
            Label = "Greentea",
            Price = 4,
        },
        {
            Name = "sprinkles",
            Label = "Sprinkles",
            Price = 4,
        },
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(-598.03, -1067.10, 22.34),
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(-588.52, -1062.61, 22.35),
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(-597.65, -1053.60, 22.34),
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(-586.320, -1061.97, 22.344),
            Display = false,
        },
        ["catcafe_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3(-588.51, -1066.14, 22.34),
            Display = false,
        },
        ["catcafe_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(-590.32, -1059.78, 22.34),
            Display = false,
        },
    }
}

Config.Jobs.Pizza = {
    PizzaCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "pizza_cheese",
            Label = "Cheese Pizza",
            Price = 4,
            RequiredIngredients = { "tomato_sauce", "cheese" },
        },
        {
            Name = "pizza_pepperoni",
            Label = "Pepperoni Pizza",
            Price = 4,
            RequiredIngredients = { "tomato_sauce", "cheese", "pepperoni" },
        },
        {
            Name = "pizza_bbq_chicken",
            Label = "BBQ Chicken Pizza",
            Price = 4,
            RequiredIngredients = { "tomato_sauce", "cheese", "bbq_chicken" },
        },
    },
    Drinks = {
        {
            Name = "icetea",
            Label = "IcedTea",
            Price = 4
        },
        {
            Name = "cocacola",
            Label = "Soda",
            Price = 4
        },
        {
            Name = "water",
            Label = "Water",
            Price = 4
        },
    },
    Ingredients = {
        {
            Name = "tomato_sauce",
            Label = "Tomato Sauce",
            Price = 4,
        },
        {
            Name = "cheese",
            Label = "Cheese",
            Price = 4,
        },
        {
            Name = "pepperoni",
            Label = "Pepperoni",
            Price = 4,
        },
        {
            Name = "bbq_chicken",
            Label = "BBQ Chicken",
            Price = 4,
        },
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(-508.62, 291.74, 83.3),
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(-504.72, 290.27, 83.6),
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(-508.72, 297.81, 83.3),
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(-504.82, 293.6, 83.3),
            Display = false,
        },
        ["pizza_dough"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to make pizza dough.",
            Coords = vector3(-505.78, 286.2, 83.3),
            Display = false,
        },
        ["pizza_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3(-508.74, 281.52, 83.3),
            Display = false,
        },
        ["pizza_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(-505.94, 284.05, 83.3),
            Display = false,
        },
        ["trash_can"] = {
            DisplayText = "|trash_status|",
            Coords = vector3(-508.28, 294.85, 83.3),
            Display = false,
        },
        ["dumpster"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to throw away the trash.",
            Coords = vector3(-506.22, 306.96, 83.3),
            Display = false,
        },
    }
}

Config.Jobs.Dunkin = {
    DunkinCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "donut_sprinkled",
            Label = "Sprinkled Donut",
            Price = 4,
            RequiredIngredients = { "sprinkles" },
        },
        {
            Name = "donut_glazed",
            Label = "Glazed Donut",
            Price = 4,
            RequiredIngredients = { "glazed" },
        },
        {
            Name = "donut_chocolate",
            Label = "Chocolate Donut",
            Price = 4,
            RequiredIngredients = { "chocolate" },
        },
        {
            Name = "donut_strawberry",
            Label = "Strawberry Donut",
            Price = 4,
            RequiredIngredients = { "strawberry" },
        },
        {
            Name = "donut_vanilla",
            Label = "Vanilla Donut",
            Price = 4,
            RequiredIngredients = { "vanilla" },
        },
    },
    Drinks = {
        {
            Name = "coffee",
            Label = "Coffee",
            Price = 4
        },
        {
            Name = "latte",
            Label = "Latte",
            Price = 4
        },
        {
            Name = "iced_coffee",
            Label = "Iced Coffee",
            Price = 4
        },
        {
            Name = "icetea",
            Label = "Iced Tea",
            Price = 4
        },
        {
            Name = "water",
            Label = "Water",
            Price = 4
        },
    },
    Ingredients = {
        {
            Name = "sprinkles",
            Label = "Sprinkles",
            Price = 4,
        },
        {
            Name = "glazed",
            Label = "Glazed",
            Price = 4,
        },
        {
            Name = "chocolate",
            Label = "Chocolate",
            Price = 4,
        },
        {
            Name = "strawberry",
            Label = "Strawberry",
            Price = 4,
        },
        {
            Name = "vanilla",
            Label = "Vanilla",
            Price = 4,
        },
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(-580.42, -883.56, 25.95),
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(-589.2, -886.04, 25.95),
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(-591.92, -873.83, 25.8),
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(-584.62, -888.94, 25.95),
            Display = false,
        },
        ["dunkin_dough"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to make dough.",
            Coords = vector3(-580.33, -886.52, 25.95),
            Display = false,
        },
        ["dunkin_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get flavors.",
            Coords = vector3(-585.03, -884.6, 25.95),
            Display = false,
        },
        ["dunkin_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(-581.15, -888.87, 25.95),
            Display = false,
        }
    }
}

Config.Jobs.Taco = {
    TacoCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "taco",
            Label = "Taco",
            Price = 4,
            RequiredIngredients = { "ground_beef", "vegetables", "tortilla", "cheese" },
        },
        {
            Name = "burrito",
            Label = "Burrito",
            Price = 4,
            RequiredIngredients = { "ground_beef", "vegetables", "tortilla", "cheese" },
        },
        {
            Name = "quesadilla",
            Label = "Quesadilla",
            Price = 4,
            RequiredIngredients = { "ground_beef", "vegetables", "tortilla", "cheese" },
        },
        {
            Name = "churros",
            Label = "Churros",
            Price = 4,
            RequiredIngredients = { "sugar", "dough_ball" },
        },
    },
    Drinks = {
        {
            Name = "icetea",
            Label = "IcedTea",
            Price = 4
        },
        {
            Name = "cocacola",
            Label = "Soda",
            Price = 4
        },
        {
            Name = "jarritosorange",
            Label = "Jarritos Orange",
            Price = 4
        },
        {
            Name = "jarritosred",
            Label = "Jarritos Red",
            Price = 4
        },
        {
            Name = "jarritosyellow",
            Label = "Jarritos Yellow",
            Price = 4
        },
    },
    Ingredients = {
        {
            Name = "ground_beef",
            Label = "GroundBeef",
            Price = 4,
        },
        {
            Name = "vegetables",
            Label = "Vegetables",
            Price = 4,
        },
        {
            Name = "tortilla",
            Label = "Tortilla",
            Price = 4,
        },
        {
            Name = "cheese",
            Label = "Cheese",
            Price = 4,
        },
        {
            Name = "sugar",
            Label = "Sugar",
            Price = 4,
        },
        {
            Name = "dough_ball",
            Label = "Dough",
            Price = 4,
        },
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(-1036.92, -1375.44, 5.52),
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(12.48, -1597.84, 29.37),
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(20.320, -1601.86, 29.37),
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(13.80, -1596.39, 29.37),
            Display = false,
        },
        ["taco_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3(16.949, -1599.55, 29.37),
            Display = false,
        },
        ["taco_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(11.28, -1599.30, 29.37),
            Display = false,
        },
        ["trash_can"] = {
            DisplayText = "|trash_status|",
            Coords = vector3(14.66, -1597.30, 29.37),
            Display = false,
        },
        ["dumpster"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to throw away the trash.",
            Coords = vector3(24.149, -1597.58, 29.28),
            Display = false,
        },
    }
}

Config.Jobs.Chickfila = {
    ChickfilaCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "chicken_nuggets",
            Label = "Chicken Nuggets",
            Price = 4,
            RequiredIngredients = { "fried_chicken" },
        },
        {
            Name = "chicken_sandwich",
            Label = "Original Chicken Sandwich",
            Price = 4,
            RequiredIngredients = { "fried_chicken", "sandwich_bun" },
        },
        {
            Name = "french_fries",
            Label = "French Fries",
            Price = 4,
            RequiredIngredients = { "potato" },
        },
        {
            Name = "cookie",
            Label = "Cookie",
            Price = 4,
            RequiredIngredients = { "cookie_dough" },
        },
    },
    Drinks = {
        {
            Name = "diet_cola",
            Label = "Diet Soda",
            Price = 4
        },
        {
            Name = "cocacola",
            Label = "Soda",
            Price = 4
        },
        {
            Name = "milkshake",
            Label = "Milkshake",
            Price = 4
        },
    },
    Ingredients = {
        {
            Name = "fried_chicken",
            Label = "Fried Chicken",
            Price = 4,
        },
        {
            Name = "sandwich_bun",
            Label = "Sandwich Bun",
            Price = 4,
        },
        {
            Name = "potato",
            Label = "Potato",
            Price = 4,
        },
        {
            Name = "cookie_dough",
            Label = "Cookie Dough",
            Price = 4,
        },
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(-1036.92, -1375.44, 5.52),
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(-1034.1, -1371.61, 5.52),
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(-1038.18, -1381.88, 5.52),
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(-1035.19, -1380.23, 5.52),
            Display = false,
        },
        ["chickfila_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3(-1028.63, -1380.2, 5.52),
            Display = false,
        },
        ["chickfila_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(-1028.74, -1372.96, 5.52),
            Display = false,
        },
        ["trash_can"] = {
            DisplayText = "|trash_status|",
            Coords = vector3(-1040.3, -1379.67, 5.52),
            Display = false,
        },
        ["dumpster"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to throw away the trash.",
            Coords = vector3(-1015.63, -1343.05, 5.52),
            Display = false,
        },
    }
}

Config.Jobs.Denaros = {
    DenarosCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "chicken_parm",
            Label = "Chicken Parmesan",
            Price = 4,
            RequiredIngredients = { "chicken_cutlet", "pasta", "cheese", "tomato_sauce" },
        },
        {
            Name = "calzone",
            Label = "Calzone",
            Price = 4,
            RequiredIngredients = { "dough_ball", "cheese", "pepperoni" },
        },
        {
            Name = "brick_pizza",
            Label = "Brick Oven Pizza",
            Price = 4,
            RequiredIngredients = { "dough_ball", "tomato_sauce", "cheese" },
        },
        {
            Name = "lasagna",
            Label = "Lasagna",
            Price = 4,
            RequiredIngredients = { "pasta", "ground_beef", "tomato_sauce", "cheese" },
        },
        {
            Name = "ravioli",
            Label = "Ravioli",
            Price = 4,
            RequiredIngredients = { "pasta", "ground_beef", "tomato_sauce" },
        },
        {
            Name = "gelato",
            Label = "Gelato",
            Price = 4,
            RequiredIngredients = { "sugar", "cream", "vanilla" },
        },
        {
            Name = "cannoli",
            Label = "Cannoli",
            Price = 4,
            RequiredIngredients = { "cream", "chocolate", "dough_ball" },
        },
        {
            Name = "p_wine",
            Label = "House Wine",
            Price = 5000,
            RequiredIngredients = { "red_wine", "poison" },
        },
    },
    Drinks = {
        {
            Name = "espresso",
            Label = "Espresso",
            Price = 4,
        },
        {
            Name = "italian_soda",
            Label = "Italian Soda",
            Price = 4,
        },
        {
            Name = "red_wine",
            Label = "Red Wine",
            Price = 5,
        },
        {
            Name = "dom_p",
            Label = "Dom P",
            Price = 5,
        },
        {
            Name = "mirror_shot",
            Label = "Mirror Shot",
            Price = 5,
        },
        {
            Name = "vodka_redbull",
            Label = "Vodka Redbull",
            Price = 5,
        },
    },
    Ingredients = {
        {
            Name = "cheese",
            Label = "Cheese",
            Price = 4,
        },
        {
            Name = "chicken_cutlet",
            Label = "Chicken Cutlet",
            Price = 4,
        },
        {
            Name = "chocolate",
            Label = "Chocolate",
            Price = 4,
        },
        {
            Name = "cream",
            Label = "Cream",
            Price = 4,
        },
        {
            Name = "dough_ball",
            Label = "Dough",
            Price = 4,
        },
        {
            Name = "ground_beef",
            Label = "Ground Beef",
            Price = 4,
        },
        {
            Name = "grapes",
            Label = "Grapes",
            Price = 4,
        },
        {
            Name = "pasta",
            Label = "Pasta",
            Price = 4,
        },
        {
            Name = "pepperoni",
            Label = "Pepperoni",
            Price = 4,
        },
        {
            Name = "sugar",
            Label = "Sugar",
            Price = 4,
        },
        {
            Name = "tomato_sauce",
            Label = "Tomato Sauce",
            Price = 4,
        },
        {
            Name = "vanilla",
            Label = "Vanilla",
            Price = 4,
        },
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(-1346.71, -1063.35, 7),
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(-1351.76, -1069.63, 7),
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(-1353.06, -1055.05, 3.5),
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(-1342.07, -1069.17, 7),
            Display = false,
        },
        ["drink_fountain2"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(-1350.16, -1064.12, 11.5),
            Display = false,
        },
        ["denaros_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3(-1351.1, -1071.43, 7),
            Display = false,
        },
        ["denaros_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(-1352.65, -1067.61, 7),
            Display = false,
        },
        ["trash_can"] = {
            DisplayText = "|trash_status|",
            Coords = vector3(-1342.97, -1061.16, 7.0),
            Display = false,
        },
        ["dumpster"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to throw away the trash.",
            Coords = vector3(-1336.72, -1055.14, 7.5),
            Display = false,
        },
    }
}

Config.Jobs.KFC = {
    KFCCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "bbq_friedchicken",
            Label = "BBQ Fried Chicken",
            Price = 4,
            RequiredIngredients = { "fried_chicken", "bbq_sauce" },
        },
        {
            Name = "kfc_chicken_sandwich",
            Label = "Original Chicken Sandwich",
            Price = 4,
            RequiredIngredients = { "fried_chicken", "sandwich_bun" },
        },
        {
            Name = "kfc_frenchfries",
            Label = "French Fries",
            Price = 4,
            RequiredIngredients = { "potato" },
        },
        {
            Name = "cookie",
            Label = "Cookie",
            Price = 4,
            RequiredIngredients = { "cookie_dough" },
        },
    },
    Drinks = {
        {
            Name = "diet_cola",
            Label = "Diet Soda",
            Price = 4
        },
        {
            Name = "cocacola",
            Label = "Soda",
            Price = 4
        },
        {
            Name = "milkshake",
            Label = "Milkshake",
            Price = 4
        },
    },
    Ingredients = {
        {
            Name = "hot_sauce",
            Label = "Hot Sauce",
            Price = 4,
        },
        {
            Name = "bbq_sauce",
            Label = "BBQ Sauce",
            Price = 4,
        },
        {
            Name = "fried_chicken",
            Label = "Fried Chicken",
            Price = 4,
        },
        {
            Name = "sandwich_bun",
            Label = "Sandwich Bun",
            Price = 4,
        },
        {
            Name = "potato",
            Label = "Potato",
            Price = 4,
        },
        {
            Name = "cookie_dough",
            Label = "Cookie Dough",
            Price = 4,
        },
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(337.2132, -896.4923, 29.33044),
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(334.4703, -891.0725, 29.33044),
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(335.9077, -884.8879, 29.33044),
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(343.767, -891.455, 29.33044),
            Display = false,
        },
        ["kfc_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3(345.4154, -897.9956, 29.33044),
            Display = false,
        },
        ["kfc_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(341.1429, -896.9539, 29.33044),
            Display = false,
        },
    }
}

Config.Jobs.Unicorn = {
    UnicornCookTime = 5,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "cosmopolitan",
            Label = "Cosmopolitan",
            Price = 4,
            RequiredIngredients = { "vodka", "cointreau", "cranberry_juice", "fresh_mix" },
        },
        {
            Name = "mojito",
            Label = "Mojito",
            Price = 4,
            RequiredIngredients = { "mint", "lime", "sugar", "rum", "club_soda" },
        },
        {
            Name = "mai_tai",
            Label = "Mai Tai",
            Price = 4,
            RequiredIngredients = { "rum", "curacao", "sugar", "lime" },
        },
        {
            Name = "mint_julep",
            Label = "Mint Julep",
            Price = 4,
            RequiredIngredients = { "water", "sugar", "mint", "bourbon" },
        },
        {
            Name = "caipirinha",
            Label = "Caipirinha",
            Price = 4,
            RequiredIngredients = { "cachaca", "lime", "sugar" },
        },
        {
            Name = "margarita",
            Label = "Margarita",
            Price = 4,
            RequiredIngredients = { "lime", "tequila", "cointreau", "triple_sec" },
        },
        {
            Name = "pina_colada",
            Label = "Pina Colada",
            Price = 4,
            RequiredIngredients = { "rum", "coconut_milk", "pineapple_juice" },
        },
    },
    -- Drinks = {
    -- {
    -- Name = "diet_cola",
    -- Label = "Diet Soda",
    -- Price = 4
    -- },
    -- {
    -- Name = "cocacola",
    -- Label = "Soda",
    -- Price = 4
    -- },
    -- {
    -- Name = "milkshake",
    -- Label = "Milkshake",
    -- Price = 4
    -- },
    -- },
    Ingredients = {
        {
            Name = "water",
            Label = "Water",
            Price = 4,
        },
        {
            Name = "vodka",
            Label = "Vodka",
            Price = 4,
        },
        {
            Name = "cointreau",
            Label = "Cointreau",
            Price = 4,
        },
        {
            Name = "cachaca",
            Label = "Cachaca",
            Price = 4,
        },
        {
            Name = "cranberry_juice",
            Label = "Cranberry Juice",
            Price = 4,
        },
        {
            Name = "mint",
            Label = "Mint",
            Price = 4,
        },
        {
            Name = "curacao",
            Label = "Curacao",
            Price = 4,
        },
        {
            Name = "lime",
            Label = "Lime",
            Price = 4,
        },
        {
            Name = "sugar",
            Label = "Sugar",
            Price = 4,
        },
        {
            Name = "club_soda",
            Label = "Club Soda",
            Price = 4,
        },
        {
            Name = "triple_sec",
            Label = "Triple Sec",
            Price = 4,
        },
        {
            Name = "tequila",
            Label = "Tequila",
            Price = 4,
        },
        {
            Name = "rum",
            Label = "Rum",
            Price = 4,
        },
        {
            Name = "coconut_milk",
            Label = "Coconut Milk",
            Price = 4,
        },
        {
            Name = "pineapple_juice",
            Label = "Pineapple Juice",
            Price = 4,
        },
    },
    InteractMarkers = {
        ["clock_out"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-out.",
            Coords = vector3(132.62, -1287.74, -29.26),
            Display = false,
        },
        ["wash_hands"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to wash your hands.",
            Coords = vector3(108.40, -1282.83, 29.61),
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(95.48, -1299.32, 35.584),
            Display = false,
        },
        ["drink_fountain"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get a drink.",
            Coords = vector3(343.767, -891.455, -29.33044),
            Display = false,
        },
        ["unicorn_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get ingredients.",
            Coords = vector3( 98.62, -1286.44, 29.21), 
            Display = false,
        },
        ["unicorn_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(112.808, -1282.35,  29.61),
            Display = false,
        },
    }
}

Config.Jobs.Ammunation = {
    AmmunationCookTime = 10,
    OvercookedTime = 5, -- after cook time elapses, after this many seconds start a fire.
    CookableItems = {
        {
            Name = "WEAPON_PISTOL",
            Label = "Pistol",
            Price = 120000,
            RequiredIngredients = { "metal_scrap", "gun_powder", "rubber" },
            Type = "weapon"
        },
        {
            Name = "WEAPON_VINTAGEPISTOL",
            Label = "Vintage Pistol",
            Price = 122000,
            RequiredIngredients = { "metal_scrap", "gun_powder", "rubber" },
            Type = "weapon"
        },
        {
            Name = "WEAPON_SNSPISTOL",
            Label = "SNS Pistol",
            Price = 125000,
            RequiredIngredients = { "metal_scrap", "gun_powder", "rubber" },
            Type = "weapon"
        },		
        {
            Name = "weapon_pistol_mk2",
            Label = "Pistol Mk II",
            Price = 125000,
            RequiredIngredients = { "metal_scrap", "gun_powder", "rubber" },
            Type = "weapon"
        },
        -- {
        -- Name = "weapon_heavypistol",
        -- Label = "Heavy Pistol",
        -- Price = 30000,
        -- RequiredIngredients = {"metal_scrap", "gun_powder", "rubber"},
        -- Type = "weapon"
        -- },		
        {
            Name = "weapon_pistol50",
            Label = "Pistol .50",
            Price = 150000,
            RequiredIngredients = { "metal_scrap", "gun_powder", "rubber" },
            Type = "weapon"
        },
        {
            Name = "WEAPON_MACHETE",
            Label = "Machete",
            Price = 10000,
            RequiredIngredients = { "metal_scrap", "gun_powder", "rubber" },
            Type = "weapon"
        },
        {
            Name = "WEAPON_SWITCHBLADE",
            Label = "Switchblade",
            Price = 10000,
            RequiredIngredients = { "metal_scrap", "gun_powder", "rubber" },
            Type = "weapon"
        },
        {
            Name = "WEAPON_HAMMER",
            Label = "Hammer",
            Price = 10000,
            RequiredIngredients = { "metal_scrap", "gun_powder", "rubber" },
            Type = "weapon"
        },
        {
            Name = "WEAPON_BAT",
            Label = "Bat",
            Price = 10000,
            RequiredIngredients = { "metal_scrap", "gun_powder", "rubber" },
            Type = "weapon"
        },
        {
            Name = "bulletproof",
            Label = "Bulletproof Vest",
            Price = 10000,
            RequiredIngredients = { "cloth", "metal_plate" },
            Type = "item"
        },
        -- {
        -- Name = "clip",
        -- Label = "Weapon Clip",
        -- Price = 5,
        -- RequiredIngredients = {"metal_scrap", "gun_powder"},
        -- Type = "item"
        -- },		
    },
    Drinks = {
        {
            Name = "water",
            Label = "Water",
            Price = 4
        },
    },
    Ingredients = {
        {
            Name = "metal_scrap",
            Label = "Metal Scrap",
            Price = 4,
        },
        {
            Name = "gun_powder",
            Label = "Gun Powder",
            Price = 4,
        },
        {
            Name = "rubber",
            Label = "Rubber",
            Price = 4,
        },
        {
            Name = "cloth",
            Label = "Cloth",
            Price = 4,
        },
        {
            Name = "metal_plate",
            Label = "Metal Plate",
            Price = 4,
        },
    },
    InteractMarkers = {
        ["toggle_duty"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to clock-|clocked_status|.",
            Coords = vector3(18.91, -1107.3, 29.8),
            Display = false,
        },
        ["boss"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
            Coords = vector3(7.43572, -1109.09, 29.7854),
            Display = false,
        },
        ["ammunation_ingredients"] = {
            DisplayText = "Press ~INPUT_CONTEXT~ to get weapon parts.",
            Coords = vector3(4.167033, -1106.677, 29.7854),
            Display = false,
        },
        ["ammunation_oven"] = {
            DisplayText = "|oven_status|",
            Coords = vector3(13.60879, -1097.143, 29.81909),
            Display = false,
        },
    }
}

Config.Jobs.Barber = {
    Stores = {
        ["example"] = {
            Type = "nailsalon",
            Management = vector3(63.4, -1437.5, 29.31),--vector4(-801.4703, -610.8534, 30.27503, 148.2798)
            Chairs = {
                {
                    Location = vector3(68.87239, -1453.451, 28.31416),
                    Offset = vector3(0.0, -0.05, 0.4),
                    Heading = 142.49,
                    Model = -1291993936
                },
                {
                    Location = vector3(67.35264, -1452.132, 28.32528),
                    Offset = vector3(0.0, -0.05, 0.4),
                    Heading = 142.49,
                    Model = -1291993936,
                },
                {
                    Location = vector3(65.78946, -1450.775, 28.32528),
                    Offset = vector3(0.0, -0.05, 0.4),
                    Heading = 142.49,
                    Model = -1291993936,
                },
                {
                    Location = vector3(64.334, -1449.511, 28.36012),
                    Offset = vector3(0.0, -0.05, 0.4),
                    Heading = 142.49,
                    Model = -1291993936,
                },
            }
        },
    },
    Supplies = {
        Location = vector3(-129.09, -1716.92, 29.07),
        Items = {
            {
                Name = "bread",
                Label = "Bread",
                Price = 4,
            },
        }
    },
    Types = {
        ["barber"] = {
            Options = {
                {
                    text = "Haircut",
                    datatype = "hair_1",
                    value = 0,
                },
                {
                    text = "Haircut Color",
                    datatype = "hair_color_1",
                    value = 0,
                },
                {
                    text = "Beard Size",
                    datatype = "beard_2",
                    value = 0,
                },
                {
                    text = "Beard Type",
                    datatype = "beard_1",
                    value = 0,
                },
                {
                    text = "Beard Color",
                    datatype = "beard_3",
                    value = 0,
                },
            }
        },
        ["nailsalon"] = {
            Options = {
                {
                    text = "Haircut",
                    datatype = "hair_1",
                    value = 0,
                },
                {
                    text = "Haircut Color",
                    datatype = "hair_color_1",
                    value = 0,
                },
                {
                    text = "Beard Size",
                    datatype = "beard_2",
                    value = 0,
                },
                {
                    text = "Beard Type",
                    datatype = "beard_1",
                    value = 0,
                },
                {
                    text = "Beard Color",
                    datatype = "beard_3",
                    value = 0,
                },
                {
                    text = "Eyebrow Size",
                    datatype = "eyebrows_2",
                    value = 0,
                },
                {
                    text = "Eyebrow Type",
                    datatype = "eyebrows_1",
                    value = 0,
                },
                {
                    text = "Eyebrow Color",
                    datatype = "eyebrows_3",
                    value = 0,
                },
                {
                    text = "Makeup Type",
                    datatype = "makeup_1",
                    value = 0,
                },
                {
                    text = "Makeup Thickness",
                    datatype = "makeup_2",
                    value = 0,
                },
                {
                    text = "Makeup Color",
                    datatype = "makeup_3",
                    value = 0,
                },
                {
                    text = "Lipstick Type",
                    datatype = "lipstick_1",
                    value = 0,
                },
                {
                    text = "Lipstick Thickness",
                    datatype = "lipstick_2",
                    value = 0,
                },
                {
                    text = "Lipstick Color",
                    datatype = "lipstick_3",
                    value = 0,
                },
            }
        },
    }
}

Config.Jobs.Nailspa = {
    Stores = {
        ["example"] = {
            Type = "nailspa",
            Management = vector3(-801.2252, -610.7584, -30.27),--vector4(-801.2252, -610.7584, 30.27503, 152.6781)
            Chairs = {
                {
                    Location = vector3(-808.9031, -599.96, 29.43),--vector4(-808.9031, -599.9658, 31.02542, 148.1432)vector4(-808.9667, -600.0388, 31.02539, 327.6223)
                    Offset = vector3(0.0, -0.05, 0.4),
                    Heading = 146.60,--vector4(-809.0339, -600.1626, 31.01987, 146.6047)
                    Model = -1291993936
                },
                {
                    Location = vector3(-810.1174, -599.25, 29.43), --vector4(-810.1174, -599.2581, 31.02557, 332.712)
                    Offset = vector3(0.0, -0.05, 0.4),
                    Heading = 146.60,
                    Model = -1291993936,
                },
                {
                    Location = vector3(-812.8812, -597.66, 29.43), --vector4(-812.8812, -597.6689, 31.02539, 150.6086)
                    Offset = vector3(0.0, -0.05, 0.4),
                    Heading = 146.60,
                    Model = -1291993936,
                },
                {
                    Location = vector3(-813.9941, -597.02, 29.43), --vector4(-813.9941, -597.0264, 31.02539, 148.0676)
                    Offset = vector3(0.0, -0.05, 0.4),
                    Heading = 146.60,
                    Model = -1291993936,
                },
            }
        },
    },
    Types = {
        ["nailspa"] = {
            Options = {
                {
                    text = "Haircut",
                    datatype = "hair_1",
                    value = 0,
                },
                {
                    text = "Haircut Color",
                    datatype = "hair_color_1",
                    value = 0,
                },
                {
                    text = "Beard Size",
                    datatype = "beard_2",
                    value = 0,
                },
                {
                    text = "Beard Type",
                    datatype = "beard_1",
                    value = 0,
                },
                {
                    text = "Beard Color",
                    datatype = "beard_3",
                    value = 0,
                },
            }
        },
        ["nailspa"] = {
            Options = {
                {
                    text = "Haircut",
                    datatype = "hair_1",
                    value = 0,
                },
                {
                    text = "Haircut Color",
                    datatype = "hair_color_1",
                    value = 0,
                },
                {
                    text = "Beard Size",
                    datatype = "beard_2",
                    value = 0,
                },
                {
                    text = "Beard Type",
                    datatype = "beard_1",
                    value = 0,
                },
                {
                    text = "Beard Color",
                    datatype = "beard_3",
                    value = 0,
                },
                {
                    text = "Eyebrow Size",
                    datatype = "eyebrows_2",
                    value = 0,
                },
                {
                    text = "Eyebrow Type",
                    datatype = "eyebrows_1",
                    value = 0,
                },
                {
                    text = "Eyebrow Color",
                    datatype = "eyebrows_3",
                    value = 0,
                },
                {
                    text = "Makeup Type",
                    datatype = "makeup_1",
                    value = 0,
                },
                {
                    text = "Makeup Thickness",
                    datatype = "makeup_2",
                    value = 0,
                },
                {
                    text = "Makeup Color",
                    datatype = "makeup_3",
                    value = 0,
                },
                {
                    text = "Lipstick Type",
                    datatype = "lipstick_1",
                    value = 0,
                },
                {
                    text = "Lipstick Thickness",
                    datatype = "lipstick_2",
                    value = 0,
                },
                {
                    text = "Lipstick Color",
                    datatype = "lipstick_3",
                    value = 0,
                },
            }
        },
    }
}

Config.Jobs.Mechanic = {
    Shops = {
        ["example"] = {
            InteractMarkers = {
                ["workbench"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to grab a vehicle part.",
                    Coords = vector3(130.53, -3031.82, 7.10),
                    Display = true,
                },
                ["boss"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
                    Coords = vector3(128.56, -3011.38, 7.2),
                    Display = true,
                },
            },
        }
    },
    VehicleParts = {
        {
            Name = "modEngine",
            Label = "Engines",
            ModType = 11,
            Items = {}
        },
        {
            Name = "modTurbo",
            Label = "Turbo",
            ModType = 17,
            Items = {}
        },
        {
            Name = "modBrakes",
            Label = "Brakes",
            ModType = 12,
            Items = {}
        },
        -- {
        -- Name = "modArmor",
        -- Label = "Armor",
        -- ModType = 16,
        -- Items = {}
        -- },
        {
            Name = "modSuspension",
            Label = "Suspension",
            ModType = 15,
            Items = {}
        },
        {
            Name = "modTransmission",
            Label = "Transmission",
            ModType = 13,
            Items = {}
        },
        {
            Name = "repair",
            Label = "Repair",
            Items = {}
        },
    },
    CarryingSettings = {
        ["modEngine"] = { "anim@heists@box_carry@", "idle", "Engine", AnimationOptions =
        {
            Prop = "prop_car_engine_01",
            PropBone = 60309,
            PropPlacement = { 0.2, 0.2, 0.08, -55.0, 290.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modArmor"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTurbo"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modBrakes"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modSuspension"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTransmission"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["repair"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
    }
}

Config.Jobs.Sunrise = {
    Shops = {
        ["sunrise"] = {
            InteractMarkers = {
                ["workbench2"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to grab a vehicle part.",
                    Coords = vector3(-330.41, -130.75, 39.40),
                    Display = true,
                },
                ["boss"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
                    Coords = vector3(-330.52, -161.59, 39.40),
                    Display = true,
                },
            },
        }
    },
    VehicleParts2 = {
        {
            Name = "modEngine",
            Label = "Engines",
            ModType = 11,
            Items = {}
        },
        {
            Name = "modTurbo",
            Label = "Turbo",
            ModType = 17,
            Items = {}
        },
        {
            Name = "modBrakes",
            Label = "Brakes",
            ModType = 12,
            Items = {}
        },
        {
            Name = "modSuspension",
            Label = "Suspension",
            ModType = 15,
            Items = {}
        },
        {
            Name = "modTransmission",
            Label = "Transmission",
            ModType = 13,
            Items = {}
        },
        {
            Name = "repair",
            Label = "Repair",
            Items = {}
        },
    },
    CarryingSettings = {
        ["modEngine"] = { "anim@heists@box_carry@", "idle", "Engine", AnimationOptions =
        {
            Prop = "prop_car_engine_01",
            PropBone = 60309,
            PropPlacement = { 0.2, 0.2, 0.08, -55.0, 290.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modArmor"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTurbo"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modBrakes"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modSuspension"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTransmission"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["repair"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
    }
}

Config.Jobs.Bennys = {
    Shops = {
        ["bennys"] = {
            InteractMarkers = {
                ["workbench3"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to grab a vehicle part.",
                    Coords = vector3(-214.42, -1338.86, 31.30),
                    Display = true,
                },
                ["boss"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
                    Coords = vector3(-192.84, -1318.27, 31.30),
                    Display = true,
                },
            },
        }
    },
    VehicleParts3 = {
        {
            Name = "modEngine",
            Label = "Engines",
            ModType = 11,
            Items = {}
        },
        {
            Name = "modTurbo",
            Label = "Turbo",
            ModType = 17,
            Items = {}
        },
        {
            Name = "modBrakes",
            Label = "Brakes",
            ModType = 12,
            Items = {}
        },
        {
            Name = "modSuspension",
            Label = "Suspension",
            ModType = 15,
            Items = {}
        },
        {
            Name = "modTransmission",
            Label = "Transmission",
            ModType = 13,
            Items = {}
        },
        {
            Name = "repair",
            Label = "Repair",
            Items = {}
        },
    },
    CarryingSettings = {
        ["modEngine"] = { "anim@heists@box_carry@", "idle", "Engine", AnimationOptions =
        {
            Prop = "prop_car_engine_01",
            PropBone = 60309,
            PropPlacement = { 0.2, 0.2, 0.08, -55.0, 290.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modArmor"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTurbo"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modBrakes"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modSuspension"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTransmission"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["repair"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
    }
}

Config.Jobs.Autoexotic = {
    Shops = {
        ["autoexotic"] = {
            InteractMarkers = {
                ["workbench6"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to grab a vehicle part.",
                    Coords = vector3(560.1313, -181.2029, 54.50), 
                    Display = true,
                },
                ["boss"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
                    Coords = vector3(559.71, -196.0079, 58.152), 
                    Display = true,
                },
            },
        }
    },
    VehicleParts6 = {
        {
            Name = "modEngine",
            Label = "Engines",
            ModType = 11,
            Items = {}
        },
        {
            Name = "modTurbo",
            Label = "Turbo",
            ModType = 17,
            Items = {}
        },
        {
            Name = "modBrakes",
            Label = "Brakes",
            ModType = 12,
            Items = {}
        },
        {
            Name = "modSuspension",
            Label = "Suspension",
            ModType = 15,
            Items = {}
        },
        {
            Name = "modTransmission",
            Label = "Transmission",
            ModType = 13,
            Items = {}
        },
        {
            Name = "repair",
            Label = "Repair",
            Items = {}
        },
    },
    CarryingSettings = {
        ["modEngine"] = { "anim@heists@box_carry@", "idle", "Engine", AnimationOptions =
        {
            Prop = "prop_car_engine_01",
            PropBone = 60309,
            PropPlacement = { 0.2, 0.2, 0.08, -55.0, 290.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modArmor"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTurbo"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modBrakes"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modSuspension"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTransmission"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["repair"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
    }
}

Config.Jobs.Hayes = {
    Shops = {
        ["hayes"] = {
            InteractMarkers = {
                ["workbench7"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to grab a vehicle part.",
                    Coords = vector3(-1414.602, -451.1312, 35.90),  --vector4(-1414.602, -451.1312, 35.90972, 209.6467)
                    Display = true,
                },
                ["boss"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
                    Coords = vector3(-1428.261, -458.4274, 35.90),  --vector4(-1428.261, -458.4274, 35.90973, 184.9057)
                    Display = true,
                },
            },
        }
    },
    VehicleParts7 = {
        {
            Name = "modEngine",
            Label = "Engines",
            ModType = 11,
            Items = {}
        },
        {
            Name = "modTurbo",
            Label = "Turbo",
            ModType = 17,
            Items = {}
        },
        {
            Name = "modBrakes",
            Label = "Brakes",
            ModType = 12,
            Items = {}
        },
        {
            Name = "modSuspension",
            Label = "Suspension",
            ModType = 15,
            Items = {}
        },
        {
            Name = "modTransmission",
            Label = "Transmission",
            ModType = 13,
            Items = {}
        },
        {
            Name = "repair",
            Label = "Repair",
            Items = {}
        },
    },
    CarryingSettings = {
        ["modEngine"] = { "anim@heists@box_carry@", "idle", "Engine", AnimationOptions =
        {
            Prop = "prop_car_engine_01",
            PropBone = 60309,
            PropPlacement = { 0.2, 0.2, 0.08, -55.0, 290.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modArmor"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTurbo"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modBrakes"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modSuspension"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTransmission"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["repair"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
    }
}

Config.Jobs.Pitstop = {
    Shops = {
        ["pitstop"] = {
            InteractMarkers = {
                ["workbench4"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to grab a vehicle part.",
                    Coords = vector3(947.25, -1552.18, 30.73),
                    Display = true,
                },
                ["boss"] = {
                    DisplayText = "Press ~INPUT_CONTEXT~ to open the management menu.",
                    Coords = vector3(958.46, -1570.78, 30.73),
                    Display = true,
                },
            },
        }
    },
    VehicleParts4 = {
        {
            Name = "modEngine",
            Label = "Engines",
            ModType = 11,
            Items = {}
        },
        {
            Name = "modTurbo",
            Label = "Turbo",
            ModType = 17,
            Items = {}
        },
        {
            Name = "modBrakes",
            Label = "Brakes",
            ModType = 12,
            Items = {}
        },
        {
            Name = "modSuspension",
            Label = "Suspension",
            ModType = 15,
            Items = {}
        },
        {
            Name = "modTransmission",
            Label = "Transmission",
            ModType = 13,
            Items = {}
        },
        {
            Name = "repair",
            Label = "Repair",
            Items = {}
        },
    },
    CarryingSettings = {
        ["modEngine"] = { "anim@heists@box_carry@", "idle", "Engine", AnimationOptions =
        {
            Prop = "prop_car_engine_01",
            PropBone = 60309,
            PropPlacement = { 0.2, 0.2, 0.08, -55.0, 290.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modArmor"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTurbo"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modBrakes"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modSuspension"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["modTransmission"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_carjack",
            PropBone = 60309,
            PropPlacement = { 0.025, 0.08, 0.255, -55.0, 0.0, -20.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
        ["repair"] = { "anim@heists@box_carry@", "idle", "gearbox", AnimationOptions =
        {
            Prop = "prop_idol_case_02",
            PropBone = 60309,
            PropPlacement = { 0.0, -0.08, 0.3, -55.0, 310.0, 0.0 },
            EmoteLoop = true,
            EmoteMoving = true,
        } },
    }
}

Config.Jobs.Bus = {
    Locations = {
        ["start"] = {
            coords = vector3(433.72, -645.72, 28.73),
            labelText = "Press ~INPUT_CONTEXT~ to start working."
        }
    },
    VehicleSpawn = {
        model = "bus",
        coords = vector3(429.31, -645.65, 28.5),
        heading = 180.0
    },
    PayoutPerMeter = 0.75
}

Config.Jobs.Taxi = {
    Locations = {
        ["start"] = {
            coords = vector3(903.22, -173.3, 74.14),
            labelText = "Press ~INPUT_CONTEXT~ to start working."
        }
    },
    VehicleSpawn = {
        model = "taxi",
        coords = vector3(907.62, -176.18, 74.14),
        heading = 238.45
    },
    PayoutPerMeter = 0.75
}

Config.Emotes = {
    ["mechanic"] = { "mini@repair", "fixing_a_ped", "Mechanic", AnimationOptions =
    {
        EmoteLoop = true,
        EmoteMoving = true,
    } },
    ["fmdbundlesbox"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Bundles Box", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.17, 0.02, 0.09, -156.0, 126.0, 1.0},
        SecondProp = 'fmd_bundleboxempty',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.16, 0.02, -0.11, -171.0, 77.0, 6.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlesbox2"] = {"anim@move_f@waitress", "idle", "~y~5MDevs~c~ Exit Bundles Box", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 58866,
        PropPlacement = {0.09, -0.04, 0.0, -268.0, 82.0, 101.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},    
    ["rbundlesdye1"] = {"leafystiranimation", "leafstir_anim", "~y~5MDevs~c~ Collecting Red Dye", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebaser', 
         SecondPropBone = 18905,
         SecondPropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},
    ["pbundlesdye1"] = {"missheistdockssetup1clipboard@base", "base", "~y~5MDevs~c~ Collecting Pink Dye", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebaseccp',
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},   
    ["bbundlesdye1"] = {"missheistdockssetup1clipboard@base", "base", "~y~5MDevs~c~ Collecting Blonde Dye", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebaseblo',
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},  
    
    ["ftbundlesdye1"] = {"leafystiranimation", "leafstir_anim", "~y~5MDevs~c~ Collecting 427 Dye", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebase427', 
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},
    ["aubbundlesdye1"] = {"missheistdockssetup1clipboard@base", "base", "~y~5MDevs~c~ Collecting Auburn Dye", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebaseau',
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},   
    ["blabundlesdye1"] = {"missheistdockssetup1clipboard@base", "base", "~y~5MDevs~c~ Collecting Black Dye", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebaseb',
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }}, 
    ["brobundlesdye1"] = {"leafystiranimation", "leafstir_anim", "~y~5MDevs~c~ Collecting Brown Dye", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebasebr', 
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},
    ["platbbundlesdye1"] = {"missheistdockssetup1clipboard@base", "base", "~y~5MDevs~c~ Collecting Platinum Dye", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebasepl',
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},   
 
    ["ccbbundlesdye1"] = {"leafystiranimation", "leafstir_anim", "~y~5MDevs~c~ Collecting Blue Dye", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebaseccblue', 
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},
    ["lgbundlesdye1"] = {"missheistdockssetup1clipboard@base", "base", "~y~5MDevs~c~ Collecting Green Dye", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebaselg',
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},   
    ["purpbundlesdye1"] = {"missheistdockssetup1clipboard@base", "base", "~y~5MDevs~c~ Collecting Purple Dye", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebasep',
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }}, 
    ["mbbundlesdye1"] = {"leafystiranimation", "leafstir_anim", "~y~5MDevs~c~ Collecting Midnight Blue Dye", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebasenb', 
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},
 
    ["bkbbundlesdye1"] = {"missheistdockssetup1clipboard@base", "base", "~y~5MDevs~c~ Collecting Black Dye Curly", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebaseb',
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},   
    ["kblubundlesdye1"] = {"missheistdockssetup1clipboard@base", "base", "~y~5MDevs~c~ Collecting Blue Dye Curly", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebaseccblue',
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},  
    ["kbbundlesdye1"] = {"missheistdockssetup1clipboard@base", "base", "~y~5MDevs~c~ Collecting Blonde Dye Curly", AnimationOptions =
    {
         Prop = 'fmd_grabdyebowl',
         PropBone = 18905,
         PropPlacement = {0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         SecondProp = 'fmd_grabdyebaseblo',
         SecondPropBone = 18905,
         SecondPropPlacement = { 0.12, -0.01, 0.01, 25.0, 15.0, -111.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }}, 
    ["bundlesdyesinkr"] = {"missheist_agency3aig_23", "urinal_sink_loop", "~y~5MDevs~c~ Dying Red Bundles", AnimationOptions =
    {
         Prop = 'fmd_bundlesconditioner',
         PropBone = 18905,
         PropPlacement = {0.14, 0.11, -0.02, 115.0, 70.0, 8.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},
    ["pbundlesdye"] = {"missheist_agency3aig_23", "urinal_sink_loop", "~y~5MDevs~c~ Dying Pink Bundles", AnimationOptions =
    {
         Prop = 'fmd_bundlesccpink',
         PropBone = 18905,
         PropPlacement = {0.1, -0.1, 0.0, -80.0, 0.0, 0.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},   
    ["bbundlesdye"] = {"missheist_agency3aig_23", "urinal_sink_loop", "~y~5MDevs~c~ Dying Blonde Bundles", AnimationOptions =
    {
         Prop = 'fmd_bundlesblonde',
         PropBone = 18905,
         PropPlacement = {0.1, -0.1, 0.0, -80.0, 0.0, 0.0},
         EmoteLoop = true,
         EmoteMoving = true,
    }},
    ["bundlessinkdye"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Red Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["rbundlessink"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Red Bundles", AnimationOptions =
    {
        Prop = 'fmd_developer40',
        PropBone = 57005,
        PropPlacement = {0.17, 0.14, 0.0, 118.0, -1.0, -22.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["pbundlessink"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Pink Bundles", AnimationOptions =
    {
        Prop = 'fmd_developer30',
        PropBone = 57005,
        PropPlacement = { 0.17, 0.14, 0.0, 118.0, -1.0, -22.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bbundlessink"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Blonde Bundles", AnimationOptions =
    {
        Prop = 'fmd_developer20',
        PropBone = 57005,
        PropPlacement = {0.17, 0.14, 0.0, 118.0, -1.0, -22.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlessinkdyer"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Red Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixedr',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},  
    ["bundlessinkdyebl"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Blonde Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixedblo',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    
    ["bundlessinkdyeft"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink 427 Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixed427',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlessinkdyeau"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Auburn Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixedau',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        AdditionalProps = {
            {
                Prop = 'fmd_grabdyebowl',
                PropBone = 57005,
                PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
            },
        },
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlessinkdyeb"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Black Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixedb',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlessinkdyeblo"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Blonde Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixedblo',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlessinkdyebr"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Brown Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixedbr',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlessinkdyeccb"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Blue Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixedccblue',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlessinkdyeccp"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Pink Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixedccp',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlessinkdyelg"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Green Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixedlg',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlessinkdyenb"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Midnight Blue Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixednb',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlessinkdyep"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Purple Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixedp',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bundlessinkdyepl"] = {"leafyshampooanimation", "shampoo_anim", "~y~5MDevs~c~ Exit Sink Platinum Bundles", AnimationOptions =
    {
        Prop = 'fmd_grabdyebowl',
        PropBone = 57005,
        PropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        SecondProp = 'fmd_grabdyemixedpl',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.19, 0.04, -0.06, 135.0, 25.0, -111.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
 
    ["rbundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Red Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.21, 0.05, 0.09, -23.0, -60.0, -40.0},
        SecondProp = 'fmd_bundlesred',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["pbundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Pink Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.2, 0.0, 0.1, -40.0, -60.0, 0.0},
        SecondProp = 'fmd_bundlesccpink',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bbundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Blonde Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.2, 0.0, 0.1, -40.0, -60.0, 0.0},
        SecondProp = 'fmd_bundlesblonde',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},    
    ["ftbundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing 427 Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.21, 0.05, 0.09, -23.0, -60.0, -40.0},
        SecondProp = 'fmd_bundles427',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["aubundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Auburn Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.2, 0.0, 0.1, -40.0, -60.0, 0.0},
        SecondProp = 'fmd_bundlesauburn',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["blabundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Black Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.2, 0.0, 0.1, -40.0, -60.0, 0.0},
        SecondProp = 'fmd_bundlesblack',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }}, 
    ["brbundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Brown Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.21, 0.05, 0.09, -23.0, -60.0, -40.0},
        SecondProp = 'fmd_bundlesbrown',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["plbundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Platinum Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.2, 0.0, 0.1, -40.0, -60.0, 0.0},
        SecondProp = 'fmd_bundlesplatinum',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["ccbbundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Blue Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.2, 0.0, 0.1, -40.0, -60.0, 0.0},
        SecondProp = 'fmd_bundlesblondeccblue',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["lgbundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Lime Green Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.21, 0.05, 0.09, -23.0, -60.0, -40.0},
        SecondProp = 'fmd_bundleslime',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["pubundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Purple Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.2, 0.0, 0.1, -40.0, -60.0, 0.0},
        SecondProp = 'fmd_bundlespurp',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["nbbundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Midnight Blue Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.2, 0.0, 0.1, -40.0, -60.0, 0.0},
        SecondProp = 'fmd_bundlesniteblue',
        SecondPropBone = 57005,
        SecondPropPlacement = {0.11, -0.05, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},       
    ["kblabundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Curly Black Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.21, 0.05, 0.09, -23.0, -60.0, -40.0},
        SecondProp = 'fmd_bundleskinkyblack',
        SecondPropBone = 57005,
        SecondPropPlacement = { 0.16, 0.03, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["kblobundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing Curly Blonde Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.2, 0.0, 0.1, -40.0, -60.0, 0.0},
        SecondProp = 'fmd_bundleskinkyblonde',
        SecondPropBone = 57005,
        SecondPropPlacement = { 0.16, 0.03, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["kblubundlesboxes"] = {"boxpursesanimation", "boxpurse_anim", "~y~5MDevs~c~ Boxing C Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxempty',
        PropBone = 18905,
        PropPlacement = {0.2, 0.0, 0.1, -40.0, -60.0, 0.0},
        SecondProp = 'fmd_bundleskinkyblue',
        SecondPropBone = 57005,
        SecondPropPlacement = { 0.16, 0.03, -0.1, 15.0, 40.0, 0.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},    
    
    
    ["rbundlesend"] = {"anim@move_f@waitress", "idle", "~y~5MDevs~c~ Done Boxing Red Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxred',
        PropBone = 58866,
        PropPlacement = {0.09, -0.04, 0.0, -268.0, 82.0, 101.0},
        SecondProp = 'fmd_bundlebag',
        SecondPropBone = 18905,
        SecondPropPlacement = {0.65, -0.04, 0.07, -232.0, 33.0, 262.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["mechanic2"] = {
        "mini@repair",
        "fixing_a_player",
        "Mechanic 2",
        AnimationOptions = {
        EmoteLoop = true,
        EmoteMoving = true,
        }
    },
    ["pbundlesend"] = {"anim@move_f@waitress", "idle", "~y~5MDevs~c~ Done Boxing Pink Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxccpink',
        PropBone = 58866,
        PropPlacement = {0.09, -0.04, 0.0, -268.0, 82.0, 101.0},
        SecondProp = 'fmd_bundlebag',
        SecondPropBone = 18905,
        SecondPropPlacement = {0.65, -0.04, 0.07, -232.0, 33.0, 262.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
    ["bbundlesend"] = {"anim@move_f@waitress", "idle", "~y~5MDevs~c~ Done Boxing Blonde Bundles", AnimationOptions =
    {
        Prop = 'fmd_bundleboxblonde',
        PropBone = 58866,
        PropPlacement = {0.09, -0.04, 0.0, -268.0, 82.0, 101.0},
        SecondProp = 'fmd_bundlebag',
        SecondPropBone = 18905,
        SecondPropPlacement = {0.65, -0.04, 0.07, -232.0, 33.0, 262.0},
        EmoteLoop = true,
        EmoteMoving = true,
    }},
}

Config.UsableItems = {
    ["donut_sprinkled"] = {
        client = function()
            if PlayerData.job.name == "police" then
                AddArmourToPed(PlayerPedId(), 25)
            end
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("donut_sprinkled", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 500000)
            TriggerClientEvent('esx_donut_sprinkled:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Sprinkled Donut")
            cb(true)
        end,
    },
    ["donut_glazed"] = {
        client = function()
            if PlayerData.job.name == "police" then
                AddArmourToPed(PlayerPedId(), 25)
            end
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("donut_glazed", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 500000)
            TriggerClientEvent('esx_donut_glazed:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Glazed Donut")
            cb(true)
        end,
    },
    ["donut_chocolate"] = {
        client = function()
            if PlayerData.job.name == "police" then
                AddArmourToPed(PlayerPedId(), 25)
            end
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("donut_chocolate", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 500000)
            TriggerClientEvent('esx_donut_chocolate:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Choclate Donut")
            cb(true)
        end,
    },
    ["donut_strawberry"] = {
        client = function()
            if PlayerData.job.name == "police" then
                AddArmourToPed(PlayerPedId(), 25)
            end
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("donut_strawberry", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 500000)
            TriggerClientEvent('esx_donut_sprinkled:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Strawberry Donut")
            cb(true)
        end,
    },
    ["donut_vanilla"] = {
        client = function()
            if PlayerData.job.name == "police" then
                AddArmourToPed(PlayerPedId(), 25)
            end
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("donut_vanilla", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 500000)
            TriggerClientEvent('esx_donut_vanilla:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Vanilla Donut")
            cb(true)
        end,
    },
    ["pizza_cheese"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("pizza_cheese", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_jetscheese:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Cheese Pizza")
            cb(true)
        end,
    },
    ["pizza_pepperoni"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("pizza_pepperoni", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_jetspep:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Pepperoni Pizza")
            cb(true)
        end,
    },
    ["pizza_bbq_chicken"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("pizza_bbq_chicken", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_jetsbbq:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x BBQ Chicken Pizza")
            cb(true)
        end,
    },
    ["coffee"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("coffee", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 500000)
            TriggerClientEvent('esx_dunkinlatte:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Coffee")
            cb(true)
        end,
    },
    ["cocacola"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("cocacola", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 500000)
            TriggerClientEvent('esx_cocacola:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x CocaCola")
            cb(true)
        end,
    },
    ["diet_cola"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("diet_cola", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 500000)
            TriggerClientEvent('esx_dietcola:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Diet Coke")
            cb(true)
        end,
    },
    ["icetea"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("icetea", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 500000)
            TriggerClientEvent('esx_icetea:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x IcedTea")
            cb(true)
        end,
    },
    ["iced_coffee"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("iced_coffee", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 500000)
            TriggerClientEvent('esx_icedcoffee:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Iced Coffee")
            cb(true)
        end,
    },
    ["chicken_parm"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("chicken_parm", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_chickenparm:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Chicken Parm")
            cb(true)
        end,
    },
    ["calzone"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("calzone", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_calzone:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Calzone")
            cb(true)
        end,
    },
    ["brick_pizza"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("brick_pizza", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_basicneeds:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Brick Pizza")
            cb(true)
        end,
    },
    ["lasagna"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("lasagna", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_lasagna:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Lasagna")
            cb(true)
        end,
    },
    ["ravioli"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("ravioli", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_ravioli:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Ravioli")
            cb(true)
        end,
    },
    ["gelato"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("gelato", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 400000)
            TriggerClientEvent('esx_gelato:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Gelato")
            cb(true)
        end,
    },
    ["cannoli"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("cannoli", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 400000)
            TriggerClientEvent('esx_cannoli:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Cannoli")
            cb(true)
        end,
    },
    ["cookie"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("cookie", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 500000)
            TriggerClientEvent('esx_cookie:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Cookie")
            cb(true)
        end,
    },
    ["chicken_nuggets"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("chicken_nuggets", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_nuggets:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Chicken Nuggets")
            cb(true)
        end,
    },
    ["french_fries"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("french_fries", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 500000)
            TriggerClientEvent('esx_chickfilafries:onEat', source)
            cb(true)
        end,
    },
    ["chicken_sandwich"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("chicken_sandwich", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_chickensandwich:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Chicken Sanwich")
            cb(true)
        end,
    },
    ---NEW ITEMS---
    ["bbq_friedchicken"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("bbq_friedchicken", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_bbq_fried_chicken:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "you have used 1x BBQ Fried Chicken")
            cb(true)
        end,
    },
    ["kfc_chicken_sandwich"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("kfc_chicken_sandwich", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_chickensandwich:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Chicken Sandwich")
            cb(true)
        end,
    },
    ["kfc_frenchfries"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("kfc_frenchfries", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_kfcfries:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "you have used 1x Fries")
            cb(true)
        end,
    },
    ["latte"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("latte", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 500000)
            TriggerClientEvent('esx_dunkinlatte:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "you have used 1x Latte")
            cb(true)
        end,
    },
    ["espresso"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("espresso", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 400000)
            TriggerClientEvent('esx_mirrorespresso:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "you have used 1x Espresso")
            cb(true)
        end,
    },
    ["italian_soda"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("italian_soda", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 400000)
            TriggerClientEvent('esx_mirrorsoda:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "you have used 1x Italian Soda")
            cb(true)
        end,
    },
    ["milkshake"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("milkshake", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 400000)
            TriggerClientEvent('esx_milkshake:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "you have used 1x Milkshake")
            cb(true)
        end,
    },
    ["mirror_shot"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("mirror_shot", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 200000)
            --TriggerClientEvent('acidtrip:acidtab', source)
            TriggerClientEvent('esx_mirrorshot:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Mirror Shot")
            cb(true)
        end,
    },
    ["taco"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("taco", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_basicneeds:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Taco")
            cb(true)
        end,
    },
    ["burrito"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("burrito", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_basicneeds:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Burrito")
            cb(true)
        end,
    },
    ["quesadilla"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("quesadilla", 1)
            TriggerClientEvent('esx_status:add', source, 'hunger', 800000)
            TriggerClientEvent('esx_basicneeds:onEat', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Quesadilla")
            cb(true)
        end,
    },
    ["jarritosorange"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("jarritosorange", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 400000)
            TriggerClientEvent('esx_jarritoorange:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Jarritos")
            cb(true)
        end,
    },
    ["jarritosred"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("jarritosred", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 400000)
            TriggerClientEvent('esx_jarritored:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Jarritos")
            cb(true)
        end,
    },
    ["jarritosyellow"] = {
        client = function()
        end,
        server = function(source, cb)
            local xPlayer = ESX.GetPlayerFromId(source)
            xPlayer.removeInventoryItem("jarritosyellow", 1)
            TriggerClientEvent('esx_status:add', source, 'thirst', 400000)
            TriggerClientEvent('esx_jarritoyellow:onDrink', source)
            TriggerClientEvent("esx:showNotification", source, "You have used 1x Jarritos")
            cb(true)
        end,
    },
}

PartStores = {
    ["mechanic_parts"] = {
        job = "mechanic",
        coords = vector3(148.66, -3050.37, 7.04),
        menu = {
            label = "Mechanic Parts",
            text = "This is where you can grab parts for your crafting."
        },
        items = {
            {
                Name = "metal_scrap",
                Label = "Metal Scrap",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "jumper_cables",
                Label = "Jumper Cables",
                Price = 1000,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "wrench",
                Label = "Wrench",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["hayes_parts"] = {
        job = "hayes",
        coords = vector3(-1410.268, -439.1494, 35.909), --vector4(-1410.268, -439.1494, 35.90973, 294.2087)
        menu = {
            label = "Mechanic Parts",
            text = "This is where you can grab parts for your crafting."
        },
        items = {
            {
                Name = "metal_scrap",
                Label = "Metal Scrap",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "jumper_cables",
                Label = "Jumper Cables",
                Price = 1000,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "wrench",
                Label = "Wrench",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["sunrise_parts"] = {
        job = "sunrise",
        coords = vector3(-350.27, -121.50, 39.06),
        menu = {
            label = "Mechanic Parts",
            text = "This is where you can grab parts for your crafting."
        },
        items = {
            {
                Name = "metal_scrap",
                Label = "Metal Scrap",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "jumper_cables",
                Label = "Jumper Cables",
                Price = 1000,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "wrench",
                Label = "Wrench",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["bennys_parts"] = {
        job = "bennys",
        coords = vector3(-206.09, -1334.371, 31.30),
        menu = {
            label = "Mechanic Parts",
            text = "This is where you can grab parts for your crafting."
        },
        items = {
            {
                Name = "metal_scrap",
                Label = "Metal Scrap",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "jumper_cables",
                Label = "Jumper Cables",
                Price = 1000,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "wrench",
                Label = "Wrench",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["mosleys_parts"] = {
        job = "mosleys",
        coords = vector3(-13.69, -1663.12, 29.42), ----{ x = -13.6957836151123, y = -1663.128173828125, z = 29.42808532714843, h = 35.37131881713867 }
        menu = {
            label = "Mechanic Parts",
            text = "This is where you can grab parts for your crafting."
        },
        items = {
            {
                Name = "metal_scrap",
                Label = "Metal Scrap",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "jumper_cables",
                Label = "Jumper Cables",
                Price = 1000,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "wrench",
                Label = "Wrench",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["pitstop_parts"] = {
        job = "pitstop",
        coords = vector3(940.25, -1554.18, 30.73),
        menu = {
            label = "Mechanic Parts",
            text = "This is where you can grab parts for your crafting."
        },
        items = {
            {
                Name = "metal_scrap",
                Label = "Metal Scrap",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "jumper_cables",
                Label = "Jumper Cables",
                Price = 1000,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "wrench",
                Label = "Wrench",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["autoexotic_parts"] = {
        job = "autoexotic",
        coords = vector3(555.5486, -172.3054, 54.50), 
        menu = {
            label = "Mechanic Parts",
            text = "This is where you can grab parts for your crafting."
        },
        items = {
            {
                Name = "metal_scrap",
                Label = "Metal Scrap",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "jumper_cables",
                Label = "Jumper Cables",
                Price = 1000,
                CraftTimer = 10, -- Seconds
            },
            {
                Name = "wrench",
                Label = "Wrench",
                Price = 500,
                CraftTimer = 10, -- Seconds
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["police_parts"] = {
        job = "police",
        coords = vector3(484.46, -995.53, 30.69),
        menu = {
            label = "Police Items",
            text = "This is where you can grab items for your patrol."
        },
        items = {
            {
                Name = "ammo-9pd",
                Label = "9MM PD+",
                Price = 1000,
                CraftTimer = 10,
                Amount = 25,
            },
            {
                Name = "ammo-riflepd",
                Label = "5.56 PD+",
                Price = 1000,
                CraftTimer = 10,
                Amount = 25,
            },
            {
                Name = "ammo-shotgunpd",
                Label = "12-Gauge PD+",
                Price = 1000,
                CraftTimer = 10,
                Amount = 25,
            },
            {
                Name = "ammo-heavysniper",
                Label = ".50 BMG",
                Price = 500,
                CraftTimer = 10,
                Amount = 20,
            },
            {
                Name = "ammo-tazer",
                Label = "Taser Shotgun Shell",
                Price = 100,
                CraftTimer = 10,
                Amount = 25,
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["prison_parts"] = {
        job = nil, -- if job == nil, all can use.
        coords = vector3(1688.05, 2550.22, 45.50),
        menu = {
            label = "Prison [Staff Only]",
            text = "Prison Yard Utilities."
        },
        items = {
            {
                Name = "lighter",
                Label = "Lighter",
                Price = 100,
                CraftTimer = 20,
                Amount = 1,
            },
            {
                Name = "shaving_kit",
                Label = "Shaving Kit",
                Price = 100,
                CraftTimer = 20,
                Amount = 1,
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["ammunation_parts"] = {
        job = "ammunation",
        coords = vector3(10.93, -1110.7, 29.8),
        menu = {
            label = "Ammunation Items",
            text = "This is where you can grab items for your store."
        },
        items = {
            {
                Name = "ammo-38",
                Label = ".38 Long Colt",
                Price = 2500,
                CraftTimer = 25, 
                Amount = 20,
            },
            {
                Name = "ammo-44",
                Label = ".44 Magnum",
                Price = 2500,
                CraftTimer = 25, 
                Amount = 20,
            },
            {
                Name = "ammo-50",
                Label = ".50 AE",
                Price = 2500,
                CraftTimer = 25, 
                Amount = 20,
            },
            {
                Name = "ammo-45",
                Label = ".45 ACP",
                Price = 5000,
                CraftTimer = 25, 
                Amount = 20,
            },			
            {
                Name = "ammo-9",
                Label = "9mm",
                Price = 5000,
                CraftTimer = 25, 
                Amount = 20,
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
   ["smokeys_parts"] = {
        job = "smokeys", -- if job == nil, all can use.
        coords = vector3(1122.28, -980.6511, 46.41), --vector4(1122.28, -980.6511, 46.4104, 6.107523)
        interact = "Press ~INPUT_CONTEXT~ to collect buds.",
        heading = 2.23,--vector4(1122.26, -980.811, 46.41288, 2.237972)
        menu = {
            label = "Smokeys",
            text = "This is where you can grab parts for your crafting."
        },
        items = {	
            {
                Name = "smokebuds",
                Label = "Weed Buds",
                Price = 5,
				Amount = 1,				
                CraftTimer = 5, -- Seconds
                Emote = "mechanic2",
            },				
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
   ["zaza_parts"] = {
        job = "zaza", -- if job == nil, all can use.
        coords = vector3(164.5185, -238.6058, 50.05), --vector4(164.5185, -238.6058, 50.05528, 93.94781)vector4(164.4698, -238.8631, 50.06504, 156.4016)
        interact = "Press ~INPUT_CONTEXT~ to collect buds.",
        heading = 156.40,
        menu = {
            label = "Zaza",
            text = "This is where you can grab parts for your crafting."
        },
        items = {	
            {
                Name = "zaza",
                Label = "Weed Buds",
                Price = 5,
				Amount = 1,				
                CraftTimer = 5, -- Seconds
                Emote = "mechanic2",
            },				
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
   ["zaza_parts2"] = {
        job = "zaza", -- if job == nil, all can use.
        coords = vector3(170.8323, -240.8806, 50.065), 
        interact = "Press ~INPUT_CONTEXT~ to collect buds.",
        heading = 156.40,
        menu = {
            label = "Zaza",
            text = "This is where you can grab parts for your crafting."
        },
        items = {	
            {
                Name = "zaza",
                Label = "Weed Buds",
                Price = 5,
				Amount = 1,
                CraftTimer = 5, -- Seconds
                Emote = "mechanic2",
            },				
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
   ["zaza_parts3"] = {
        job = "zaza", -- if job == nil, all can use.
        coords = vector3(175.6893, -239.3375, 50.00), --vector4(175.6893, -239.3375, 50.0553, 159.8236)
        interact = "Press ~INPUT_CONTEXT~ to collect bags.",
        heading = 156.40,
        menu = {
            label = "Zaza",
            text = "This is where you can grab parts for your crafting."
        },
        items = {	
            {
                Name = "drugbags",
                Label = "Weed Bag",
                Price = 5,
				Amount = 5,
                CraftTimer = 5, -- Seconds
                Emote = "mechanic2",
            },				
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
   ["smokeys_parts2"] = {
        job = "smokeys", -- if job == nil, all can use.
        coords = vector3(1123.691, -986.1461, 46.36), --vector4(1123.691, -986.1461, 46.36982, 274.2537)
        interact = "Press ~INPUT_CONTEXT~ to collect parts.",
        heading = 274.25,
        menu = {
            label = "Smokeys",
            text = "This is where you can grab parts for your crafting."
        },
        items = {	
            {
                Name = "drugbags",
                Label = "Weed Bag",
                Price = 5,
				Amount = 5,
                CraftTimer = 5, -- Seconds
                Emote = "mechanic2",
            },	
            {
                Name = "n2o_empty",
                Label = "N₂O Tank",
                Price = 5,
				Amount = 5,
                CraftTimer = 5, -- Seconds
                Emote = "mechanic2",
            },	
            {
                Name = "ammonium_nitrate",
                Label = "Ammonium Nitrate",
                Price = 5,
				Amount = 5,
                CraftTimer = 5, -- Seconds
                Emote = "mechanic2",
            },				
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["nailspa_parts"] = {
        job = "nailspa",
        coords = vector3(-794.4838, -599.37, 30.10), --vector4(-794.4838, -599.3745, 30.27499, 323.3915)vector4(vector4(-794.5839, -599.562, 30.275, 322.604)or4(-794.9103, -599.7818, 30.27501, 233.4904)vector4(64.71577, -1442.902, 29.30513, 0.393085)
        interact = "Press ~INPUT_CONTEXT~ to get bundle supplies.",
        heading = 322.60,
        menu = {
            label = "Nailspa Colors",
            text = "This is where you can grab parts for your crafting."
        },
        items = {
            -- {
                -- Name = "fmdwrapper",
                -- Label = "Bundle Boxes",
                -- Price = 5,
                -- CraftTimer = 5, -- Seconds
                -- Emote = "fmdbundlesbox",
               -- Exit needed? bundlesbox2
            -- },		
            {
                Name = "fmdbbrown_hair",
                Label = "4-27 dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "ftbundlesdye1",
            },
            {
                Name = "fmdauburn_hair",
                Label = "Auburn dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "aubbundlesdye1",
            },
            {
                Name = "fmdblack_hair",
                Label = "Black dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "blabundlesdye1",
            },
            {
                Name = "fmdblonde_hair",
                Label = "Blonde dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "bbundlesdye1",
            },
            {
                Name = "fmdbrown_hair",
                Label = "Brown dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "brobundlesdye1",
            },
            {
                Name = "fmdplatinum_hair",
                Label = "Platinum dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "platbbundlesdye1",
            },
            {
                Name = "fmdccblue_hair",
                Label = "Cotton Candy Blue dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "ccbbundlesdye1",
            },
            {
                Name = "fmdccpink_hair",
                Label = "Cotton Candy Pink dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "pbundlesdye1",
            },
            {
                Name = "fmdlime_hair",
                Label = "Lime Green dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "lgbundlesdye1",
            },
            {
                Name = "fmdpurple_hair",
                Label = "Purple dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "purpbundlesdye1",
            },
            {
                Name = "fmdred_hair",
                Label = "Red dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "rbundlesdye1",
            },	
            {
                Name = "fmdmidb_hair",
                Label = "Midnight Blue dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "mbbundlesdye1",
            },	
            {
                Name = "fmdkblack_hair",
                Label = "Curly Black dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "bkbbundlesdye1",
            },	
            {
                Name = "fmdkblonde_hair",
                Label = "Curly Blonde dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "kbbundlesdye1",
            },	
            {
                Name = "fmdkblue_hair",
                Label = "Curly Blue dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "kblubundlesdye1",
            },				
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["nailsalon_parts"] = {
        job = "nailsalon",
        coords = vector3(64.71577, -1442.902, 29.04), --vector4(64.71577, -1442.902, 29.30513, 0.393085)
        interact = "Press ~INPUT_CONTEXT~ to bundle hair.",
        heading = 0.39,
        menu = {
            label = "Nailsalon Colors",
            text = "This is where you can grab parts for your crafting."
        },
        items = {
            -- {
                -- Name = "fmdwrapper",
                -- Label = "Bundle Boxes",
                -- Price = 5,
                -- CraftTimer = 5, -- Seconds
                -- Emote = "fmdbundlesbox",
                --Exit needed? bundlesbox2
            -- },		
            {
                Name = "fmdbbrown_hair",
                Label = "4-27 dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "ftbundlesdye1",
            },
            {
                Name = "fmdauburn_hair",
                Label = "Auburn dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "aubbundlesdye1",
            },
            {
                Name = "fmdblack_hair",
                Label = "Black dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "blabundlesdye1",
            },
            {
                Name = "fmdblonde_hair",
                Label = "Blonde dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "bbundlesdye1",
            },
            {
                Name = "fmdbrown_hair",
                Label = "Brown dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "brobundlesdye1",
            },
            {
                Name = "fmdplatinum_hair",
                Label = "Platinum dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "platbbundlesdye1",
            },
            {
                Name = "fmdccblue_hair",
                Label = "Cotton Candy Blue dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "ccbbundlesdye1",
            },
            {
                Name = "fmdccpink_hair",
                Label = "Cotton Candy Pink dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "pbundlesdye1",
            },
            {
                Name = "fmdlime_hair",
                Label = "Lime Green dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "lgbundlesdye1",
            },
            {
                Name = "fmdpurple_hair",
                Label = "Purple dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "purpbundlesdye1",
            },
            {
                Name = "fmdred_hair",
                Label = "Red dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "rbundlesdye1",
            },	
            {
                Name = "fmdmidb_hair",
                Label = "Midnight Blue dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "mbbundlesdye1",
            },	
            {
                Name = "fmdkblack_hair",
                Label = "Curly Black dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "bkbbundlesdye1",
            },	
            {
                Name = "fmdkblonde_hair",
                Label = "Curly Blonde dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "kbbundlesdye1",
            },	
            {
                Name = "fmdkblue_hair",
                Label = "Curly Blue dye",
                Price = 5,
                CraftTimer = 5, -- Seconds
                Emote = "kblubundlesdye1",
            },				
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    }
}

CraftingTables = {
    ["smokeys_bundles"] = {
        craftOnce = true,
        job = "smokeys",
        coords = vector3(1123.178, -983.91, 46.36),--vector4(1123.178, -983.91, 46.36982, 282.1569)
        interact = "Press ~INPUT_CONTEXT~ to craft.",
        heading = 282.15, --vector4(-808.2349, -604.7625, 30.27503, 142.1577)
        menu = {
            label = "Bag Weed",
            text = "Bag Weed here."
        },
        items = {
            {
                Name = "smokeys_aliencookies",
                Label = "Aliencookies",
                Price = 5,
                RequiredIngredients = { "smokebuds", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.				
                Emote = "mechanic2",
            },
            {
                Name = "smokeys_applepie",
                Label = "Applepie",
                Price = 5,
                RequiredIngredients = { "smokebuds", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },		
            {
                Name = "smokeys_bluedream",
                Label = "Blue Dream",
                Price = 5,
                RequiredIngredients = { "smokebuds", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "smokeys_cheesecake",
                Label = "CheeseCake",
                Price = 5,
                RequiredIngredients = { "smokebuds", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "smokeys_gumball",
                Label = "GumBall",
                Price = 5,
                RequiredIngredients = { "smokebuds", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "smokeys_orangekrush",
                Label = "Orange Krush",
                Price = 5,
                RequiredIngredients = { "smokebuds", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "smokeys_pineappleexpress",
                Label = "Pineappleexpress",
                Price = 5,
                RequiredIngredients = { "smokebuds", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.				
                Emote = "mechanic2",
            },		
            {
                Name = "smokeys_purplepunch",
                Label = "Purple Punch",
                Price = 5,
                RequiredIngredients = { "smokebuds", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },				
            {
                Name = "smokeys_whitechocolate",
                Label = "White Chocolate",
                Price = 5,
                RequiredIngredients = { "smokebuds", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "smokeys_zkittles",
                Label = "Zkittles",
                Price = 5,
                RequiredIngredients = { "smokebuds", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },				
            {
                Name = "n2o_strawberry",
                Label = "SolarGas (Strawberry)",
                Price = 50,
                RequiredIngredients = { "n2o_empty", "ammonium_nitrate" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "n2o_watermelon",
                Label = "SolarGas (Watermelon)",
                Price = 50,
                RequiredIngredients = { "n2o_empty", "ammonium_nitrate" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "n2o_mango",
                Label = "SolarGas (Mango)",
                Price = 50,
                RequiredIngredients = { "n2o_empty", "ammonium_nitrate" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "n2o_grape",
                Label = "SolarGas (Grape)",
                Price = 50,
                RequiredIngredients = { "n2o_empty", "ammonium_nitrate" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },				
            {
                Name = "n2o_raspberry",
                Label = "SolarGas (Raspberry)",
                Price = 50,
                RequiredIngredients = { "n2o_empty", "ammonium_nitrate" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },					
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["zaza_bundles"] = {
        craftOnce = true,
        job = "zaza",
        coords = vector3(165.103, -233.791, 50.05),--vector4(165.103, -233.791, 50.05526, 68.58879)
        interact = "Press ~INPUT_CONTEXT~ to bag weed.",
        heading = 68.58, --vector4(-808.2349, -604.7625, 30.27503, 142.1577)
        menu = {
            label = "Bag Weed",
            text = "Bag Weed here."
        },
        items = {
            {
                Name = "zaza_cherryld",
                Label = "Cherry Lemonade",
                Price = 5,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.				
                Emote = "mechanic2",
            },
            {
                Name = "zaza_cookiemstr",
                Label = "Cookie Monster",
                Price = 5,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },		
            {
                Name = "zaza_italice",
                Label = "Italian Ice",
                Price = 5,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "zaza_gelato",
                Label = "Gelato",
                Price = 5,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "zaza_greencrack",
                Label = "Green Crack",
                Price = 5,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "zaza_italice",
                Label = "Italian Ice",
                Price = 5,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "zaza_sherbet",
                Label = "Sherbet",
                Price = 5,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.				
                Emote = "mechanic2",
            },		
            {
                Name = "zaza_zlushie",
                Label = "Zlushie",
                Price = 5,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },				
            {
                Name = "zaza_sprinklez",
                Label = "Sprinklez",
                Price = 5,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "zaza_lunatuna",
                Label = "LunaTuna",
                Price = 5,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },				
            {
                Name = "weed_brownie",
                Label = "Weed Brownie",
                Price = 50,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "weed_cookie1",
                Label = "Weed Cookie 1",
                Price = 50,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },	
            {
                Name = "weed_cookie2",
                Label = "Weed cookie 2",
                Price = 50,
                RequiredIngredients = { "zaza", "drugbags" },
                CraftTimer = 5, -- Seconds
                Amount = 1, -- Amount to craft per cycle.								
                Emote = "mechanic2",
            },				
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["nailspa_boxbundles"] = {
        craftOnce = true,
        job = "nailspa",
        coords = vector3(-808.3375, -605.0131, 30.10),--vector4(-808.3375, -605.0131, 30.27502, 146.5735)
        interact = "Press ~INPUT_CONTEXT~ to box hair bundles.",
        heading = 142.15, --vector4(-808.2349, -604.7625, 30.27503, 142.1577)
        menu = {
            label = "Box Hair bundles",
            text = "Box hair bundles here."
        },
        items = {
            {
                Name = "fmdbbrown_bundlesbox",
                Label = "4-27 boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdbbrown_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.				
                Emote = "ftbundlesboxes",
            },
            {
                Name = "fmdauburn_bundlesbox",
                Label = "Auburn boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdauburn_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "aubundlesboxes",
            },
            {
                Name = "fmdblack_bundlesbox",
                Label = "Black boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdblack_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "blabundlesboxes",
            },	
            {
                Name = "fmdblonde_bundlesbox",
                Label = "Blonde boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdblonde_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "bbundlesboxes",
            },
            {
                Name = "fmdbrown_bundlesbox",
                Label = "Brown boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdbrown_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "brbundlesboxes",
            },
            {
                Name = "fmdplatinum_bundlesbox",
                Label = "Platinum boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdplatinum_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "plbundlesboxes",
            },
            {
                Name = "fmdccblue_bundlesbox",
                Label = "CC Blue boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdccblue_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "kblubundlesboxes",
            },
            {
                Name = "fmdccpink_bundlesbox",
                Label = "CC Pink boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdccpink_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "pbundlesboxes",
            },
            {
                Name = "fmdlime_bundlesbox",
                Label = "Lime Green boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdlime_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "lgbundlesboxes",
            },
            {
                Name = "fmdpurple_bundlesbox",
                Label = "Purple boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdpurple_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "pubundlesboxes",
            },
            {
                Name = "fmdred_bodywavebox",
                Label = "Red boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdred_bodywave" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "rbundlesboxes",
            },
            {
                Name = "fmdmidb_bundlesbox",
                Label = "Midnight Blue boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdmidb_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "nbbundlesboxes",
            },
            {
                Name = "fmdkblack_bundlesbox",
                Label = "Curly Black boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdkblack_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "kblabundlesboxes",
            },
            {
                Name = "fmdkblonde_bundlesbox",
                Label = "Curly Blonde boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdkblonde_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "kblobundlesboxes",
            },
            {
                Name = "fmdkblue_bundlesbox",
                Label = "Curly Blue boxes bundles",
                Price = 5,
                RequiredIngredients = {"fmdkblue_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "kblubundlesboxes",
            },			
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["nailsalon_boxbundles"] = {
        craftOnce = true,
        job = "nailsalon",
        coords = vector3(67.21, -1441.79, 29.04),
        interact = "Press ~INPUT_CONTEXT~ to box hair bundles.",
        heading = 44.38, --vector4(67.03934, -1441.632, 29.30503, 44.38222)
        menu = {
            label = "Box Hair bundles",
            text = "Box hair bundles here."
        },
        items = {
            {
                Name = "fmdbbrown_bundlesbox",
                Label = "4-27 boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdbbrown_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "ftbundlesboxes",
            },
            {
                Name = "fmdauburn_bundlesbox",
                Label = "Auburn boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdauburn_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "aubundlesboxes",
            },
            {
                Name = "fmdblack_bundlesbox",
                Label = "Black boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdblack_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "blabundlesboxes",
            },	
            {
                Name = "fmdblonde_bundlesbox",
                Label = "Blonde boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdblonde_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "bbundlesboxes",
            },
            {
                Name = "fmdbrown_bundlesbox",
                Label = "Brown boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdbrown_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "brbundlesboxes",
            },
            {
                Name = "fmdplatinum_bundlesbox",
                Label = "Platinum boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdplatinum_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "plbundlesboxes",
            },
            {
                Name = "fmdccblue_bundlesbox",
                Label = "CC Blue boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdccblue_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "kblubundlesboxes",
            },
            {
                Name = "fmdccpink_bundlesbox",
                Label = "CC Pink boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdccpink_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "pbundlesboxes",
            },
            {
                Name = "fmdlime_bundlesbox",
                Label = "Lime Green boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdlime_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "lgbundlesboxes",
            },
            {
                Name = "fmdpurple_bundlesbox",
                Label = "Purple boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdpurple_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "pubundlesboxes",
            },
            {
                Name = "fmdred_bodywavebox",
                Label = "Red boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdred_bodywave" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "rbundlesboxes",
            },
            {
                Name = "fmdmidb_bundlesbox",
                Label = "Midnight Blue boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdmidb_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "nbbundlesboxes",
            },
            {
                Name = "fmdkblack_bundlesbox",
                Label = "Curly Black boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdkblack_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "kblabundlesboxes",
            },
            {
                Name = "fmdkblonde_bundlesbox",
                Label = "Curly Blonde boxed bundles",
                Price = 5,
                RequiredIngredients = {"fmdkblonde_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "kblobundlesboxes",
            },
            {
                Name = "fmdkblue_bundlesbox",
                Label = "Curly Blue boxes bundles",
                Price = 5,
                RequiredIngredients = {"fmdkblue_bundles" },
                CraftTimer = 5, -- Seconds
                Amount = 5, -- Amount to craft per cycle.								
                Emote = "kblubundlesboxes",
            },			
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
   ["nailspa_crafting"] = {
        craftOnce = true,
        job = "nailspa",
        coords = vector3(-798.2691, -605.9394, 30.10), --vector4(-798.2691, -605.9394, 30.27501, 331.7449)vector4(72.36143, -1444.239, 29.3009, 47.06124)
        interact = "Press ~INPUT_CONTEXT~ to bundle hair.",
        heading = 331.74,
        menu = {
            label = "Nail&Spa Dye station",
            text = "Dye hair bundles here."
        },
        items = {
            {
                Name = "fmdbbrown_bundles",
                Label = "4-27 bundles",
                Price = 5,
                RequiredIngredients = { "fmdbbrown_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeft",
                Props = {
                    { 
                        model = `fmd_bundles427`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdauburn_bundles",
                Label = "Auburn bundles",
                Price = 5,
                RequiredIngredients = {  "fmdauburn_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeau",
                Props = {
                    { 
                        model = `fmd_bundlesauburn`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdblack_bundles",
                Label = "Black bundles",
                Price = 5,
                RequiredIngredients = {  "fmdblack_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeb",
                Props = {
                    { 
                        model = `fmd_bundlesblack`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },	
            {
                Name = "fmdblonde_bundles",
                Label = "Blonde bundles",
                Price = 5,
                RequiredIngredients = { "fmdblonde_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeblo",
                Props = {
                    { 
                        model = `fmd_bundlesblonde`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdbrown_bundles",
                Label = "Brown bundles",
                Price = 5,
                RequiredIngredients = { "fmdbrown_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyebr",
                Props = {
                    { 
                        model = `fmd_bundlesbrown`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdplatinum_bundles",
                Label = "Platinum bundles",
                Price = 5,
                RequiredIngredients = { "fmdplatinum_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyepl",
                Props = {
                    { 
                        model = `fmd_bundlesplatinum`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdccblue_bundles",
                Label = "Cotton Candy Blue bundles",
                Price = 5,
                RequiredIngredients = {  "fmdccblue_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccb",
                Props = {
                    { 
                        model = `fmd_bundlesccblue`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdccpink_bundles",
                Label = "Cotton Candy Pink bundles",
                Price = 5,
                RequiredIngredients = { "fmdccpink_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccp",
                Props = {
                    { 
                        model = `fmd_bundlesccpink`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdlime_bundles",
                Label = "Lime Green bundles",
                Price = 5,
                RequiredIngredients = { "fmdlime_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyelg",
                Props = {
                    { 
                        model = `fmd_bundleslime`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdpurple_bundles",
                Label = "Purple bundles",
                Price = 5,
                RequiredIngredients = { "fmdpurple_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyep",
                Props = {
                    { 
                        model = `fmd_bundlespurp`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdred_bodywave",
                Label = "Red bundles",
                Price = 5,
                RequiredIngredients = { "fmdred_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyer",
                Props = {
                    { 
                        model = `fmd_bundlesred`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdmidb_bundles",
                Label = "Midnight Blue bundles",
                Price = 5,
                RequiredIngredients = { "fmdmidb_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyenb",
                Props = {
                    { 
                        model = `fmd_bundlesniteblue`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdkblack_bundles",
                Label = "Curly Black bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblack_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeb",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblack`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdkblonde_bundles",
                Label = "Curly Blonde bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblonde_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeblo",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblonde`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },
            {
                Name = "fmdkblue_bundles",
                Label = "Curly Blue bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblue_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccb",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblue`, 
                        coords = vector3(-797.949158, -605.332825, 30.22), 
                        rotation = vector3(0.040000, 4.999998, -103.29)
                    },
                }
            },			
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["nailsalon_crafting"] = {
        craftOnce = true,
        job = "nailsalon",
        coords = vector3(72.36143, -1444.239, 29.04), --vector4(72.36143, -1444.239, 29.3009, 47.06124)
        interact = "Press ~INPUT_CONTEXT~ to bundle hair.",
        heading = 46.0,
        menu = {
            label = "Nailsalon Dye station",
            text = "Dye hair bundles here."
        },
        items = {
            {
                Name = "fmdbbrown_bundles",
                Label = "4-27 bundles",
                Price = 5,
                RequiredIngredients = { "fmdbbrown_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeft",
                Props = {
                    { 
                        model = `fmd_bundles427`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdauburn_bundles",
                Label = "Auburn bundles",
                Price = 5,
                RequiredIngredients = {  "fmdauburn_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeau",
                Props = {
                    { 
                        model = `fmd_bundlesauburn`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdblack_bundles",
                Label = "Black bundles",
                Price = 5,
                RequiredIngredients = {  "fmdblack_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeb",
                Props = {
                    { 
                        model = `fmd_bundlesblack`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },	
            {
                Name = "fmdblonde_bundles",
                Label = "Blonde bundles",
                Price = 5,
                RequiredIngredients = { "fmdblonde_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeblo",
                Props = {
                    { 
                        model = `fmd_bundlesblonde`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdbrown_bundles",
                Label = "Brown bundles",
                Price = 5,
                RequiredIngredients = { "fmdbrown_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyebr",
                Props = {
                    { 
                        model = `fmd_bundlesbrown`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdplatinum_bundles",
                Label = "Platinum bundles",
                Price = 5,
                RequiredIngredients = { "fmdplatinum_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyepl",
                Props = {
                    { 
                        model = `fmd_bundlesplatinum`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdccblue_bundles",
                Label = "Cotton Candy Blue bundles",
                Price = 5,
                RequiredIngredients = {  "fmdccblue_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccb",
                Props = {
                    { 
                        model = `fmd_bundlesccblue`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdccpink_bundles",
                Label = "Cotton Candy Pink bundles",
                Price = 5,
                RequiredIngredients = { "fmdccpink_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccp",
                Props = {
                    { 
                        model = `fmd_bundlesccpink`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdlime_bundles",
                Label = "Lime Green bundles",
                Price = 5,
                RequiredIngredients = { "fmdlime_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyelg",
                Props = {
                    { 
                        model = `fmd_bundleslime`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdpurple_bundles",
                Label = "Purple bundles",
                Price = 5,
                RequiredIngredients = { "fmdpurple_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyep",
                Props = {
                    { 
                        model = `fmd_bundlespurp`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdred_bodywave",
                Label = "Red bundles",
                Price = 5,
                RequiredIngredients = { "fmdred_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyer",
                Props = {
                    { 
                        model = `fmd_bundlesred`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdmidb_bundles",
                Label = "Midnight Blue bundles",
                Price = 5,
                RequiredIngredients = { "fmdmidb_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyenb",
                Props = {
                    { 
                        model = `fmd_bundlesniteblue`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdkblack_bundles",
                Label = "Curly Black bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblack_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeb",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblack`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdkblonde_bundles",
                Label = "Curly Blonde bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblonde_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeblo",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblonde`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdkblue_bundles",
                Label = "Curly Blue bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblue_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccb",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblue`, 
                        coords = vector3(71.939575195312, -1443.7939453125, 29.25), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },			
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["nailsalon_crafting2"] = {
        craftOnce = true,
        job = "nailsalon",
        coords = vector3(73.86703, -1445.576, 29.04), --vector4(73.86703, -1445.576, 29.29858, 45.00683)vector4(72.36143, -1444.239, 29.3009, 47.06124)
        interact = "Press ~INPUT_CONTEXT~ to bundle hair.",
        heading = 46.0,
        menu = {
            label = "Nailsalon Dye station",
            text = "Dye hair bundles here."
        },
        items = {
            {
                Name = "fmdbbrown_bundles",
                Label = "4-27 bundles",
                Price = 5,
                RequiredIngredients = { "fmdbbrown_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeft",
                Props = {
                    { 
                        model = `fmd_bundles427`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdauburn_bundles",
                Label = "Auburn bundles",
                Price = 5,
                RequiredIngredients = {  "fmdauburn_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeau",
                Props = {
                    { 
                        model = `fmd_bundlesauburn`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdblack_bundles",
                Label = "Black bundles",
                Price = 5,
                RequiredIngredients = {  "fmdblack_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeb",
                Props = {
                    { 
                        model = `fmd_bundlesblack`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },	
            {
                Name = "fmdblonde_bundles",
                Label = "Blonde bundles",
                Price = 5,
                RequiredIngredients = { "fmdblonde_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeblo",
                Props = {
                    { 
                        model = `fmd_bundlesblonde`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdbrown_bundles",
                Label = "Brown bundles",
                Price = 5,
                RequiredIngredients = { "fmdbrown_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyebr",
                Props = {
                    { 
                        model = `fmd_bundlesbrown`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdplatinum_bundles",
                Label = "Platinum bundles",
                Price = 5,
                RequiredIngredients = { "fmdplatinum_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyepl",
                Props = {
                    { 
                        model = `fmd_bundlesplatinum`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdccblue_bundles",
                Label = "Cotton Candy Blue bundles",
                Price = 5,
                RequiredIngredients = {  "fmdccblue_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccb",
                Props = {
                    { 
                        model = `fmd_bundlesccblue`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdccpink_bundles",
                Label = "Cotton Candy Pink bundles",
                Price = 5,
                RequiredIngredients = { "fmdccpink_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccp",
                Props = {
                    { 
                        model = `fmd_bundlesccpink`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdlime_bundles",
                Label = "Lime Green bundles",
                Price = 5,
                RequiredIngredients = { "fmdlime_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyelg",
                Props = {
                    { 
                        model = `fmd_bundleslime`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdpurple_bundles",
                Label = "Purple bundles",
                Price = 5,
                RequiredIngredients = { "fmdpurple_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyep",
                Props = {
                    { 
                        model = `fmd_bundlespurp`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdred_bodywave",
                Label = "Red bundles",
                Price = 5,
                RequiredIngredients = { "fmdred_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyer",
                Props = {
                    { 
                        model = `fmd_bundlesred`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdmidb_bundles",
                Label = "Midnight Blue bundles",
                Price = 5,
                RequiredIngredients = { "fmdmidb_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyenb",
                Props = {
                    { 
                        model = `fmd_bundlesniteblue`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdkblack_bundles",
                Label = "Curly Black bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblack_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeb",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblack`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdkblonde_bundles",
                Label = "Curly Blonde bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblonde_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeblo",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblonde`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdkblue_bundles",
                Label = "Curly Blue bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblue_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccb",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblue`, 
                        coords = vector3(73.467102, -1445.075562, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },			
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["nailsalon_crafting3"] = {
        craftOnce = true,
        job = "nailsalon",
        coords = vector3(75.41954, -1446.818, 29.04), --vector4(75.41954, -1446.818, 29.29676, 52.05175)
        interact = "Press ~INPUT_CONTEXT~ to bundle hair.",
        heading = 46.0,
        menu = {
            label = "Nailsalon Dye station",
            text = "Dye hair bundles here."
        },
        items = {
            {
                Name = "fmdbbrown_bundles",
                Label = "4-27 bundles",
                Price = 5,
                RequiredIngredients = { "fmdbbrown_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeft",
                Props = {
                    { 
                        model = `fmd_bundles427`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdauburn_bundles",
                Label = "Auburn bundles",
                Price = 5,
                RequiredIngredients = {  "fmdauburn_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeau",
                Props = {
                    { 
                        model = `fmd_bundlesauburn`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdblack_bundles",
                Label = "Black bundles",
                Price = 5,
                RequiredIngredients = {  "fmdblack_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeb",
                Props = {
                    { 
                        model = `fmd_bundlesblack`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },	
            {
                Name = "fmdblonde_bundles",
                Label = "Blonde bundles",
                Price = 5,
                RequiredIngredients = { "fmdblonde_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeblo",
                Props = {
                    { 
                        model = `fmd_bundlesblonde`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdbrown_bundles",
                Label = "Brown bundles",
                Price = 5,
                RequiredIngredients = { "fmdbrown_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyebr",
                Props = {
                    { 
                        model = `fmd_bundlesbrown`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdplatinum_bundles",
                Label = "Platinum bundles",
                Price = 5,
                RequiredIngredients = { "fmdplatinum_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyepl",
                Props = {
                    { 
                        model = `fmd_bundlesplatinum`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdccblue_bundles",
                Label = "Cotton Candy Blue bundles",
                Price = 5,
                RequiredIngredients = {  "fmdccblue_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccb",
                Props = {
                    { 
                        model = `fmd_bundlesccblue`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdccpink_bundles",
                Label = "Cotton Candy Pink bundles",
                Price = 5,
                RequiredIngredients = { "fmdccpink_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccp",
                Props = {
                    { 
                        model = `fmd_bundlesccpink`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdlime_bundles",
                Label = "Lime Green bundles",
                Price = 5,
                RequiredIngredients = { "fmdlime_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyelg",
                Props = {
                    { 
                        model = `fmd_bundleslime`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdpurple_bundles",
                Label = "Purple bundles",
                Price = 5,
                RequiredIngredients = { "fmdpurple_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyep",
                Props = {
                    { 
                        model = `fmd_bundlespurp`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdred_bodywave",
                Label = "Red bundles",
                Price = 5,
                RequiredIngredients = { "fmdred_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyer",
                Props = {
                    { 
                        model = `fmd_bundlesred`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdmidb_bundles",
                Label = "Midnight Blue bundles",
                Price = 5,
                RequiredIngredients = { "fmdmidb_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyenb",
                Props = {
                    { 
                        model = `fmd_bundlesniteblue`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdkblack_bundles",
                Label = "Curly Black bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblack_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeb",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblack`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdkblonde_bundles",
                Label = "Curly Blonde bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblonde_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeblo",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblonde`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },
            {
                Name = "fmdkblue_bundles",
                Label = "Curly Blue bundles",
                Price = 5,
                RequiredIngredients = { "fmdkblue_hair" },
                CraftTimer = 5, -- Seconds
                Emote = "bundlessinkdyeccb",
                Props = {
                    { 
                        model = `fmd_bundleskinkyblue`, 
                        coords = vector3(74.943687, -1446.402832, 29.29), 
                        rotation = vector3(4.4101519584656, -2.6100790500641, -44.429)
                    },
                }
            },			
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["mechanic_crafting"] = {
        job = "mechanic",
        coords = vector3(138.88, -3050.3, 7.04),
        menu = {
            label = "Mechanic Crafting",
            text = "This is where you can craft things for your work."
        },
        items = {
            {
                Name = "repairkit",
                Label = "Repair Kit",
                Price = 250,
                RequiredIngredients = { "metal_scrap", "jumper_cables", "wrench" },
                CraftTimer = 15, -- Seconds
            },
            {
                Name = "lockpick",
                Label = "Lockpick",
                Price = 10000,
                RequiredIngredients = { "metal_scrap", "wrench" },
                CraftTimer = 15, -- Seconds
            },		
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["hayes_crafting"] = {
        job = "hayes",
        coords = vector3(-1408.644, -447.5236, 35.90), 
        menu = {
            label = "Mechanic Crafting",
            text = "This is where you can craft things for your work."
        },
        items = {
            {
                Name = "repairkit",
                Label = "Repair Kit",
                Price = 250,
                RequiredIngredients = { "metal_scrap", "jumper_cables", "wrench" },
                CraftTimer = 15, -- Seconds
            },
            {
                Name = "lockpick",
                Label = "Lockpick",
                Price = 10000,
                RequiredIngredients = { "metal_scrap", "wrench" },
                CraftTimer = 15, -- Seconds
            },		
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["sunrise_crafting"] = {
        job = "sunrise",
        coords = vector3(-347.39, -113.66, 39.06),
        menu = {
            label = "Mechanic Crafting",
            text = "This is where you can craft things for your work."
        },
        items = {
            {
                Name = "repairkit",
                Label = "Repair Kit",
                Price = 250,
                RequiredIngredients = { "metal_scrap", "jumper_cables", "wrench" },
                CraftTimer = 15,
            },
            {
                Name = "lockpick",
                Label = "Lockpick",
                Price = 10000,
                RequiredIngredients = { "metal_scrap", "wrench" },
                CraftTimer = 15, -- Seconds
            },			
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["bennys_crafting"] = {
        job = "bennys",
        coords = vector3(-206.20, -1337.01, 31.30),
        menu = {
            label = "Mechanic Crafting",
            text = "This is where you can craft things for your work."
        },
        items = {
            {
                Name = "repairkit",
                Label = "Repair Kit",
                Price = 250,
                RequiredIngredients = { "metal_scrap", "jumper_cables", "wrench" },
                CraftTimer = 15, -- Seconds
            },
			{
                Name = "lockpick",
                Label = "Lockpick",
                Price = 10000,
                RequiredIngredients = { "metal_scrap", "wrench" },
                CraftTimer = 15, -- Seconds
            },			
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["pitstop_crafting"] = {
        job = "pitstop",
        coords = vector3(941.076, -1551.39, 30.73),
        menu = {
            label = "Mechanic Crafting",
            text = "This is where you can craft things for your work."
        },
        items = {
            {
                Name = "repairkit",
                Label = "Repair Kit",
                Price = 250,
                RequiredIngredients = { "metal_scrap", "jumper_cables", "wrench" },
                CraftTimer = 15, -- Seconds
            },
            {
                Name = "lockpick",
                Label = "Lockpick",
                Price = 10000,
                RequiredIngredients = { "metal_scrap", "wrench" },
                CraftTimer = 15, -- Seconds
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },
    ["autoexotic_crafting"] = {
        job = "autoexotic",
        coords = vector3(559.2499, -172.2864, 54.50), --vector4(559.2499, -172.2864, 54.50858, 346.8736)
        menu = {
            label = "Mechanic Crafting",
            text = "This is where you can craft things for your work."
        },
        items = {
            {
                Name = "repairkit",
                Label = "Repair Kit",
                Price = 250,
                RequiredIngredients = { "metal_scrap", "jumper_cables", "wrench" },
                CraftTimer = 15, -- Seconds
            },
            {
                Name = "lockpick",
                Label = "Lockpick",
                Price = 10000,
                RequiredIngredients = { "metal_scrap", "wrench" },
                CraftTimer = 15, -- Seconds
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["mosleys_crafting"] = {
        job = "mosleys",
        coords = vector3(-8.84, -1677.79, 29.46), --{ x = -8.84193897247314, y = -1677.798583984375, z = 29.46983909606933, h = 192.0054473876953 }
        menu = {
            label = "Mechanic Crafting",
            text = "This is where you can craft things for your work."
        },
        items = {
            {
                Name = "repairkit",
                Label = "Repair Kit",
                Price = 250,
                RequiredIngredients = { "metal_scrap", "jumper_cables", "wrench" },
                CraftTimer = 15, -- Seconds
            },
            {
                Name = "lockpick",
                Label = "Lockpick",
                Price = 10000,
                RequiredIngredients = { "metal_scrap", "wrench" },
                CraftTimer = 15, -- Seconds
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    },	
    ["prison_crafting"] = {
        job = nil,                                -- if job == nil, all can use.
        coords = vector3(1740.46, 2532.98, 43.3), -- CHANGE THIS NORTHINGTON
        menu = {
            label = "Prison Crafting",
            text = "This is where you can craft things for you to survive prison."
        },
        items = {
            {
                Name = "weapon_shank",
                Label = "Prison Shank",
                Type = "weapon",
                Price = 5000,
                RequiredIngredients = { "toothbrush", "lighter", "shaving_kit" },
                CraftTimer = 5, -- Seconds
            },
        },
        -- Dont mess with the below.
        crafting = false,
        type = nil,
        fire = nil,
        timer = 0
    }
}

BillingRegisters = {
    ["register_smokeys"] = {
        job = "smokeys",
        society = nil,		
        coords = vector3(1132.619, -991.1298, 46.11), --vector4(1132.619, -991.1298, 46.11322, 274.2092)
        receiptFormat = {
            label = "Smokey's Bill",
            txt = "Smokey's wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Smokey's will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Smokey's will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Smokey's will not be paid this bill.",
                },
            }
        }
    },
    ["register_zaza"] = {
        job = "zaza",
        society = "zaza",		
        coords = vector3(188.4327, -240.934, 54.07), --vector4(188.4327, -240.934, 54.07048, 242.2594)
        receiptFormat = {
            label = "Zaza Bill",
            txt = "Zaza wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Zaza will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Zaza will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Zaza will not be paid this bill.",
                },
            }
        }
    },
    ["register_bigzos"] = {
        job = "bigzos",
        society = nil,
        taxpercent = 20,
        taxsociety = "bigzos",			
        coords = vector3(448.6199, -2053.708, 23.95), 
        receiptFormat = {
            label = "Big Zo's Bill",
            txt = "Big Zo's wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Big Zo's will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Big Zo's will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Big Zo's will not be paid this bill.",
                },
            }
        }
    },
    ["register_nailsalon"] = {
        job = "nailsalon",
        society = "nailsalon",
        coords = vector3(73.02, -1456.65, 29.3),
        receiptFormat = {
            label = "Nailsalon Bill",
            txt = "The nailsalon wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "The nailsalon will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "The nailsalon will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "The nailsalon will not be paid this bill.",
                },
            }
        }
    },
    ["register_nailspa"] = {
        job = "nailspa",
        society = "nailspa",
        coords = vector3(-801.544, -600.552, 30.27), --vector4(-801.544, -600.552, 30.27502, 53.65438)
        receiptFormat = {
            label = "Nail&Spa Bill",
            txt = "Nail&Spa wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Nail&Spa will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Nail&Spa will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Nail&Spa will not be paid this bill.",
                },
            }
        }
    },	
    ["register_lawyer"] = {
        job = "lawyer",
        society = nil,
        coords = vector3(11.1, 11.1, -29.3),
        receiptFormat = {
            label = "Lawyer Bill",
            txt = "Lawyer wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Lawyer will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Lawyer will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Lawyer will not be paid this bill.",
                },
            }
        }
    },	
    ["register_towing"] = {
        job = "towing",
        society = nil,
        coords = vector3(-191.99, -1162.34, 23.67),
        receiptFormat = {
            label = "Towing Bill",
            txt = "Towing wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Towing will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Towing will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Towing will not be paid this bill.",
                },
            }
        }
    },
    ["register_autoexotic"] = {
        job = "autoexotic",
        society = "autoexotic",
        coords = vector3(542.9921, -199.2912, 54.50), 
        receiptFormat = {
            label = "AutoExotic Bill",
            txt = "AutoExotic wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "AutoExotic will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "AutoExotic will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "AutoExotic will not be paid this bill.",
                },
            }
        }
    },
    ["register_hayes"] = {
        job = "hayes",
        society = "hayes",
        coords = vector3(-1429.706, -454.9306, 35.90),  --vector4(-1429.706, -454.9306, 35.90973, 36.11343)
        receiptFormat = {
            label = "Hayes Bill",
            txt = "Hayes wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Hayes will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Hayes will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Hayes will not be paid this bill.",
                },
            }
        }
    },	
    ["register_burgershot"] = {
        job = "burgershot",
        society = "burgershot",
        coords = vector3(-1193.584, -894.3324, 13.88), 
        receiptFormat = {
            label = "Burgershot Bill",
            txt = "Burgershot wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Burgershot will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Burgershot will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Burgershot will not be paid this bill.",
                },
            }
        }
    },
    ["register_unicorn"] = {
        job = "unicorn",
        society = "unicorn",
        coords = vector3(96.2, -1298.72, -35.5),
        receiptFormat = {
            label = "VU Bill",
            txt = "VU wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "VU will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "VU will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "VU will not be paid this bill.",
                },
            }
        }
    },	
    ["register_dunkindonuts"] = {
        job = "dunkindonuts",
        society = "dunkindonuts",
        coords = vector3(-582.74, -883.53, 25.9),
        receiptFormat = {
            label = "DunkinDonuts Bill",
            txt = "DunkinDonuts wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "DunkinDonuts will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "DunkinDonuts will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "DunkinDonuts will not be paid this bill.",
                },
            }
        }
    },
    ["register_chickfila"] = {
        job = "chickfila",
        society = "chickfila",
        coords = vector3(-1036.09, -1372.03, 5.5),
        receiptFormat = {
            label = "Chicfila Bill",
            txt = "Chicfila wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Mechanic will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Mechanic will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Mechanic will not be paid this bill.",
                },
            }
        }
    },
    ["register_mechanic"] = {
        job = "mechanic",
        society = "mechanic",
        coords = vector3(146.83, -3013.37, 7.04),
        receiptFormat = {
            label = "Mechanic Bill",
            txt = "Mechanic wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Mechanic will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Mechanic will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Mechanic will not be paid this bill.",
                },
            }
        }
    },
    ["register_mosleys"] = {
        job = "mosleys",
        society = "mosleys",
        coords = vector3(-22.36483, -1658.637, 29.49),
        receiptFormat = {
            label = "Mosleys Mechanic Bill",
            txt = "Mosleys Mechanic wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Mechanic will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Mechanic will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Mechanic will not be paid this bill.",
                },
            }
        }
    },	
    ["register_bahama"] = {
        job = "bahama",
        society = "bahama",
        coords = vector3(-1399.479, -600.2496, 30.31),
        receiptFormat = {
            label = "BahamaMama Bill",
            txt = "BahamaMama wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "BahamaMama will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "BahamaMama will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "BahamaMama will not be paid this bill.",
                },
            }
        }
    },		
    ["register_sunrise"] = {
        job = "sunrise",
        society = "sunrise",
        coords = vector3(-349.5, -140.37, 39.40),
        receiptFormat = {
            label = "Sunrise Customs Bill",
            txt = "Sunrise Customs wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Mechanic will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Mechanic will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Mechanic will not be paid this bill.",
                },
            }
        }
    },
    ["register_bennys"] = {
        job = "bennys",
        society = "bennys",
        coords = vector3(-213.28, -1322.15, 31.30),
        receiptFormat = {
            label = "Bennys Customs Bill",
            txt = "Bennys Customs wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Mechanic will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Mechanic will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Mechanic will not be paid this bill.",
                },
            }
        }
    },
    ["register_pitstop"] = {
        job = "pitstop",
        society = "pitstop",
        coords = vector3(944.72, -1566.26, 30.73),
        receiptFormat = {
            label = "Pitstop Garage Bill",
            txt = "Pitstop Garage wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Mechanic will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Mechanic will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Mechanic will not be paid this bill.",
                },
            }
        }
    },
    ["register_denaros"] = {
        job = "denaros",
        society = "denaros",
        coords = vector3(-1342.59, -1071.72, 7.0),
        receiptFormat = {
            label = "Mirrors Bill",
            txt = "Mirrors wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Mirrors will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Mirrors will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Mirrors will not be paid this bill.",
                },
            }
        }
    },
    ["register_bishops"] = {
        job = "bishops",
        society = "bishops",
        coords = vector3(2582.249, 478.0796, 108.65),--vector4(2582.249, 478.0796, 108.6579, 169.1404)
        receiptFormat = {
            label = "Bishops Bill",
            txt = "Bishops wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Bishops will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Bishops will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Bishops will not be paid this bill.",
                },
            }
        }
    },
    ["register_blazeit"] = {
        job = "blazeit",
        society = "blazeit",
        coords = vector3(369.57, -1270.04, 32.59),
        receiptFormat = {
            label = "Blazeit Bill",
            txt = "Blazeit wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Blazeit will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Blazeit will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Blazeit will not be paid this bill.",
                },
            }
        }
    },
    ["register_grizzleygas"] = {
        job = "grizzleygas",
        society = "grizzleygas",
        coords = vector3(-931.39, -1179.87, 5.02),
        receiptFormat = {
            label = "Grizzley Gas Bill",
            txt = "Grizzley Gas wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Grizzley Gas will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Grizzley Gas will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Grizzley Gas will not be paid this bill.",
                },
            }
        }
    },
    ["register_taco"] = {
        job = "taco",
        society = nil,
        coords = vector3(9.30, -1605.22, 29.37),
        receiptFormat = {
            label = "Taco Farmer Bill",
            txt = "Taco wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Taco Farmer will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Taco Farmer will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Taco Farmer will not be paid this bill.",
                },
            }
        }
    },
    ["register_catcafe"] = {
        job = "catcafe",
        society = "catcafe",
        coords = vector3(-584.71, -1061.55, 22.34),
        receiptFormat = {
            label = "UWU Cafe Bill",
            txt = "UWU Cafe wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "UWU Cafe will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "UWU Cafe will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "UWU Cafe will not be paid this bill.",
                },
            }
        }
    },
    ["register_pearls"] = {
        job = "pearls",
        society = "pearls",
        coords = vector3(-1834.753, -1189.77, 14.31),
        receiptFormat = {
            label = "Pearls Bill",
            txt = "Pearls wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Pearls will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Pearls will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Pearls will not be paid this bill.",
                },
            }
        }
    },
    ["register_ammunation"] = {
        job = "ammunation",	
        society = nil,
        taxpercent = 20,
        taxsociety = "north",			
        coords = vector3(16.93097, -1107.504, 29.79), 
        receiptFormat = {
            label = "Ammunation Bill",
            txt = "Ammunation wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "Ammunation will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "Ammunation will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "Ammunation will not be paid this bill.",
                },
            }
        }
    },	
    ["regular_injury"] = {
        job = "ambulance",
        society = nil,
        taxpercent = 20,
        taxsociety = "north",        
        coords = vector3(308.23, -592.85, 43.28),
        receiptFormat = {
            label = "Hospital Bill",
            txt = "The hospital wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "The hospital will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "The hospital will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "The hospital will not be paid this bill.",
                },
            }
        }
    },
    ["physical_therapy"] = {
        job = "ambulance",
        society = nil,
        taxpercent = 80,
        taxsociety = "north",        
        coords = vector3(308.23, -592.85, 43.28),
        receiptFormat = {
            label = "Hospital Bill",
            txt = "The hospital wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "The hospital will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "The hospital will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "The hospital will not be paid this bill.",
                },
            }
        }
    },	
    ["register_ambulance"] = {
        job = "ambulance",
        society = nil,
        taxpercent = 20,
        taxsociety = "north",		
        coords = vector3(308.23, -592.85, 43.28),
        receiptFormat = {
            label = "Hospital Bill",
            txt = "The hospital wants to charge you <span style='color:green'>$|charge|</span>.",
            options = {
                {
                    selected = "credit",
                    label = "Credit Card",
                    txt = "The hospital will be paid the sum of the bill with your card.",
                },
                {
                    selected = "cash",
                    label = "Cash",
                    txt = "The hospital will be paid the sum of the bill with cash.",
                },
                {
                    selected = "no",
                    label = "Reject the Bill.",
                    txt = "The hospital will not be paid this bill.",
                },
            }
        }
    },
}

BossMenus = {
    ["grizzleygas"] = {
        Coords = vector3(-939.11, -1186.39, 5.02)
    },
    ["zaza"] = {
        Coords = vector3(182.3328, -252.9774, 54.070) 
    },	
    ["nailspa"] = {
        Coords = vector3(-801.4689, -610.7847, 30.27)
    },	
    ["bigzos"] = {
        Coords = vector3(437.6662, -2062.856, 24.10) 
    },		
    ["hookahlounge"] = { 
        Coords = vector3(-441.5984, 279.7142, 83.02)
    },	
    ["unicorn"] = { 
        Coords = vector3(96.2, -1298.72, 35.5)
    },	
    ["towing"] = {
        Coords = vector3(-184.95, -1163.61, 23.67)
    },	
    ["gasstation"] = {
        Coords = vector3(-43.45, -1748.26, 29.42)
    },
}

Outfits = {
    ["ammunation"] = {
        Location = vector3(5.32, -1109.46, 29.8),
        Job = "ammunation",
        Skin = {
            male = {
                ['tshirt_1'] = 59,
                ['tshirt_2'] = 1,
                ['torso_1'] = 146,
                ['torso_2'] = 0,
                ['pants_1'] = 98,
                ['pants_2'] = 2,
                ['shoes_1'] = 12,
                ['shoes_2'] = 0,
                ['bproof_1'] = 0,
                ['arms'] = 2,
                ['arms_2'] = 0
            },
            female = {
                ['tshirt_1'] = 16,
                ['tshirt_2'] = 4,
                ['torso_1'] = 169,
                ['torso_2'] = 0,
                ['pants_1'] = 106,
                ['pants_2'] = 1,
                ['shoes_1'] = 24,
                ['shoes_2'] = 0,
                ['arms'] = 12,
                ['arms_2'] = 0
            }
        }
    },
    ["bus"] = {
        Location = vector3(436.58, -624.52, 28.71),
        Job = "bus",
        Skin = {
            male = {
                ['tshirt_1'] = 59,
                ['tshirt_2'] = 1,
                ['torso_1'] = 146,
                ['torso_2'] = 0,
                ['pants_1'] = 98,
                ['pants_2'] = 2,
                ['shoes_1'] = 12,
                ['shoes_2'] = 0,
                ['bproof_1'] = 0,
                ['arms'] = 2,
                ['arms_2'] = 0
            },
            female = {
                ['tshirt_1'] = 16,
                ['tshirt_2'] = 4,
                ['torso_1'] = 169,
                ['torso_2'] = 0,
                ['pants_1'] = 106,
                ['pants_2'] = 1,
                ['shoes_1'] = 24,
                ['shoes_2'] = 0,
                ['arms'] = 12,
                ['arms_2'] = 0
            }
        }
    },
    ["taxi"] = {
        Location = vector3(896.17, -178.18, 74.7),
        Job = "taxi",
        Skin = {
            male = {
                ['tshirt_1'] = 59,
                ['tshirt_2'] = 1,
                ['torso_1'] = 146,
                ['torso_2'] = 0,
                ['pants_1'] = 98,
                ['pants_2'] = 2,
                ['shoes_1'] = 12,
                ['shoes_2'] = 0,
                ['bproof_1'] = 0,
                ['arms'] = 2,
                ['arms_2'] = 0
            },
            female = {
                ['tshirt_1'] = 16,
                ['tshirt_2'] = 4,
                ['torso_1'] = 169,
                ['torso_2'] = 0,
                ['pants_1'] = 106,
                ['pants_2'] = 1,
                ['shoes_1'] = 24,
                ['shoes_2'] = 0,
                ['arms'] = 12,
                ['arms_2'] = 0
            }
        }
    },
}
