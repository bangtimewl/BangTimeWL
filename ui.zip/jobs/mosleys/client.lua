local JobData = Config.Jobs.Mosleys
local AllowInteraction = true
local CarryingData = {
    Active = false,
    EntityID = nil,
    Key = nil,
    Value = nil
}

local currentMessage, currentAction, currentActionData = '', nil, nil
local HasAlreadyEnteredMarker, LastZone = false
local coupeDoors, receivedItems = { 0, 1, 4, 5 }, {}
local ownedTable = {}
local isChoppingVehicle = false

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj)
            ESX = obj
        end)
        Citizen.Wait(100)
    end

    while ESX.GetPlayerData().job == nil do
        Citizen.Wait(100)
    end

    ESX.PlayerData = ESX.GetPlayerData()

    Citizen.CreateThread(function()
        StartScript();
    end)
    Citizen.CreateThread(function()
        SellLocation();
    end)
end)

RegisterNetEvent('ultimate_chopshop:updateOwnedTable')
AddEventHandler('ultimate_chopshop:updateOwnedTable', function(ownedTableSv)
    ownedTable = ownedTableSv

    if JobData.Debug then
        for k, v in pairs(ownedTable) do
            print(k, v)
        end
    end
end)

function StartScript()
    if JobData.EnableBlips then
        for k, v in pairs(JobData.Locations) do
            local blip = AddBlipForCoord(v.coords)
            SetBlipSprite(blip, 380)
            SetBlipColour(blip, 1)
            SetBlipScale(blip, 0.7)
            SetBlipDisplay(blip, 4)
            SetBlipAsShortRange(blip, true)

            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString('Chopshop')
            EndTextCommandSetBlipName(blip)
        end
    end

    while true do
        local wait = 100

        if JobData.AllowJobs.Jobs[ESX.PlayerData.job.name] then
            local playerPed = PlayerPedId()
            local coords = GetEntityCoords(playerPed)

            local isInMarker, lastSleep, isOwn, currentZone = false, true, false

            for k, v in pairs(JobData.Locations) do
                if IsPedInAnyVehicle(playerPed, false) then
                    local distance = GetDistanceBetweenCoords(coords, v.coords, true)

                    if distance <= 15.0 then
                        wait = 5
                        DrawMarker(27, v.coords, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 3.0, 3.0, 1.0, 255, 0, 0, 255, false,
                                false, 2, true, nil, nil, false)
                    end

                    if distance <= 3.0 then
                        isInMarker, currentZone = true, k
                    end
                end
            end

            if (isInMarker and not HasAlreadyEnteredMarker) or (isInMarker and LastZone ~= currentZone) then
                HasAlreadyEnteredMarker, LastZone = true, currentZone
                -- Enter
                TriggerEvent('ultimate_chopshop:hasEnteredMarker', currentZone, isOwn)
            end

            if not isInMarker and HasAlreadyEnteredMarker then
                HasAlreadyEnteredMarker = false
                -- Exit
                TriggerEvent('ultimate_chopshop:hasExitedMarker', currentZone)
            end
        else
            wait = 1000
        end

        Citizen.Wait(wait)
    end
end

RegisterNetEvent('esx:setJob')
AddEventHandler('esx:setJob', function(job)
    ESX.PlayerData.job = job
end)

AddEventHandler('ultimate_chopshop:hasEnteredMarker', function(zone, own)
    if not own then
        currentAction = zone
        currentMessage = 'Press ~INPUT_CONTEXT~ To ~r~Chop~s~ This ~b~Vehicle'
        currentActionData = true
    else
        currentAction = zone
        currentMessage = 'Press ~INPUT_CONTEXT~ To Access ~b~The Menu'
        currentActionData = false
    end
end)

AddEventHandler('ultimate_chopshop:hasExitedMarker', function(zone)
    ESX.UI.Menu.CloseAll()
    currentAction = nil
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)

        if currentAction then
            ESX.ShowHelpNotification(currentMessage)

            if IsControlJustReleased(1, 51) then
                if currentActionData then
                    StartChopping(LastZone)
                else
                    OpenOwnMenu(LastZone)
                    currentAction = nil
                end
            end
        end
    end
end)

function IsVehicleOwned(plate)
    local p = promise:new()

    ESX.TriggerServerCallback("mos:vehicleOwned", function(owned)
        p:resolve(owned)
    end, plate)

    return Citizen.Await(p)
end

function StartChopping(id)
    isChoppingVehicle = true
    local playerPed = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(playerPed, false)
    local doorCount = GetNumberOfVehicleDoors(vehicle)
    local props = ESX.Game.GetVehicleProperties(vehicle)
    if not IsVehicleOwned(props.plate) then
        ESX.ShowNotification("This vehicle is not owned by anyone!")
        isChoppingVehicle = false
        return
    end

    if not IsVehicleDriveable(vehicle) then
        ESX.ShowNotification("No junk cars allowed!")
        isChoppingVehicle = false
        return
    end

    local job = ESX.GetPlayerData().job

    if job.grade ~= 4 then
        ESX.ShowNotification("You do not have the required rank to chop vehicles!")
        isChoppingVehicle = false
        return
    end

    Citizen.CreateThread(function()
        DisableVehicleExit();
    end)
    SetVehicleEngineOn(vehicle, false, false, true)
    FreezeEntityPosition(vehicle, true)

    if doorCount > 4 then
        for i = 0, doorCount - 1 do
            local info = JobData.Parts[i]

            if not info then
                ESX.ShowNotification("Something went wrong, please contact the server owner!")
                break
            end

            SetVehicleDoorOpen(vehicle, i, false, false)
            PlaySoundFrontend(-1, "Hydraulics_Down", "Lowrider_Super_Mod_Garage_Sounds", true)
            exports['progressBars']:startUI(info.time * 1000, info.label)
            PlaySoundFrontend(-1, "TIMER_STOP", "HUD_MINI_GAME_SOUNDSET", 1)

            Citizen.Wait(info.time * 1000)
            SetVehicleDoorBroken(vehicle, i, false)

            if info.item.enabled then
                local chance = math.random(1, 100)

                if chance <= info.item.chance then
                    table.insert(receivedItems, {
                        name = info.item.name,
                        count = info.item.count
                    })
                end
            end

            Citizen.Wait(1000)
        end
    else
        for k, v in pairs(coupeDoors) do
            local info = JobData.Parts[v]

            if not info then
                ESX.ShowNotification("Something went wrong, please contact the server owner!")
                break
            end

            SetVehicleDoorOpen(vehicle, v, false, false)
            PlaySoundFrontend(-1, "Hydraulics_Down", "Lowrider_Super_Mod_Garage_Sounds", true)
            exports['progressBars']:startUI(info.time * 1000, info.label)
            Citizen.Wait(info.time * 1000)
            SetVehicleDoorBroken(vehicle, i, false)

            if info.item.enabled then
                local chance = math.random(1, 100)

                if chance <= info.item.chance then
                    table.insert(receivedItems, {
                        name = info.item.name,
                        count = info.item.count
                    })
                end
            end

            Citizen.Wait(1000)
        end
    end

    exports['progressBars']:startUI(JobData.TyreTime * 1000, 'Tires')
    Citizen.Wait(JobData.TyreTime * 1000)
    for i = 0, 5 do
        SetVehicleTyreBurst(vehicle, i, true, 1000)
        PlaySoundFrontend(-1, "Hydraulics_Down", "Lowrider_Super_Mod_Garage_Sounds", true)
        Citizen.Wait(1000)
    end

    local myItems = 0
    local myChance = math.random(1, 100)

    for k, v in pairs(JobData.AdditionalItems) do
        if myItems == JobData.AdditionalItemAmount then
            break
        end

        if myChance <= v.chance then
            table.insert(receivedItems, {
                name = v.name,
                count = v.count
            })

            myItems = myItems + 1
        end
    end

    exports['progressBars']:startUI(JobData.DeleteVehicleTime * 1000, 'Finishing Up...')
    Citizen.Wait(JobData.DeleteVehicleTime * 1000)
    print("after finishing up")
    local props = ESX.Game.GetVehicleProperties(vehicle)
    print("got the props")
    TriggerServerEvent("ultimate_chopshop:chopped", props.plate)
    print("triggered chopped", props.plate)
    PlaySoundFrontend(-1, "Exit_Engine_Blips", "Lowrider_Super_Mod_Garage_Sounds", true)
    print("after play sound")
    TriggerServerEvent('ultimate_chopshop:receiveItems', receivedItems)
    print("received items")
    TriggerServerEvent('ultimate_chopshop:receivePayment', LastZone)
    print("received payment")
    FreezeEntityPosition(vehicle, false)
    SetVehicleHasBeenOwnedByPlayer(vehicle, false)
    SetEntityAsMissionEntity(vehicle, true, false)
    ESX.Game.DeleteVehicle(vehicle)

    local tries = 0

    while DoesEntityExist(vehicle) and tries < 11 do
        Citizen.Wait(1000)
        SetVehicleHasBeenOwnedByPlayer(vehicle, false)
        SetEntityAsMissionEntity(vehicle, true, false)
        DeleteVehicle(vehicle)
    end

    if DoesEntityExist(vehicle) then
        SetVehicleHasBeenOwnedByPlayer(vehicle, false)
        SetEntityAsMissionEntity(vehicle, true, false)
        NetworkExplodeVehicle(vehicle, true, false, false)
        DeleteVehicle(vehicle)
    end

    TriggerEvent('ultimate_chopshop:hasExitedMarker', LastZone, false)
    receivedItems = {}
    isChoppingVehicle = false
end

function OpenOwnMenu(id)
    if ownedTable[id] and ownedTable[id] ~= ESX.PlayerData.identifier then
        ESX.ShowNotification('Service Is Already ~r~Owned~s~!')
    else
        local elements = {}

        if ownedTable[id] == ESX.PlayerData.identifier then
            table.insert(elements,
                    {
                        value = 'sell',
                        label = 'Sell Chopshop <b style="color:red;>">$' .. JobData.Locations[id].sellprice .. '</b>',
                        price = Config.Locations[id].sellprice
                    })
        else
            table.insert(elements,
                    {
                        value = 'buy',
                        label = 'Buy Chopshop <b style="color:lime;">$' .. JobData.Locations[id].price .. '</b>',
                        price = Config.Locations[id].price
                    })
        end

        ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'ultimate_chopshop_buymenu', {
            title = 'Buy Chopshop',
            align = 'right',
            elements = elements
        }, function(data, menu)
            if data.current.value == 'sell' then
                TriggerServerEvent('ultimate_chopshop:tryToSell', id, data.current.price)
            elseif data.current.value == 'buy' then
                TriggerServerEvent('ultimate_chopshop:tryToPurchase', id, data.current.price)
            end

            menu.close()
            currentAction = id
            currentMessage = 'Press ~INPUT_CONTEXT~ To Access ~b~The Menu'
        end, function(data, menu)
            menu.close()
            currentAction = id
            currentMessage = 'Press ~INPUT_CONTEXT~ To Access ~b~The Menu'
        end)
    end
end

local isInMenu = false
function SellLocation()
    if JobData.SellLocation.enableBlip then
        local blip = AddBlipForCoord(JobData.SellLocation.coords)
        SetBlipSprite(blip, 171)
        SetBlipColour(blip, 27)
        SetBlipScale(blip, 0.8)
        SetBlipDisplay(blip, 4)
        SetBlipAsShortRange(blip, true)

        BeginTextCommandSetBlipName("STRING")
        AddTextComponentString('Sell Vehicle Parts')
        EndTextCommandSetBlipName(blip)
    end

    while true do
        local wait = 1000

        local playerPed = PlayerPedId()
        local coords = GetEntityCoords(playerPed)
        local distance = GetDistanceBetweenCoords(coords, JobData.SellLocation.coords, true)

        if distance <= 15.0 and JobData.AllowJobs.Jobs[ESX.PlayerData.job.name] then
            wait = 5
            DrawMarker(27, JobData.SellLocation.coords, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.5, 1.5, 1.0, 150, 150, 150, 255,
                    false, false, 2, true, nil, nil, false)

            if distance <= 1.5 and not isInMenu then
                ESX.ShowHelpNotification('Press ~INPUT_CONTEXT~ To Access ~b~Sell Menu')

                if IsControlJustPressed(1, 51) then
                    OpenSellMenu()
                end
            elseif distance > 1.5 and isInMenu then
                ESX.UI.Menu.CloseAll()
                isInMenu = false
            end
        end

        Citizen.Wait(wait)
    end
end

function OpenSellMenu()
    isInMenu = true

    ESX.TriggerServerCallback('ultimate_chopshop:getPlayerInventory', function(inventory)
        ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'ultimate_chopshop_sellmenu', {
            title = 'Sell Vehicle Parts',
            align = 'right',
            elements = inventory
        }, function(data, menu)
            if data.current.count > 0 then
                -- ultimate_chopshop:sellItem
                ESX.UI.Menu.Open('dialog', GetCurrentResourceName(), 'ultimate_chopshop_sellmenu_amount', {
                    title = 'Amount'
                }, function(data2, menu2)
                    if tonumber(data2.value) and tonumber(data2.value) > 0 then
                        TriggerServerEvent('ultimate_chopshop:sellItem', data.current.value, tonumber(data2.value))
                        menu2.close()
                        menu.close()
                        OpenSellMenu()
                    end
                end, function(data2, menu2)
                    menu2.close()
                end)
            else
                ESX.ShowNotification('You Don\'t Have That Item!')
            end
        end, function(data, menu)
            menu.close()
            isInMenu = false
        end)
    end)
end

function DisableVehicleExit()
    while isChoppingVehicle do
        Citizen.Wait(5)

        DisableControlAction(0, 23, true)
        DisableControlAction(0, 49, true)
        DisableControlAction(0, 75, true)
    end
end

function MosleysGetMarkerText(storeID, markerID)
    local text = JobData.Shops[storeID].InteractMarkers[markerID].DisplayText
    if (key == "toggle_duty") then
        text = text:gsub("|clocked_status|", (ClockedIn and "out" or "in"))
    end
    return text
end

function MosleysGetWorkbench5Submenu(index, SubData)
    local CurrentVehicle = GetLastDrivenVehicle(PlayerPedId())
    SetVehicleModKit(CurrentVehicle, 0)
    local parentData = JobData.VehicleParts5[index]
    local submenu = {
        {
            id = 1,
            header = SubData.Label,
            txt = "Choose a selection below."
        },
    }
    local modCount = GetNumVehicleMods(CurrentVehicle, parentData.ModType)
    if (parentData.ModType == 17) then
        modCount = modCount + 1
    end
    for i = 0, modCount, 1 do
        submenu[#submenu + 1] = {
            id = i + 1,
            header = (i == 0 and "Default" or (parentData.Label .. " - Level " .. (i))),
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = SubData.Name,
                    data = {
                        selected = i - 1,
                    }
                }
            }
        }
    end
    submenu[#submenu + 1] = {
        id = #submenu + 1,
        header = "Back <<",
        txt = "",
        params = {
            event = "nh-context-bridge:returnData",
            args = {
                id = "returnWorkbench5",
                data = {
                    selected = "returnWorkbench5",
                }
            }
        }
    }
    return submenu
end

function MosleysGetWorkbench5Menu()
    local menu = {
        {
            id = 1,
            header = "Vehicle Parts",
            txt = "This is where you can carry a vehicle part to the vehicle!"
        },
    }
    for i = 1, #JobData.VehicleParts5 do
        local submenu
        local data = JobData.VehicleParts5
        menu[#menu + 1] = {
            id = i + 1,
            header = data[i].Label .. " >>",
            txt = "",
            params = {
                event = "nh-context-bridge:returnData",
                args = {
                    id = "workbench5",
                    data = {
                        selected = data[i].Name,
                        submenu = data[i].ModType ~= nil and MosleysGetWorkbench5Submenu(i, data[i]) or nil,
                    }
                }
            }
        }
    end
    return menu
end

function MosleysInteractMarker(storeID, markerID)
    if (ESX.GetPlayerData().job.name ~= "mosleys") then
        ESX.ShowNotification("You are not authorized to use this.")
        return
    end
    if (markerID == "workbench5") then
        TriggerEvent('nh-context-bridge:sendMenu', MosleysGetWorkbench5Menu())
    elseif (markerID == "boss") then
        OpenSocietyJobBossMenu()
    end
end

function MosleysThread()
    Citizen.CreateThread(function()
        while true do
            local wait = 1000
            local coords = GetPlayerCoords()
            for storeID, data in pairs(JobData.Shops) do
                for markerID, markerData in pairs(data.InteractMarkers) do
                    if (markerData.Display or markerData.Display == nil) then
                        local dist = #(markerData.Coords - coords)
                        if (dist < 20.0) then
                            wait = 0
                            if (Marker(markerData.Coords, dist, MosleysGetMarkerText(storeID, markerID)) and AllowInteraction) then
                                MosleysInteractMarker(storeID, markerID)
                            end
                        end
                    end
                end
            end
            Citizen.Wait(wait)
        end
    end)
end

MosleysThread()

function StopCarrying()
    CarryingData.Key = nil
    CarryingData.Value = nil
    DestroyAllProps()
    ClearPedTasksImmediately(PlayerPedId())
end

function UpgradeVehicle(vehicle)
    local CurrentMods = ESX.Game.GetVehicleProperties(vehicle)
    CurrentMods[CarryingData.Key] = CarryingData.Value
    ESX.Game.SetVehicleProperties(vehicle, CurrentMods)
    TriggerServerEvent("esx_societyjobs:mosleys:updateVehicle", CurrentMods)

    StopCarrying()
end

function SetActiveCarrying(key, index)
    OnEmotePlay(JobData.CarryingSettings[key])
    CarryingData.Key = key
    CarryingData.Value = index

    Citizen.CreateThread(function()
        while key == CarryingData.Key and index == CarryingData.Value do
            if (IsControlJustPressed(1, 51)) then
                local CurrentVehicle = GetLastDrivenVehicle(PlayerPedId())
                if #(GetEntityCoords(CurrentVehicle) - GetEntityCoords(PlayerPedId())) < 3.0 then
                    FreezeEntityPosition(PlayerPedId(), true)
                    if (CarryingData.Key == "repair") then
                        SetVehicleEngineHealth(CurrentVehicle, 100)
                        SetVehicleEngineOn(CurrentVehicle, true, true)
                        SetVehicleFixed(CurrentVehicle)
                    else
                        UpgradeVehicle(CurrentVehicle)
                    end

                    Citizen.Wait(100)

                    OnEmotePlay(Config.Emotes["mechanic"])
                    DisplayProgress(15000, "Installing", 'mini@repair', 'fixing_a_player')
                    Citizen.Wait(15000)

                    ClearPedTasksImmediately(PlayerPedId())

                    FreezeEntityPosition(PlayerPedId(), false)
                    break
                end
            elseif (IsControlJustPressed(1, 73)) then
                StopCarrying()
                break
            end
            Citizen.Wait(0)
        end
    end)
end

RegisterNetEvent("nh-context:returnData")
AddEventHandler("nh-context:returnData", function(_data)
    local key = _data.id
    local data = _data.data
    if (key == "workbench5") then
        if (data.selected == "repair") then
            SetActiveCarrying(data.selected, 0)
        else
            TriggerEvent('nh-context-bridge:sendMenu', data.submenu)
        end
    elseif (JobData.CarryingSettings[key]) then
        SetActiveCarrying(key, data.selected)
    elseif (key == "returnWorkbench5") then
        TriggerEvent('nh-context-bridge:sendMenu', MosleysGetWorkbench5Menu())
    end
end)
