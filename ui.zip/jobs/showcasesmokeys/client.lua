local JobData = Config.Jobs.Showcasesmokeys
local HasAlreadyEnteredMarker = false
local LastZone = nil

function StartScriptC()
    if JobData.EnableBlips then
        for k, v in pairs(JobData.Locations) do
            local blip = AddBlipForCoord(v.coords)
            SetBlipSprite(blip, 380)
            SetBlipColour(blip, 1)
            SetBlipScale(blip, 0.7)
            SetBlipDisplay(blip, 4)
            SetBlipAsShortRange(blip, true)

            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString('SCZaza')
            EndTextCommandSetBlipName(blip)
        end
    end

    Citizen.CreateThread(function()
        while true do
            local wait = 0

            for k, v in pairs(JobData.Locations) do
                local coords = GetEntityCoords(PlayerPedId())

                local dist = #(coords - v.coords)

                if dist < 10 then
                    LastZone = k
                    if Marker(v.coords, dist, "Browse") then
                        JobsNUI:Emit("items", JobData.Items)
                        JobsNUI:Emit("open", { context = "showcasesmokeys", customPurchaseText = "Order", customPurchaseEvent = "purchasesmokeys" })
                        SetNuiFocus(true, true)
                    end
                end
            end

            if LastZone == nil then
                wait = 1000
            end

            Citizen.Wait(0)
        end
    end)
end

local canOrder = true

JobsNUI:On("purchasesmokeys", function(data, cb)
    if data.context ~= "showcasesmokeys" then
        return
    end

    if canOrder == false then
        ESX.ShowNotification("You recently placed an order, please wait before trying again")
        return
    end

    SetTimeout(60000, function()
        canOrder = true
    end)
    canOrder = false

    exports["lb-phone"]:SendCompanyMessage("smokeys", "Order placed!", false)
    ESX.ShowNotification("We have received your order!")

    cb('')
end)

local currentActionData
local currentAction
local currentActionData

AddEventHandler('showcase:entermarker', function(zone)
    currentAction = zone
    currentMessage = 'Press ~INPUT_CONTEXT~ browse'
    currentActionData = true
end)

AddEventHandler('showcase:exitmarker', function(zone)
    ESX.UI.Menu.CloseAll()
    currentAction = nil
end)

StartScriptC()
